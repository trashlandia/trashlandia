# game.py - FIXED: Victory zone collision detection and end sequence - PYGBAG COMPATIBLE
"""Main Game Class - Coordinates all game systems with train station hub"""

import pygame
import sys
import os
import time
import math
import random
import asyncio  # Added for pygbag compatibility
from config.settings import *
from config.settings import GameState, SCREEN_WIDTH, SCREEN_HEIGHT
from models.character import Character
from models.npc import NPC
from models.zone import Zone
from systems.camera import Camera
from systems.map_loader import MapLoader
from systems.save_system import SaveSystem
from systems.highscore_system import HighscoreSystem
from ui.player_name_screen import PlayerNameScreen
from ui.renderer import GameRenderer


class Game:
    """Main game class that coordinates all systems"""

    def __init__(self, player_name=None):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Our Trashy Adventure")

        # Stop intro music when transitioning to the main game
        pygame.mixer.music.stop() # COMMENTED OUT

        # Initialize core systems
        self._init_core_systems(player_name)
        self._init_game_state()
        self._init_train_animation()
        self._init_world_data()
        self._init_zones()
        self._init_rendering()
        self._init_audio()
        self._init_ui_state()
        self._init_victory_zone_state()  # NEW: Initialize victory zone specific state
        self.train_station_title_shown = False

        # ADDED: Initialize timing for animations
        self.last_time = time.time()
        self.delta_time = 0

        # Initialize game data and load progress
        self._initialize_game_data()
        if self.save_system.load_progress_sync(self):
            self._respawn_at_train_station()

    def _init_victory_zone_state(self):
        """Initialize victory zone specific state variables - MODIFIED: Added artifact message state"""
        self.spaceship_world_rect = None
        self.spaceship_collision_active = False
        self.end_sequence_timer = 0
        self.spaceship_end_x = -200
        self.spaceship_end_y = SCREEN_HEIGHT // 2
        self.spaceship_end_speed = 2.0
        self.end_credits_started = False

        # NEW: Artifact message state
        self.artifact_message = ""
        self.artifact_message_timer = 0
        self.show_artifact_message = False
        self.artifact_message_duration = 2000  # 2 seconds

        # ADD: Credits pause timer initialization
        self.credits_pause_start_time = 0

    def _init_core_systems(self, player_name=None):
        """Initialize core game systems - MODIFIED to accept player name and detect Noah mode"""
        self.highscore_system = HighscoreSystem()

        # Use provided player name or default
        if player_name:
            self.highscore_system.set_player_name(player_name)
            # NEW: Check for Noah mode
            self.noah_mode = player_name.lower() == "noah"
        else:
            # Fallback for browser deployment - use default name
            player_name = "Anonymous"
            self.highscore_system.set_player_name(player_name)
            # NEW: Check for Noah mode
            self.noah_mode = player_name.lower() == "noah"

        self.highscore_system.start_game_timer()

        self.clock = pygame.time.Clock()

        # Use web-compatible save system
        try:
            from main import WebSaveSystem
            self.save_system = WebSaveSystem()
        except ImportError:
            # Fallback to original save system
            self.save_system = SaveSystem()

    def is_noah_mode(self):
        """NEW: Check if Noah mode is active for special minimap behavior"""
        return getattr(self, 'noah_mode', False)

    def _init_game_state(self):
        """Initialize game state variables"""
        self.running = True
        self.state = GameState.EXPLORATION
        self.current_door_dialogue = None

        # Game mechanics state
        self.combat_cooldown_end = 0
        self.last_fled_enemy = None
        self.speed_boost_active = False
        self.speed_boost_end_time = 0
        self.door_cooldown = False
        self.door_cooldown_start = 0
        self.door_cooldown_duration = 500

    def _init_train_animation(self):
        """Initialize train animation data"""
        self.train_image = None
        self.train_x = self.train_y = 0
        self.train_speed = 5
        self.train_animation_start_time = 0
        self.train_animation_duration = 4000
        self.current_path_index = 0
        self._load_train_image()

    def _init_world_data(self):
        """Initialize world and zone data"""
        # Zone order with 5 new zones added
        self.zone_order = [
            "Oozing Canal City", "Forest of Rusting Trees", "Wasteland Plains", "Train Station",
            "Toxic Swamplands", "Burning Deserts", "Frozen Wasteland", "Volcanic Peaks",
            "Dark Abyss", "BOSS ENEMY LEVEL", "Final Victory Zone"
        ]

        self.current_zone = self.zone_order[0]
        self.zone_maps = {}
        self.current_zone_map = None
        self.world_width = 4000  # Default fallback
        self.world_height = 3000
        self._load_zone_maps()

    def _init_zones(self):
        """Initialize all game zones"""
        # Set player position based on current map dimensions
        self.player = Character(
            name="Barf", hp=100, max_hp=100, level=1, xp=0,
            skills={"environmentalist": 1, "combatant": 1},
            inventory=[], block_chance=30
        )
        self.player.x = self.world_width // 2
        self.player.y = self.world_height // 2

        # Create zones with appropriate settings
        zone_configs = [
            (0, 40), (1, 40), (2, 40), (3, 0, True),  # Original zones + hub
            (4, 40), (5, 40), (6, 40), (7, 40), (8, 40),  # New zones
            (9, 0, False, True),  # Boss zone
            (10, 0, False, False)  # Final Victory Zone
        ]

        self.zones = {}
        for i, config in enumerate(zone_configs):
            zone_name = self.zone_order[i]
            trash_count = config[1]
            is_hub = len(config) > 2 and config[2]
            is_special = len(config) > 3 and config[3]
            self.zones[zone_name] = Zone(zone_name, trash_count, self.world_width,
                                         self.world_height, is_hub=is_hub, is_special=is_special)

    def _init_rendering(self):
        """Initialize rendering systems"""
        self.camera = Camera()
        from systems.crafting import CraftingSystem
        from systems.combat import CombatSystem
        from systems.input_handler import InputHandler

        self.combat = CombatSystem()
        self.combat.set_game(self)
        self.renderer = GameRenderer(self.screen, self)
        self.fonts = self.renderer.fonts
        self.crafting = CraftingSystem()
        self.input_handler = InputHandler(self)
        self.upgrade_button_rects = {}

    def _init_audio(self):
        """Initialize audio system"""
        if not pygame.mixer.get_init():
            pygame.mixer.init()
        self.music_playing = True
        self.music_loaded = False
        self.current_music = None
        self.music_position = 0
        self._load_music()

    def _init_ui_state(self):
        """Initialize UI state variables"""
        ui_states = ['show_inventory', 'show_dialogue', 'show_crafting', 'show_minimap',
                     'show_player_stats', 'show_highscores']
        for state in ui_states:
            setattr(self, state, False)
        self.restart_button = None
        self.show_victory_text = False
        self.victory_text_start_time = 0
        self.victory_text_duration = 4000  # 4 seconds

        # CRITICAL: Initialize zone title variables properly
        self.show_zone_title = False
        self.zone_title_start_time = 0
        self.zone_title_duration = 3000  # 3 seconds
        self.current_zone_title = ""
        self.zone_title_subtitle = ""
        self.previous_zone = None  # Track previous zone to detect changes
        self.level_up_notice_end = 0  # NEW: when the "LEVEL UP" banner stops showing
        self.heal_notice_end = 0  # when the "FULLY HEALED" banner stops showing

    def check_spaceship_collision(self):
        """MODIFIED: Check spaceship collision in victory zone with artifact requirement"""
        if (self.current_zone != "Final Victory Zone" or
                self.spaceship_collision_active or
                not hasattr(self, 'spaceship_world_rect') or
                self.spaceship_world_rect is None):
            return False

        # Create player collision rect - slightly larger for easier collision
        player_rect = pygame.Rect(self.player.x - 20, self.player.y - 20, 40, 40)

        # Check collision with spaceship
        if player_rect.colliderect(self.spaceship_world_rect):
            # NEW: Check if player has all 3 alien artifacts
            if self._has_all_alien_artifacts():
                self._start_end_sequence()
                return True
            else:
                self._show_artifact_requirement_message()
            return False

        return False

    def _has_all_alien_artifacts(self):
        """NEW: Check if player has all 3 required alien artifacts in inventory"""
        from config.settings import ArtType

        artifact_count = 0
        for item in self.player.inventory:
            if (hasattr(item, 'item_type') and
                    item.item_type == ArtType.ALIEN_ARTIFACT):
                artifact_count += 1

        return artifact_count >= 3

    def _show_artifact_requirement_message(self):
        """NEW: Show message when player tries to enter spaceship without artifacts - with proper styling"""
        from config.settings import ArtType

        # Count current artifacts
        artifact_count = 0
        for item in self.player.inventory:
            if (hasattr(item, 'item_type') and
                    item.item_type == ArtType.ALIEN_ARTIFACT):
                artifact_count += 1

        artifacts_needed = 3 - artifact_count

        # Initialize message system if needed
        if not hasattr(self, 'artifact_message'):
            self.artifact_message = ""
            self.artifact_message_timer = 0
            self.show_artifact_message = False

        if artifacts_needed > 0:
            self.artifact_message = f"The spaceship's control panel flickers with alien symbols. You need {artifacts_needed} more alien artifacts to activate the departure sequence and escape this world."
        else:
            self.artifact_message = "The spaceship hums to life! All alien artifacts are in place. The departure sequence is ready to begin."

        self.show_artifact_message = True
        self.artifact_message_timer = pygame.time.get_ticks()

    def _start_end_sequence(self):
        """FIXED: Start the end sequence when player touches spaceship - NO highscore recording"""
        self.spaceship_collision_active = True
        self.end_credits_started = True
        self.end_sequence_timer = 0
        self.spaceship_end_x = -200
        self.spaceship_end_y = SCREEN_HEIGHT // 2

    def _respawn_at_train_station(self):
        """Respawn player at train station with full health"""
        self.current_zone = "Train Station"
        self.current_zone_map = self.zone_maps.get("Train Station")
        self.player.x = self.world_width // 2
        self.player.y = self.world_height // 2
        self.player.hp = self.player.max_hp

        # Reset victory zone state when respawning
        self._init_victory_zone_state()

        # Update conductor's door positions
        zone = self.get_current_zone()
        if zone.is_hub and zone.npcs:
            for npc_tuple in zone.npcs:
                npc = npc_tuple[0]
                if hasattr(npc, 'is_conductor') and npc.is_conductor:
                    npc.door_positions = [(door.x, door.y) for door in zone.doors]
                    npc.current_door_index = 0
                    npc.pause_at_door = 0
                    break

        self.camera.update(self.player.x, self.player.y)
        self.renderer.minimap_dirty = True
        self._play_zone_music()

    def handle_player_death(self):
        """Handle player death - pause timer, save progress and transition to death screen"""
        # FIXED: Pause timer instead of resetting it
        self.highscore_system.pause_timer()
        self.save_system.save_progress_sync(self)
        self.state = GameState.GAME_OVER
        self._create_restart_button()

    def restart_from_death(self):
        """Restart game from death - keep progress, respawn at train station, RESUME timer"""
        self.player.hp = self.player.max_hp

        # Clear temporary states
        self.combat_cooldown_end = 0
        self.last_fled_enemy = None
        self.speed_boost_active = False
        self.speed_boost_end_time = 0

        # Reset victory zone state
        self._init_victory_zone_state()

        # Close all UI
        ui_states = ['show_inventory', 'show_dialogue', 'show_crafting', 'show_minimap',
                     'show_player_stats', 'show_highscores']
        for state in ui_states:
            setattr(self, state, False)

        # FIXED: Resume timer instead of starting new one
        self.highscore_system.resume_timer()

        self._respawn_at_train_station()
        self.state = GameState.EXPLORATION

    def start_new_game(self):
        """Start completely new game - clear all progress"""
        self.save_system.clear_save_sync()

        # NEW: Reset train station title flag for new game
        self.train_station_title_shown = False

        # For browser deployment, just reinitialize without showing name screen
        player_name = "Anonymous"
        self.__init__(player_name=player_name)

    def is_game_paused(self):
        """Check if the game should be paused due to UI overlays"""
        # FIXED: Don't pause during end credits
        if self.spaceship_collision_active and self.end_credits_started:
            return False

        if any([self.show_inventory, self.show_crafting, self.show_player_stats, self.show_highscores]):
            return True

        if hasattr(self.renderer, 'art_display'):
            art_display = self.renderer.art_display
            return (hasattr(art_display, 'show_art_dialogue') and art_display.show_art_dialogue) or \
                (hasattr(art_display, 'show_painting_viewer') and art_display.show_painting_viewer)
        return False

    def _calculate_delta_time(self):
        """Calculate delta time for smooth animations"""
        current_time = time.time()
        self.delta_time = current_time - self.last_time
        self.last_time = current_time
        return self.delta_time

    def _update_player_animation(self):
        """Update player animation based on current input state - FIXED"""
        if self.state != GameState.EXPLORATION:
            return

        # Don't update player animation during end credits
        if self.spaceship_collision_active and self.end_credits_started:
            return

        # Get current key states to determine movement
        keys = pygame.key.get_pressed()
        moving_up = keys[pygame.K_UP] or keys[pygame.K_w]
        moving_down = keys[pygame.K_DOWN] or keys[pygame.K_s]
        moving_left = keys[pygame.K_LEFT] or keys[pygame.K_a]
        moving_right = keys[pygame.K_RIGHT] or keys[pygame.K_d]

        # Update the player's animation with delta time and movement states
        self.player.update_exploration_animation(
            self.delta_time,
            moving_up=moving_up,
            moving_down=moving_down,
            moving_left=moving_left,
            moving_right=moving_right
        )

    def _load_zone_maps(self):
        """Load TMX maps for each zone"""
        zone_map_files = {
            "Oozing Canal City": "map1.tmx", "Forest of Rusting Trees": "map2.tmx",
            "Wasteland Plains": "map3.tmx", "Train Station": "maptrainstation.tmx",
            "Toxic Swamplands": "map5.tmx", "Burning Deserts": "map6.tmx",
            "Frozen Wasteland": "map7.tmx", "Volcanic Peaks": "map8.tmx",
            "Dark Abyss": "map9.tmx", "BOSS ENEMY LEVEL": "map4.tmx",
            "Final Victory Zone": "map10.tmx"
        }

        for zone_name, map_file in zone_map_files.items():
            try:
                # Try to load from maps folder first
                map_path = f"maps/{map_file}"
                map_loader = MapLoader(map_path)
                self.zone_maps[zone_name] = map_loader

                if not hasattr(self, '_world_dimensions_set'):
                    self.world_width = map_loader.width
                    self.world_height = map_loader.height
                    self._world_dimensions_set = True

            except Exception as e:
                print(f"Error loading map {map_file} for {zone_name}: {e}")
                try:
                    # Fallback: try without maps folder
                    map_loader = MapLoader(map_file)
                    self.zone_maps[zone_name] = map_loader
                except Exception:
                    # Final fallback: create a basic map loader
                    print(f"Creating fallback map for {zone_name}")
                    self.zone_maps[zone_name] = MapLoader("")  # Empty filename for fallback

        self.current_zone_map = self.zone_maps.get(self.current_zone)

    def get_current_zone_map(self):
        """Get the current zone's map"""
        return self.zone_maps.get(self.current_zone)

    def _transition_to_zone(self, target_zone_name, is_right_door, is_train_door=False):
        """Handle zone transitions - FIXED: Always show zone titles"""
        self.door_cooldown = True
        self.door_cooldown_start = pygame.time.get_ticks()

        if is_train_door:
            self.state = GameState.TRAIN_TRANSITION
            self.train_animation_start_time = pygame.time.get_ticks()
            self.current_path_index = 0
            self.train_x, self.train_y = self.train_path[0]
            return

        # Special handling for boss door
        if target_zone_name == "BOSS ENEMY LEVEL":
            main_zone_names = ["Oozing Canal City", "Forest of Rusting Trees", "Wasteland Plains",
                               "Toxic Swamplands", "Burning Deserts", "Frozen Wasteland",
                               "Volcanic Peaks", "Dark Abyss"]
            if not all(self.zones[zone_name].is_restored for zone_name in main_zone_names):
                self.current_door_dialogue = next(door for door in self.get_current_zone().doors
                                                  if door.target_zone == "BOSS ENEMY LEVEL")
                self.show_dialogue = True
                return

        # CRITICAL FIX: Store previous zone BEFORE changing
        self.previous_zone = self.current_zone

        # Normal zone transition
        self.current_zone = target_zone_name
        self.current_zone_map = self.zone_maps.get(target_zone_name)

        # FIXED: Reset victory zone state when entering victory zone
        if target_zone_name == "Final Victory Zone":
            self._init_victory_zone_state()

        # Position player in new zone
        if target_zone_name == "Train Station":
            self.player.x = self.world_width // 2
            self.player.y = self.world_height // 2
        elif target_zone_name == "BOSS ENEMY LEVEL":
            self.player.x = self.world_width // 2 - 200
            self.player.y = self.world_height // 2
        elif target_zone_name == "Final Victory Zone":
            # Position player away from spaceship initially
            self.player.x = 200  # Start at left side of map
            self.player.y = self.world_height // 2
        else:
            self._position_player_in_new_zone(is_right_door)

        self.camera.update(self.player.x, self.player.y)
        self.renderer.minimap_dirty = True
        self._play_zone_music()

        # CRITICAL FIX: Always show zone title when transitioning to different zone
        if self.previous_zone != target_zone_name:
            self._show_zone_entry_title(target_zone_name)

    def update(self):
        """MODIFIED: Update game state with artifact message handling"""
        # CRITICAL: Calculate delta time first for smooth animations
        self._calculate_delta_time()

        if self.state == GameState.GAME_OVER:
            return

        # Handle victory text timeout
        if self.show_victory_text:
            current_time = pygame.time.get_ticks()
            if current_time - self.victory_text_start_time >= self.victory_text_duration:
                self.show_victory_text = False

        # Handle zone title timeout
        if self.show_zone_title:
            current_time = pygame.time.get_ticks()
            if current_time - self.zone_title_start_time >= self.zone_title_duration:
                self.show_zone_title = False

        # Handle train transition animation
        if self.state == GameState.TRAIN_TRANSITION:
            current_time = pygame.time.get_ticks()
            elapsed = current_time - self.train_animation_start_time
            progress = min(1.0, elapsed / self.train_animation_duration)

            # Calculate current path segment
            total_segments = len(self.train_path) - 1
            current_segment = min(int(progress * total_segments), total_segments - 1)
            segment_progress = (progress * total_segments) % 1.0

            # Interpolate between path points
            start_x, start_y = self.train_path[current_segment]
            end_x, end_y = self.train_path[current_segment + 1]
            self.train_x = start_x + (end_x - start_x) * segment_progress
            self.train_y = start_y + (end_y - start_y) * segment_progress

            if elapsed >= self.train_animation_duration:
                self._complete_train_transition()
            return

        # FIXED: Handle end credits sequence
        if self.spaceship_collision_active and self.end_credits_started:
            self._update_end_sequence()
            return  # Don't process other game logic during end credits

        # Check if game should be paused due to UI overlays
        if self.is_game_paused():
            return

        # Handle speed boost expiration
        if self.speed_boost_active and self.get_speed_boost_remaining() <= 0:
            self.speed_boost_active = False

        if self.state == GameState.EXPLORATION:
            # CRITICAL: Update player animation BEFORE input handling
            self._update_player_animation()

            self.input_handler.handle_continuous_input()
            self.camera.update(self.player.x, self.player.y)

            # FIXED: Check spaceship collision in victory zone (now with artifact requirement)
            if self.current_zone == "Final Victory Zone":
                self.check_spaceship_collision()

            self._check_door_collisions()
            self.get_current_zone().update_npcs()
            self.get_current_zone().update_enemies()
            self._check_enemy_collisions()
            self._constrain_player_position()
        elif self.state == GameState.COMBAT:
            self.combat.update()

        self._check_level_up()

    def _update_end_sequence(self):
        """FIXED: Update the end credits sequence"""
        # Safety check for required attributes
        if not hasattr(self, 'end_sequence_timer') or not hasattr(self, 'spaceship_end_x'):
            return
        self.end_sequence_timer += 1

        # Move spaceship across screen
        self.spaceship_end_x += self.spaceship_end_speed

        # Reset spaceship position when it goes off screen
        if self.spaceship_end_x > SCREEN_WIDTH + 300:
            self.spaceship_end_x = -200
            # Vary the speed slightly for variety
            self.spaceship_end_speed = random.uniform(1.5, 3.0)

    def draw(self):
        """MODIFIED: Draw the current game state with artifact message support"""
        self.screen.fill(BLACK)

        if self.state == GameState.TRAIN_TRANSITION:
            self._draw_train_transition()
            return

        # FIXED: Handle end credits drawing
        if self.spaceship_collision_active and self.end_credits_started:
            self.renderer._draw_star_field()
            self.renderer._draw_spaceship_end_sequence()
            pygame.display.flip()
            return

        # Main game state rendering
        if self.state == GameState.GAME_OVER:
            self.renderer.draw_death_screen()
        elif self.state == GameState.EXPLORATION:
            self.renderer.draw_exploration(self.get_current_zone(), self.player, self.current_zone)
            self.renderer.draw_ui(self.player, self.get_current_zone(), self.current_zone)
        elif self.state == GameState.COMBAT:
            self.renderer.draw_combat(self.combat.selected_enemy, self.combat.combat_log)

        # Draw UI overlays (only if not in end credits)
        ui_overlays = [
            (self.show_inventory, lambda: self.renderer.draw_inventory(self.player.inventory)),
            (self.show_crafting, lambda: self.renderer.draw_crafting_menu()),
            (self.show_player_stats, lambda: self._draw_player_stats()),
            (self.show_dialogue, lambda: self.renderer.draw_dialogue()),
            (self.show_highscores, lambda: self.renderer.draw_highscores(self.highscore_system))
        ]

        for condition, draw_func in ui_overlays:
            if condition:
                draw_func()

        # Draw art displays if active
        if hasattr(self.renderer.art_display, 'show_art_dialogue') and self.renderer.art_display.show_art_dialogue:
            self.renderer.art_display.draw_art_dialogue()
        if hasattr(self.renderer.art_display,
                   'show_painting_viewer') and self.renderer.art_display.show_painting_viewer:
            self.renderer.art_display.draw_painting_viewer()

        # CRITICAL FIX: Draw zone title on top of everything else
        if hasattr(self, 'show_zone_title') and self.show_zone_title:
            self.renderer.draw_zone_title()

        # Draw victory text LAST (absolutely topmost)
        if hasattr(self, 'show_victory_text') and self.show_victory_text:
            self.renderer.draw_victory_text()

        # NEW: Draw artifact requirement message
        if hasattr(self, 'show_artifact_message') and self.show_artifact_message:
            self._draw_artifact_message()

        # Level-up banner
        if pygame.time.get_ticks() < self.level_up_notice_end:
            notice = self.fonts['normal'].render(f"LEVEL UP!  Level {self.player.level}", True, BLACK)
            self.screen.blit(notice, notice.get_rect(center=(SCREEN_WIDTH // 2, 120)))

        # Trade heal banner
        if pygame.time.get_ticks() < self.heal_notice_end:
            heal_text = self.fonts['normal'].render("TRADE COMPLETE - FULLY HEALED!", True, BLACK)
            self.screen.blit(heal_text, heal_text.get_rect(center=(SCREEN_WIDTH // 2, 160)))

        # Draw music button
        self.renderer.draw_music_button()
        pygame.display.flip()

    def _draw_artifact_message(self):
        """NEW: Draw the artifact requirement message with NPC dialogue box styling"""
        if not hasattr(self, 'artifact_message') or not self.artifact_message:
            return

        # Use the same panel size and positioning as NPC dialogue
        panel_size = DIALOGUE_PANEL_SIZE
        rect = pygame.Rect(
            SCREEN_WIDTH // 4, SCREEN_HEIGHT - panel_size[1] - 50,
            panel_size[0], panel_size[1]
        )

        # Semi-transparent black background (same as NPC dialogue)
        dialog_surface = pygame.Surface((rect.width, rect.height))
        dialog_surface.set_alpha(220)  # Same transparency as NPC dialogue
        dialog_surface.fill(BLACK)
        self.screen.blit(dialog_surface, rect)

        # White border (same as NPC dialogue)
        pygame.draw.rect(self.screen, WHITE, rect, 2)

        # Title using same font and style as NPC dialogue
        if hasattr(self, 'fonts') and 'small' in self.fonts:
            title_surf = self.fonts['small'].render("Spaceship Requirements:", True, WHITE)
            self.screen.blit(title_surf, (rect.x + 10, rect.y + 10))

        # Message text with word wrapping (leave space for "Press X" at bottom)
        if hasattr(self, 'fonts') and 'tiny' in self.fonts:
            font = self.fonts['tiny']

            # Word wrap the message
            words = self.artifact_message.split(' ')
            lines = []
            current_line = ""
            max_width = rect.width - 40  # Same padding as NPC dialogue

            for word in words:
                test_line = current_line + (" " if current_line else "") + word
                if font.size(test_line)[0] <= max_width:
                    current_line = test_line
                else:
                    if current_line:
                        lines.append(current_line)
                    current_line = word

            if current_line:
                lines.append(current_line)

            # Draw lines with same spacing and positioning as NPC dialogue
            y_offset = 50  # Same as NPC dialogue
            text_area_height = rect.height - 80  # Reserve space for "Press X" message

            for line in lines:
                if y_offset + 25 > text_area_height:  # Prevent overflow
                    break
                text_surf = font.render(line, True, WHITE)
                self.screen.blit(text_surf, (rect.x + 20, rect.y + y_offset))
                y_offset += 25

            # Draw "Press X to close" at the bottom (same style as NPC dialogue)
            close_text = "Press X to close"
            close_surf = font.render(close_text, True, WHITE)
            close_rect = close_surf.get_rect()
            close_rect.centerx = rect.centerx
            close_rect.bottom = rect.bottom - 15  # Same positioning as NPC dialogue
            self.screen.blit(close_surf, close_rect)

    async def run(self):
        """Main game loop - async for pygbag"""
        while self.running:
            self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(FPS)
            await asyncio.sleep(0)  # Required for pygbag

        # Only reached on a normal exit (window closed)
        self.save_system.clear_save_sync()
        pygame.quit()
        sys.exit()

    def get_rainbow_color(self, progress):
        """Generate rainbow colors based on animation progress"""
        offsets = [0, 2, 4]
        return tuple(int(255 * (0.5 + 0.5 * math.sin(progress * 2 * math.pi + offset)))
                     for offset in offsets)

    def _initialize_game_data(self):
        """Initialize all game data"""
        self.player_image_right = self.player_image_left = self.current_player_image = None
        self.player_facing_right = True
        self._load_player_images()

        for zone in self.zones.values():
            zone._generate_content(self)

        self.init_fog_of_war()
        self._play_zone_music()

        # CRITICAL FIX: Show zone title for initial zone
        self._show_zone_entry_title(self.current_zone)

    def _load_player_images(self):
        """Load player sprite images using Character class system"""
        Character.load_player_images()

    def restart_game(self):
        """Completely restart the game"""
        self._initialize_game_data()

    def _create_restart_button(self):
        """Create the restart button for the death screen"""
        button_width, button_height = 300, 100
        button_x = (SCREEN_WIDTH - button_width) // 2
        button_y = SCREEN_HEIGHT - button_height - 40
        self.restart_button = pygame.Rect(button_x, button_y, button_width, button_height)

    def _find_music_path(self, filename):
        """Find a music file in the search paths"""
        for path in MUSIC_SEARCH_PATHS:
            full_path = os.path.join(path, filename)
            if os.path.exists(full_path):
                return full_path
        return None

    def _load_music(self):
        """Check that music files exist for the zones"""
        self.zone_music = ZONE_MUSIC
        for music_file in self.zone_music.values():
            if self._find_music_path(music_file):
                self.music_loaded = True
                return
        print("Warning: no .ogg music files found")

    def toggle_music(self):
        """Mute/unmute music. Uses volume instead of pause/seek, which is more reliable in browsers"""
        if not self.music_loaded:
            return
        self.music_playing = not self.music_playing
        pygame.mixer.music.set_volume(MUSIC_VOLUME if self.music_playing else 0.0)

    def get_music_button_rect(self):
        """Get the rectangle for the music toggle button"""
        button_size = 40
        return pygame.Rect(SCREEN_WIDTH - button_size - 10, SCREEN_HEIGHT - button_size - 10,
                           button_size, button_size)

    def handle_music_button_click(self, pos):
        """Check if music button was clicked and toggle music"""
        if self.get_music_button_rect().collidepoint(pos):
            self.toggle_music()
            return True
        return False

    def _play_zone_music(self):
        """Play the music for the current zone"""
        if not self.music_loaded:
            return

        music_file = self.zone_music.get(self.current_zone)
        if not music_file or self.current_music == music_file:
            return

        path = self._find_music_path(music_file)
        if not path:
            print(f"Music file not found: {music_file}")
            return

        try:
            pygame.mixer.music.stop()
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(MUSIC_VOLUME if self.music_playing else 0.0)
            pygame.mixer.music.play(-1)
            self.current_music = music_file
        except pygame.error as e:
            print(f"Error loading {path}: {e}")

    def _show_zone_entry_title(self, zone_name):
        """Show zone entry title with appropriate subtitle"""

        # NEW: Special handling for train station - only show once ever
        if zone_name == "Train Station":
            if self.train_station_title_shown:
                return
            else:
                self.train_station_title_shown = True

        # Don't show title if returning to the same zone (for other zones)
        if self.previous_zone == zone_name:
            return

        zone_info = self._get_zone_display_info(zone_name)
        self.current_zone_title = zone_info['title']
        self.zone_title_subtitle = zone_info['subtitle']
        self.show_zone_title = True
        self.zone_title_start_time = pygame.time.get_ticks()

    def _get_zone_display_info(self, zone_name):
        """Get display title and subtitle for each zone"""
        zone_display_data = {
            "Oozing Canal City": {
                "title": "OOZING CANAL CITY",
                "subtitle": "A city drowning in pollution and decay"
            },
            "Forest of Rusting Trees": {
                "title": "FOREST OF RUSTING TREES",
                "subtitle": "Where nature battles industrial waste"
            },
            "Wasteland Plains": {
                "title": "WASTELAND PLAINS",
                "subtitle": "Barren lands scarred by neglect"
            },
            "Train Station": {
                "title": "CENTRAL TRAIN STATION",
                "subtitle": "Hub of hope and restoration"
            },
            "Toxic Swamplands": {
                "title": "TOXIC SWAMPLANDS",
                "subtitle": "Poisoned marshes of forgotten waste"
            },
            "Burning Deserts": {
                "title": "BURNING DESERTS",
                "subtitle": "Scorched earth under a merciless sun"
            },
            "Frozen Wasteland": {
                "title": "FROZEN WASTELAND",
                "subtitle": "Ice-locked realm of abandoned hopes"
            },
            "Volcanic Peaks": {
                "title": "VOLCANIC PEAKS",
                "subtitle": "Where fire meets the desperate earth"
            },
            "Dark Abyss": {
                "title": "DARK ABYSS",
                "subtitle": "The deepest depths of despair"
            },
            "BOSS ENEMY LEVEL": {
                "title": "FINAL BOSS BATTLE",
                "subtitle": "Face the source of all the waste"
            },
            "Final Victory Zone": {
                "title": "ESCAPE BY ROCKET",
                "subtitle": "...find a way out of this trashy land"
            }
        }

        return zone_display_data.get(zone_name, {
            "title": zone_name.upper(),
            "subtitle": "A land in need of restoration"
        })

    def init_fog_of_war(self):
        """Initialize fog of war data with proper path definitions"""
        if hasattr(self.renderer, 'revealed_positions'):
            self.renderer.revealed_positions = {
                zone_name: set() for zone_name in self.zone_order if zone_name != "BOSS ENEMY LEVEL"
            }
            self.renderer.minimap_dirty = True

        # Combat-specific image
        self.player_combat_image = None
        for path in ["", "assets/", "images/", "data/"]:
            try:
                self.player_combat_image = pygame.image.load(f"{path}guy1.png").convert_alpha()
                self.player_combat_image = pygame.transform.scale(self.player_combat_image, (192, 192))
                break
            except:
                continue

        self.current_player_image = self.player_image_right or self.player_image_left
        self.player_facing_right = True

    def get_speed_boost_remaining(self):
        """Get remaining speed boost time in seconds"""
        current_time = time.time()
        if self.speed_boost_active and current_time < self.speed_boost_end_time:
            return int(self.speed_boost_end_time - current_time)
        elif self.speed_boost_active:
            self.speed_boost_active = False
            return 0
        return 0

    def activate_speed_boost(self, duration=20):
        """Activate speed boost for specified duration"""
        self.speed_boost_active = True
        self.speed_boost_end_time = time.time() + duration

    def get_current_zone(self):
        """Get the current zone object"""
        return self.zones[self.current_zone]

    def can_craft_item(self, recipe_name):
        """Check if player can craft an item"""
        return self.crafting.can_craft(recipe_name, self.player.inventory)

    def craft_item(self, recipe_name):
        """Craft an item if possible"""
        if self.can_craft_item(recipe_name):
            crafted_item = self.crafting.craft_item(recipe_name, self.player.inventory)
            if crafted_item:
                self.player.inventory.append(crafted_item)
                return True
        return False

    def _handle_death_screen_click(self, pos):
        """Handle clicks on the death screen"""
        if hasattr(self, 'restart_button') and self.restart_button and self.restart_button.collidepoint(pos):
            has_progress = any(zone.is_restored for zone in self.zones.values() if not zone.is_hub)
            if has_progress:
                self.restart_from_death()
            else:
                self.start_new_game()
            return True

        if hasattr(self, 'new_game_button') and self.new_game_button and self.new_game_button.collidepoint(pos):
            self.start_new_game()
            return True
        return False

    def handle_boss_defeated(self):
        """Called when boss enemy is defeated - record highscore, show victory text, and create victory door"""
        # Show victory text
        self.show_victory_text = True
        self.victory_text_start_time = pygame.time.get_ticks()

        # Record the victory
        success = self.highscore_system.record_victory(self.player.hp, self.player.total_attack)
        if success:
            completion_time = self.highscore_system.get_formatted_current_time()

        # CREATE VICTORY DOOR - spawn it near the player
        self._create_victory_door()

    def _create_victory_door(self):
        """Create a victory door that appears after boss defeat"""
        from models.door import Door

        # Position door about 100 pixels to the right of player
        door_x = self.player.x + 100
        door_y = self.player.y

        # Ensure door is within world bounds
        door_x = max(50, min(door_x, self.world_width - 50))
        door_y = max(50, min(door_y, self.world_height - 50))

        # Create the victory door with special image using old constructor signature
        victory_door = Door(
            "Final Victory Zone",  # target_zone first
            door_x,  # x second
            door_y,  # y third
            True,  # is_right_door
            "door10.png"  # door_image
        )

        # Add special dialogue for the victory door
        victory_door.dialogue = ["A portal to a restored world awaits..."]

        # Add the door to the current boss zone
        current_zone = self.get_current_zone()
        current_zone.doors.append(victory_door)

        # Update minimap to show the new door
        self.renderer.minimap_dirty = True

    def _load_train_image(self):
        """Load the train image and calculate animation path"""
        for path in ASSET_SEARCH_PATHS:
            try:
                self.train_image = pygame.image.load(os.path.join(path, "train.png")).convert_alpha()
                self.train_image = pygame.transform.scale(self.train_image, (300, 150))
                self.train_path = [
                    (SCREEN_WIDTH // 4, SCREEN_HEIGHT // 4),
                    (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 3),
                    (3 * SCREEN_WIDTH // 4, SCREEN_HEIGHT // 4),
                    (SCREEN_WIDTH, SCREEN_HEIGHT // 2),
                    (SCREEN_WIDTH + 300, SCREEN_HEIGHT // 2)
                ]
                break
            except:
                continue

    def _handle_zone_restored(self):
        """Handle zone restoration - Award XP and save progress"""
        zone_level = self._get_zone_level()
        xp_reward = zone_level * 80
        self.player.xp += xp_reward
        self._check_level_up()
        self.save_system.save_progress_sync(self)

    def _handle_zone_restored(self):
        """Zone cleared: +1 level, plus XP to spend on upgrades"""
        zone_level = self._get_zone_level()
        xp_reward = zone_level * 80
        self.player.xp += xp_reward
        self.grant_level_up()
        self.save_system.save_progress_sync(self)

    def handle_combat_death(self):
        """Called when player dies in combat"""
        self.handle_player_death()

    def _check_door_collisions(self):
        """Check for door collisions and handle transitions"""
        current_time = pygame.time.get_ticks()
        if self.door_cooldown and (current_time - self.door_cooldown_start >= self.door_cooldown_duration):
            self.door_cooldown = False

        if self.door_cooldown or self.state != GameState.EXPLORATION:
            return

        # Don't check door collisions during end credits
        if self.spaceship_collision_active and self.end_credits_started:
            return

        zone = self.get_current_zone()
        player_rect = pygame.Rect(self.player.x - 24, self.player.y - 24, 48, 48)

        for door in zone.doors:
            if door.check_collision(player_rect):
                if hasattr(door, 'is_special_door') and door.is_special_door:
                    main_zone_names = ["Oozing Canal City", "Forest of Rusting Trees", "Wasteland Plains",
                                       "Toxic Swamplands", "Burning Deserts", "Frozen Wasteland",
                                       "Volcanic Peaks", "Dark Abyss"]
                    if all(self.zones[zone_name].is_restored for zone_name in main_zone_names):
                        self._transition_to_zone(door.target_zone, door.is_right_door, False)
                    else:
                        self.current_door_dialogue = door
                        self.show_dialogue = True
                    return
                else:
                    is_train_door = getattr(door, 'is_train_door', False)
                    self._transition_to_zone(door.target_zone, door.is_right_door, is_train_door)
                    return

    def _get_zone_level(self):
        """Get the difficulty level of the current zone"""
        zone_levels = {
            "Oozing Canal City": 1, "Forest of Rusting Trees": 2, "Wasteland Plains": 3,
            "Train Station": 0, "Toxic Swamplands": 4, "Burning Deserts": 5,
            "Frozen Wasteland": 6, "Volcanic Peaks": 7, "Dark Abyss": 8, "BOSS ENEMY LEVEL": 9
        }
        return zone_levels.get(self.current_zone, 1)

    def _position_player_in_new_zone(self, came_from_right_door):
        """Position player safely away from doors in new zone"""
        safe_distance = 500
        if came_from_right_door:
            self.player.x = safe_distance
        else:
            self.player.x = self.world_width - safe_distance
        self.player.y = self.world_height // 2 + random.randint(-100, 100)

    def _collect_items(self):
        """Collect both trash and food items"""
        zone = self.get_current_zone()
        collected_items, zone_restored = zone.cleanup_trash(
            int(self.player.x), int(self.player.y), TRASH_COLLECTION_RADIUS)

        for item in collected_items:
            self._add_to_inventory(item)

        if zone_restored:
            self._handle_zone_restored()

    def _try_interact_with_npc(self):
        """Check for nearby NPCs to interact with"""
        zone = self.get_current_zone()
        for npc, x, y in zone.npcs:
            distance = math.sqrt((self.player.x - x) ** 2 + (self.player.y - y) ** 2)
            if distance < DIALOGUE_RADIUS:
                self.show_dialogue = True
                return

    def _add_to_inventory(self, item):
        """Add any item to inventory with proper stacking"""
        self.player.add_to_inventory(item)

    def set_combat_cooldown(self, enemy):
        """Set a cooldown after fleeing from combat"""
        self.combat_cooldown_end = time.time() + 20
        self.last_fled_enemy = enemy

    def is_combat_on_cooldown(self, enemy):
        """Check if combat is on cooldown for this enemy"""
        return time.time() < self.combat_cooldown_end and enemy == self.last_fled_enemy

    def _check_enemy_collisions(self):
        """Check for collisions with moving enemies"""
        # Don't check enemy collisions during end credits
        if self.spaceship_collision_active and self.end_credits_started:
            return

        zone = self.get_current_zone()
        for enemy, x, y in zone.enemies:
            if self.is_combat_on_cooldown(enemy):
                continue

            distance = ((self.player.x - enemy.x) ** 2 + (self.player.y - enemy.y) ** 2) ** 0.5
            if distance < COMBAT_COLLISION_RADIUS:
                self.combat.start_combat(enemy)
                self.state = GameState.COMBAT
                break

    def _constrain_player_position(self):
        """Keep player within world bounds"""
        self.player.constrain_position(self.world_width, self.world_height)

    def _check_level_up(self):
        """Check if player should level up"""
        self.player.check_level_up()

    def grant_level_up(self, heal=True):
        """Give the player a level and show a short on-screen notice"""
        self.player.level_up(heal=heal)
        self.level_up_notice_end = pygame.time.get_ticks() + 2500

    def get_combat_cooldown_remaining(self):
        """Get remaining cooldown time in seconds after fleeing combat"""
        current_time = time.time()
        return int(self.combat_cooldown_end - current_time) if current_time < self.combat_cooldown_end else 0

    def handle_events(self):
        """Handle all pygame events"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            if self.state == GameState.TRAIN_TRANSITION:
                continue

            # FIXED: Handle ESC key during end credits to return to menu
            if self.spaceship_collision_active and self.end_credits_started:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    # Return to main menu or reset game
                    self.start_new_game()
                continue

            if event.type in [pygame.USEREVENT + 1, pygame.USEREVENT + 2, pygame.USEREVENT + 3]:
                if self.state == GameState.COMBAT:
                    self.combat.handle_custom_event(event)
                continue

            if self.state == GameState.GAME_OVER:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if self._handle_death_screen_click(event.pos):
                        return
                continue

            self.input_handler.handle_event(event)

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.handle_music_button_click(event.pos):
                    pass
                elif self.show_player_stats:
                    self._handle_stats_upgrade_click(event.pos)
            elif event.type == pygame.MOUSEWHEEL:
                if self.show_inventory and hasattr(self.renderer, 'handle_inventory_scroll'):
                    self.renderer.handle_inventory_scroll(event)

    def _handle_crafting_click(self, pos):
        """Handle clicks in crafting menu"""
        if hasattr(self.crafting, 'handle_crafting_click'):
            crafted_item = self.crafting.handle_crafting_click(pos, self.player.inventory)
            if crafted_item:
                return True
        return False

    def _handle_inventory_click(self, pos):
        """Handle inventory clicks"""
        for item in self.player.inventory:
            if hasattr(item, 'rect') and item.rect and item.rect.collidepoint(pos):
                self.player.handle_inventory_click(item, self)
                break

    def _handle_stats_upgrade_click(self, pos):
        """Handle clicks on stat upgrade buttons"""
        if not hasattr(self, 'upgrade_button_rects'):
            return False

        for stat_index, button_rect in self.upgrade_button_rects.items():
            if button_rect.collidepoint(pos):
                return self.player.handle_stat_upgrade(stat_index)
        return False

    def get_victory_zone_map(self):
        """Load map10.tmx for victory zone"""
        if self.current_zone == "Final Victory Zone":
            return self.load_tmx_map("map10.tmx")
        return self.get_current_zone_map()

    def _complete_train_transition(self):
        """Complete the train transition after animation - FIXED"""
        # Store previous zone for title display
        self.previous_zone = self.current_zone

        self.current_zone = "Train Station"
        self.current_zone_map = self.zone_maps.get("Train Station")
        self.player.x = self.world_width // 2
        self.player.y = self.world_height // 2
        self.camera.update(self.player.x, self.player.y)
        self.renderer.minimap_dirty = True
        self._play_zone_music()
        self.state = GameState.EXPLORATION

        # FIXED: Show train station title after train animation
        # Only show if we're actually coming from a different zone
        if self.previous_zone != "Train Station":
            self._show_zone_entry_title("Train Station")

    def _draw_player_stats(self):
        """Draw player stats and store button rects"""
        self.renderer.draw_player_stats_menu()
        self.upgrade_button_rects = getattr(self.renderer, 'upgrade_button_rects', {})

    def _draw_train_transition(self):
        """Draw train transition animation"""
        current_time = pygame.time.get_ticks()
        elapsed = current_time - self.train_animation_start_time
        progress = min(1.0, elapsed / self.train_animation_duration)

        # Draw multiple train images for trailing effect
        for i in range(3):
            alpha = 255 - (i * 80)
            if alpha <= 0:
                continue
            offset = i * 20
            trail_image = self.train_image.copy()
            trail_image.set_alpha(alpha)
            self.screen.blit(trail_image, (self.train_x - offset, self.train_y - offset))

        # Draw main train image
        self.screen.blit(self.train_image, (self.train_x, self.train_y))

        # Draw dynamic portal effect
        portal_size = int(300 + 200 * math.sin(progress * math.pi * 4))
        portal_surface = pygame.Surface((portal_size, portal_size), pygame.SRCALPHA)

        # Create pulsing portal with rotating effect
        angle = progress * 360 * 2
        for i in range(5):
            radius = portal_size // 2 - i * 30
            if radius <= 0:
                continue
            color = (100 + i * 30, 100 + i * 30, 255 - i * 50, 150 - i * 20)
            pygame.draw.circle(portal_surface, color, (portal_size // 2, portal_size // 2), radius)

        # Rotate and draw portal
        rotated_portal = pygame.transform.rotate(portal_surface, angle)
        portal_rect = rotated_portal.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
        self.screen.blit(rotated_portal, portal_rect)

        # Rainbow text at bottom
        if hasattr(self, 'fonts') and 'normal' in self.fonts:
            text_color = self.get_rainbow_color(progress * 2)
            text = self.fonts['normal'].render("To The Train Station...", True, text_color)
            text_rect = text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50))

            # Add text shadow
            shadow = self.fonts['normal'].render("To The Train Station...", True, BLACK)
            self.screen.blit(shadow, (text_rect.x + 2, text_rect.y + 2))
            self.screen.blit(text, text_rect)

        pygame.display.flip()