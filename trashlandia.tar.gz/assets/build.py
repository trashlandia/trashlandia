# build.py
import os
import shutil
import subprocess
import sys


def build_for_web():
    """Build the game for web deployment using pygbag"""

    # Create assets folder structure
    assets_dirs = ["assets", "images", "data"]
    for dir_name in assets_dirs:
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)

    # Check if pygbag is installed
    try:
        import pygbag
    except ImportError:
        print("Installing pygbag...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pygbag"])

    # Build command
    build_cmd = [sys.executable, "-m", "pygbag", "--build", "--template", "default.tmpl", "main.py"]

    print("Building for web...")
    result = subprocess.run(build_cmd, capture_output=True, text=True)

    if result.returncode == 0:
        print("Build successful!")
        print("Files are in build/web/ directory")

        # Copy assets to build directory
        build_assets_dir = "build/web/assets"
        if not os.path.exists(build_assets_dir):
            os.makedirs(build_assets_dir)

        for dir_name in assets_dirs:
            if os.path.exists(dir_name):
                dest_dir = os.path.join(build_assets_dir, dir_name)
                if os.path.exists(dest_dir):
                    shutil.rmtree(dest_dir)
                shutil.copytree(dir_name, dest_dir)

        print("Assets copied to build directory")
    else:
        print("Build failed:")
        print(result.stderr)


if __name__ == "__main__":
    build_for_web()