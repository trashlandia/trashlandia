# systems/combat.py
"""Combat System - Handle turn-based combat mechanics with interactive buttons and animated sprites"""
import random
import pygame
from typing import List, Optional
from config.settings import *


class CombatSystem:
    """Handles turn-based combat mechanics with interactive UI and sprite animations"""

    def __init__(self):
        self.selected_enemy: Optional['Enemy'] = None
        self.combat_log: List[str] = []
        self.game = None
        # CRITICAL: Enemy ALWAYS goes first - player_turn starts as False
        self.player_turn = False
        self.buttons = []
        self.player_defending = self.enemy_attack_announced = False
        self.combat_active = False
        self.block_successful = False
        self.block_attacks_remaining = 0
        self.buttons = []
        self.player_blocked_this_turn = False

        # NEW: Combat phase tracking to prevent premature player actions
        self.combat_phase = "enemy_first_attack"  # Track combat phases
        self.enemy_has_attacked_first = False  # Ensure enemy attacks first

        # Animation variables
        self.player_x = 150
        self.enemy_x = SCREEN_WIDTH - 200
        self.player_target_x = self.player_x
        self.enemy_target_x = self.enemy_x
        self.animation_speed = 8
        self.is_animating = False

        # Base positions
        self.player_base_x = 150
        self.enemy_base_x = SCREEN_WIDTH - 200
        self.center_offset = 100

    def set_game(self, game):
        self.game = game

    def start_combat(self, enemy):
        """Initialize combat with an enemy - GUARANTEED: Enemy attacks first"""
        self.selected_enemy = enemy
        self.combat_log = [f"Combat started with {enemy.type.value} enemy (Lvl {enemy.level})!"]

        # CRITICAL: ALWAYS set player_turn to False - enemy goes first EVERY TIME
        self.player_turn = False
        self.player_defending = self.enemy_attack_announced = False
        self.block_successful = False
        self.combat_active = True
        self.player_blocked_this_turn = False

        # NEW: Reset combat phase tracking
        self.combat_phase = "enemy_first_attack"
        self.enemy_has_attacked_first = False

        # Reset positions
        self.player_x = self.player_base_x
        self.enemy_x = self.enemy_base_x
        self.player_target_x = self.player_base_x
        self.enemy_target_x = self.enemy_base_x
        self.is_animating = False

        self._create_buttons()

    def _create_buttons(self):
        """Create interactive buttons for combat actions"""
        button_width, button_height = 220, 60
        gap = (SCREEN_WIDTH - (3 * button_width)) // 4
        start_y = SCREEN_HEIGHT - 150

        button_data = [
            ("ATTACK", (200, 50, 50), self._player_attack),
            ("BLOCK", (50, 50, 200), self._player_block),
            ("FLEE", (200, 200, 50), self._player_flee)
        ]

        self.buttons = []
        for i, (text, color, action) in enumerate(button_data):
            x = gap * (i + 1) + button_width * i
            self.buttons.append({
                "rect": pygame.Rect(x, start_y, button_width, button_height),
                "text": text,
                "color": color,
                "action": action
            })

    def handle_click(self, pos):
        """Handle button clicks - ONLY when it's truly player's turn AND enemy has attacked first"""
        if (not self.combat_active or
                not self.player_turn or
                self.is_animating or
                not self.enemy_has_attacked_first):  # NEW: Prevent action until enemy attacks first
            return False

        for button in self.buttons:
            if button["rect"].collidepoint(pos):
                button["action"]()
                return True
        return False

    def _start_player_animation(self):
        """Start player attack animation - ONLY if enemy has attacked first"""
        if not self.enemy_has_attacked_first:
            return False

        self.player_target_x = self.player_base_x + self.center_offset
        self.is_animating = True
        return True

    def _start_enemy_animation(self):
        """Start enemy attack animation"""
        self.enemy_target_x = self.enemy_base_x - self.center_offset
        self.is_animating = True

    def _return_player_to_base(self):
        """Return player to base position"""
        self.player_target_x = self.player_base_x

    def _return_enemy_to_base(self):
        """Return enemy to base position"""
        self.enemy_target_x = self.enemy_base_x

    def _update_animations(self):
        """Update sprite positions for animations"""
        if not self.is_animating:
            return

        # Update player position
        if abs(self.player_x - self.player_target_x) > self.animation_speed:
            if self.player_x < self.player_target_x:
                self.player_x += self.animation_speed
            else:
                self.player_x -= self.animation_speed
        else:
            self.player_x = self.player_target_x

        # Update enemy position
        if abs(self.enemy_x - self.enemy_target_x) > self.animation_speed:
            if self.enemy_x < self.enemy_target_x:
                self.enemy_x += self.animation_speed
            else:
                self.enemy_x -= self.animation_speed
        else:
            self.enemy_x = self.enemy_target_x

        # Check if animation is complete
        if (abs(self.player_x - self.player_target_x) <= self.animation_speed and
                abs(self.enemy_x - self.enemy_target_x) <= self.animation_speed):
            self.is_animating = False

    def _player_attack(self):
        """Player chooses to attack with animation - ONLY if enemy attacked first"""
        if (not self.combat_active or
                not self.selected_enemy or
                self.is_animating or
                not self.enemy_has_attacked_first):  # NEW: Block if enemy hasn't attacked
            return

        # Start attack animation
        if self._start_player_animation():
            self.animation_phase = "player_attack_forward"

    def _player_block(self):
        """Player attempts to block - Uses player's block_chance stat"""
        if (not self.combat_active or
                self.is_animating or
                not self.enemy_has_attacked_first):  # NEW: Block if enemy hasn't attacked
            return

        # Use the player's block_chance stat (convert percentage to decimal)
        block_chance = self.game.player.block_chance / 100.0

        if random.random() < block_chance:
            # Successful block
            self.block_attacks_remaining = 2
            self.player_blocked_this_turn = True
            self.combat_log.append(
                f"Block successful! ({self.game.player.block_chance}% chance) You get 2 more Attacks!")
            self.block_successful = True
        else:
            # Failed block
            self.player_blocked_this_turn = False
            self.combat_log.append(f"You failed to block! ({self.game.player.block_chance}% chance)")
            self.block_successful = False
            self._end_player_turn()

    def _player_flee(self):
        """Player flees combat - guaranteed success"""
        if self.is_animating:
            return

        self.combat_log.append("You successfully fled from combat!")
        if self.game and self.selected_enemy:
            self.game.set_combat_cooldown(self.selected_enemy)
        self.end_combat()

    def _end_player_turn(self):
        """End player turn - Enemy goes next"""
        self.player_turn = False
        self.player_defending = False
        self.enemy_attack_announced = False
        self.combat_phase = "enemy_turn"
        # Return player to base position
        self._return_player_to_base()

    def _enemy_attack(self):
        """Enemy's turn to attack with animation - GUARANTEED to happen when enemy turn"""
        if not self.combat_active or not self.selected_enemy or self.selected_enemy.hp <= 0:
            return

        # Handle extra attacks from successful block
        if self.block_successful and self.block_attacks_remaining > 0:
            self.block_attacks_remaining -= 1
            if self.block_attacks_remaining == 0:
                self.block_successful = False
                self.player_blocked_this_turn = False
                self._reset_turn()
            return

        if not self.enemy_attack_announced:
            self.combat_log.append(f"{self.selected_enemy.type.value.capitalize()} prepares to attack!")
            self.enemy_attack_announced = True
            # Start enemy animation
            self._start_enemy_animation()
            self.is_animating = True
            self.animation_phase = "enemy_attack_forward"
            return

        # Apply damage after animation completes
        if self.player_blocked_this_turn:
            # Player successfully blocked - no damage taken
            self.combat_log.append(
                f"You successfully blocked {self.selected_enemy.type.value.capitalize()}'s attack! No damage taken!")
            self.player_blocked_this_turn = False
        elif not self.player_defending:
            # Normal attack - full damage
            damage = random.randint(3, self.selected_enemy.attack)
            self.game.player.hp -= damage
            self.combat_log.append(f"{self.selected_enemy.type.value.capitalize()} deals {damage} damage!")
        else:
            # This shouldn't happen anymore since we removed the defend option, but keeping for safety
            damage = random.randint(1, max(1, self.selected_enemy.attack // 2))
            self.game.player.hp -= damage
            self.combat_log.append(f"You partially blocked the attack! Took {damage} damage!")

        # NEW: Mark that enemy has completed their first attack
        if not self.enemy_has_attacked_first:
            self.enemy_has_attacked_first = True
            self.combat_phase = "normal_combat"

        # Check for player defeat
        if self.game.player.hp <= 0:
            self._player_death()
        else:
            # Return enemy to base position
            self._return_enemy_to_base()
            self.animation_phase = "enemy_attack_return"
            self.is_animating = True

    def handle_custom_event(self, event):
        """Handle custom timer events for delayed actions"""
        if event.type == pygame.USEREVENT + 1:  # Victory delay
            pygame.time.set_timer(pygame.USEREVENT + 1, 0)  # Cancel timer
            self._victory()
        elif event.type == pygame.USEREVENT + 2:  # End player turn delay
            pygame.time.set_timer(pygame.USEREVENT + 2, 0)  # Cancel timer
            self._end_player_turn()
        elif event.type == pygame.USEREVENT + 3:  # Reset turn delay
            pygame.time.set_timer(pygame.USEREVENT + 3, 0)  # Cancel timer
            self._reset_turn()

    def handle_combat_outcome(self, combat_system):
        """Handle the outcome of combat - check for player death"""
        if self.game.player.hp <= 0:
            # Call the game's death handler
            self.game.handle_combat_death()
        else:
            # Normal combat end - return to exploration
            self.game.state = GameState.EXPLORATION

    def _player_death(self):
        """Handle player death - trigger game over state"""
        self.combat_log.append("You have been defeated!")
        self.game.player.hp = 0
        self._cleanup_combat()
        if self.game:
            self.game.state = GameState.GAME_OVER
            self.game._create_restart_button()
            zone = self.game.get_current_zone()
            zone.enemies = [(e, x, y) for e, x, y in zone.enemies if e != self.selected_enemy]

    def _victory(self):
        """Handle combat victory - Simplified boss detection"""
        if not self.selected_enemy:
            return

        # Remove the defeated enemy from the zone first
        zone = self.game.get_current_zone()
        zone.enemies = [(e, x, y) for e, x, y in zone.enemies if e != self.selected_enemy]

        # Award XP
        xp_gain = XP_PER_ENEMY_LEVEL * self.selected_enemy.level
        self.combat_log.append(f"Enemy defeated! Gained {xp_gain} XP!")
        self.game.player.xp += xp_gain
        # Level progression: every ENEMIES_PER_LEVEL kills = +1 level (no heal)
        player = self.game.player
        player.enemies_defeated += 1
        if player.enemies_defeated % max(1, ENEMIES_PER_LEVEL) == 0:
            self.game.grant_level_up(heal=False)

        # Check if we're in the boss zone
        if self.game and self.game.current_zone == "BOSS ENEMY LEVEL":
            self.combat_log.append("BOSS DEFEATED! Recording your victory!")

            # Force the victory text to show
            self.game.show_victory_text = True
            self.game.victory_text_start_time = pygame.time.get_ticks()

            # Record the victory
            if hasattr(self.game, 'handle_boss_defeated'):
                self.game.handle_boss_defeated()
            else:
                # Fallback: call highscore system directly
                self.game.highscore_system.record_victory(self.game.player.hp, self.game.player.total_attack)
        else:
            # Regular enemy defeat
            enemy_name = self.selected_enemy.type.value.capitalize()
            self.combat_log.append(f"{enemy_name} defeated!")

        # Update minimap
        if self.game.renderer:
            self.game.renderer.minimap_dirty = True

        # End combat
        self.end_combat()

    def _reset_turn(self):
        """Reset turn state - Player turn comes after enemy"""
        self.player_defending = self.enemy_attack_announced = False
        # NEW: Only allow player turn if enemy has attacked first
        if self.enemy_has_attacked_first:
            self.player_turn = True
            self.combat_phase = "player_turn"
        else:
            # Force enemy turn if they haven't attacked yet
            self.player_turn = False
            self.combat_phase = "enemy_first_attack"

        # Return enemy to base position
        self._return_enemy_to_base()

    def _cleanup_combat(self):
        """Clean up combat state completely"""
        self.combat_active = False
        self.selected_enemy = None
        self.combat_log = []
        # CRITICAL: Reset to enemy-first for next combat
        self.player_turn = False
        self.player_defending = False
        self.enemy_attack_announced = False
        self.block_successful = False
        self.block_attacks_remaining = 0
        self.player_blocked_this_turn = False
        self.buttons = []
        self.is_animating = False

        # NEW: Reset combat phase tracking
        self.combat_phase = "enemy_first_attack"
        self.enemy_has_attacked_first = False

        # Cancel any pending timers
        pygame.time.set_timer(pygame.USEREVENT + 1, 0)
        pygame.time.set_timer(pygame.USEREVENT + 2, 0)
        pygame.time.set_timer(pygame.USEREVENT + 3, 0)

    def end_combat(self):
        """Public method to end combat and return to exploration"""
        self._cleanup_combat()
        if self.game:
            # Ensure player HP is properly bounded
            self.game.player.hp = max(0, min(self.game.player.hp, self.game.player.max_hp))
            self.game.state = GameState.EXPLORATION

    def update(self):
        """Update combat system each frame - GUARANTEED enemy-first logic with phase control"""
        if not self.combat_active or self.game.state == GameState.GAME_OVER:
            return

        # Update animations
        self._update_animations()

        # Handle animation completion - MODIFIED to respect enemy-first rule
        if not self.is_animating and hasattr(self, 'animation_phase'):
            if self.animation_phase == "player_attack_forward":
                # NEW: Double-check enemy attacked first before allowing player damage
                if not self.enemy_has_attacked_first:
                    self._reset_turn()
                    del self.animation_phase
                    return

                # Player has reached attack position, apply damage
                base_damage = random.randint(self.game.player.total_attack - 2, self.game.player.total_attack + 7)
                damage = base_damage * self.game.player.level
                self.selected_enemy.hp -= damage

                if self.game.player.attack_bonus > 0:
                    self.combat_log.append(
                        f"You attack with your equipment! Deal {damage} damage! "
                    )
                else:
                    self.combat_log.append(f"You attack and deal {damage} damage!")

                if self.selected_enemy.hp <= 0:
                    self.selected_enemy.hp = 0  # Ensure HP doesn't go negative
                    self._victory()  # Immediately handle victory
                else:
                    # Return player to base position
                    self._return_player_to_base()
                    self.animation_phase = "player_attack_return"
                    self.is_animating = True

            elif self.animation_phase == "player_attack_return":
                # Player has returned to base, end turn (enemy goes next)
                self._end_player_turn()
                del self.animation_phase

            elif self.animation_phase == "enemy_attack_return":
                # Enemy has returned to base, now it's player's turn (if enemy attacked first)
                self._reset_turn()
                del self.animation_phase

        # CRITICAL: Enemy turn logic - Process when it's enemy's turn and not animating
        # PRIORITY: If enemy hasn't attacked first yet, force enemy turn regardless of player_turn value
        if ((not self.player_turn or not self.enemy_has_attacked_first) and
                self.selected_enemy and
                not self.is_animating and
                self.selected_enemy.hp > 0):
            self._enemy_attack()

    def get_sprite_positions(self):
        """Get current sprite positions for rendering"""
        return {
            'player_x': self.player_x,
            'enemy_x': self.enemy_x,
            'player_y': SCREEN_HEIGHT // 2,
            'enemy_y': SCREEN_HEIGHT // 2
        }

    def draw_buttons(self, screen):
        """Draw combat buttons - ONLY show when it's truly player's turn AND enemy has attacked first"""
        if (not self.combat_active or
                not self.player_turn or
                not self.enemy_has_attacked_first):  # NEW: Hide buttons until enemy attacks first
            return

        # Button container background
        button_bg = pygame.Surface((SCREEN_WIDTH, 120))
        button_bg.fill((20, 20, 30))
        screen.blit(button_bg, (0, SCREEN_HEIGHT - 120))

        for button in self.buttons:
            # Disable buttons during animation
            button_color = button["color"] if not self.is_animating else (100, 100, 100)

            pygame.draw.rect(screen, button_color, button["rect"])
            pygame.draw.rect(screen, WHITE, button["rect"], 3)

            if self.game and self.game.renderer:
                text_surf = self.game.renderer.fonts['normal'].render(button["text"], True, WHITE)
                text_rect = text_surf.get_rect(center=button["rect"].center)
                screen.blit(text_surf, text_rect)