# systems/input_handler.py - MODIFIED: Art items appear at top of inventory
"""
Input Handler System - Manages all user input
CHANGE: Art items (poetry, paintings, alien artifacts) now appear at top of inventory
"""

import pygame
import math
from config.settings import *
from models.item import Item


class InputHandler:
    """Handles all user input for the game"""

    def __init__(self, game):
        self.game = game
        self.current_interacting_npc = None

    def handle_event(self, event):
        """Handle discrete events (key presses, mouse clicks)"""
        if event.type == pygame.QUIT:
            self.game.running = False
            return

        # Handle art/painting windows first (highest priority)
        if self._handle_art_windows(event):
            return

        elif event.type == pygame.KEYDOWN:
            self._handle_keydown(event.key)

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                # Handle NPC quest button clicks FIRST (highest priority when dialogue is open)
                if (self.game.show_dialogue and
                        self.current_interacting_npc and
                        hasattr(self.current_interacting_npc, 'handle_click')):
                    if self.current_interacting_npc.handle_click(event.pos, self.game.player.inventory,
                                                                 self.game.player):
                        # Trade completed - the NPC code already gave XP and healed the player
                        self.game.heal_notice_end = pygame.time.get_ticks() + 2000
                        self.game._check_level_up()
                        return

                # Handle other click handlers...
                if self.game.state == GameState.COMBAT:
                    self.game.combat.handle_click(event.pos)
                elif self.game.show_crafting:
                    self._handle_crafting_click(event.pos)
                elif self.game.show_inventory:
                    self._handle_inventory_click(event.pos)
                elif self.game.show_player_stats:
                    self._handle_player_stats_click(event.pos)
                elif self.game.state == GameState.GAME_OVER:
                    self.game._handle_death_screen_click(event.pos)

        elif event.type == pygame.MOUSEBUTTONUP:
            # Handle mouse button release for art dialogue scrollbar
            if (hasattr(self.game.renderer, 'show_art_dialogue') and
                    self.game.renderer.show_art_dialogue):
                if self.game.renderer.handle_art_dialogue_click(event.pos, event):
                    return

        elif event.type == pygame.MOUSEMOTION:
            # Handle mouse motion for art dialogue scrollbar dragging ONLY
            if (hasattr(self.game.renderer, 'show_art_dialogue') and
                    self.game.renderer.show_art_dialogue and
                    hasattr(self.game.renderer, 'art_dialogue_dragging') and
                    self.game.renderer.art_dialogue_dragging):
                if self.game.renderer.handle_art_dialogue_click(event.pos, event):
                    return

        elif event.type == pygame.MOUSEWHEEL:
            # Handle art dialogue scrolling first
            if (hasattr(self.game.renderer, 'show_art_dialogue') and
                    self.game.renderer.show_art_dialogue):
                mouse_pos = pygame.mouse.get_pos()
                if self.game.renderer.handle_art_dialogue_click(mouse_pos, event):
                    return

            # Handle highscore scrolling
            if self.game.show_highscores and hasattr(self.game.renderer, 'handle_highscore_scroll'):
                self.game.renderer.handle_highscore_scroll(event)
                return

            # Handle inventory scrolling if art dialogue didn't consume the event
            if self.game.show_inventory and hasattr(self.game.renderer, 'handle_inventory_scroll'):
                self.game.renderer.handle_inventory_scroll(event)

    def _handle_art_windows(self, event):
        """Handle art/painting window interactions (returns True if handled)"""
        art_display = getattr(self.game.renderer, 'art_display', None)
        if not art_display:
            return False

        mouse_pos = pygame.mouse.get_pos()

        # Check painting viewer first
        if art_display.show_painting_viewer:
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
                if art_display.handle_painting_viewer_click(mouse_pos, event):
                    return True

        # Then check art dialogue
        if art_display.show_art_dialogue:
            if art_display.handle_art_dialogue_click(mouse_pos, event):
                return True

        return False

    def _handle_keydown(self, key):
        """Handle key press events - MODIFIED: Added door dialogue handling"""

        if key == pygame.K_h:  # NEW: Toggle highscore window
            self.game.show_highscores = not self.game.show_highscores
            if self.game.show_highscores:
                # Close other menus when opening highscores
                self.game.show_inventory = False
                self.game.show_crafting = False
                self.game.show_player_stats = False
                self.game.show_dialogue = False

        elif key == pygame.K_i:
            self.game.show_inventory = not self.game.show_inventory
            if self.game.show_inventory:
                self.game.show_crafting = False
                self.game.show_player_stats = False
                self.game.show_highscores = False

        elif key == pygame.K_m:
            self.game.show_minimap = not self.game.show_minimap

        elif key == pygame.K_c:
            self.game.show_crafting = not self.game.show_crafting
            if self.game.show_crafting:
                self.game.show_inventory = False
                self.game.show_player_stats = False
                self.game.show_highscores = False

        elif key == pygame.K_g:
            self.game.show_player_stats = not self.game.show_player_stats
            if self.game.show_player_stats:
                self.game.show_inventory = False
                self.game.show_crafting = False
                self.game.show_highscores = False

        elif key == pygame.K_SPACE:
            if self.game.state == GameState.EXPLORATION:
                self._collect_trash()
            elif self.game.state == GameState.COMBAT:
                if self.game.combat.player_turn:
                    self.game.combat._player_attack()

        elif key == pygame.K_f and self.game.state == GameState.COMBAT:
            if self.game.combat.player_turn:
                self.game.combat._player_flee()


        elif key == pygame.K_x:
            if self.game.state == GameState.EXPLORATION:
                # NEW: First check if artifact message is showing and close it
                if (hasattr(self.game, 'show_artifact_message') and
                        self.game.show_artifact_message):
                    self.game.show_artifact_message = False
                elif self.game.show_dialogue:
                    # Close dialogue if it's open - clear door dialogue too
                    self.game.show_dialogue = False
                    self.current_interacting_npc = None
                    if hasattr(self.game, 'current_door_dialogue'):
                        self.game.current_door_dialogue = None
                else:
                    # Try to start dialogue with nearby NPC
                    self._interact_with_npc()

        # Zone switching (for debugging)
        elif key == pygame.K_1:
            self.game.current_zone = "Oozing Canal City"
        elif key == pygame.K_2:
            self.game.current_zone = "Forest of Rusting Trees"
        elif key == pygame.K_3:
            self.game.current_zone = "Wasteland Plains"

    def _interact_with_npc(self):
        """Handle NPC interaction with proper distance checking"""
        zone = self.game.get_current_zone()
        player_x = self.game.player.x
        player_y = self.game.player.y

        closest_npc = None
        closest_distance = float('inf')

        # Check all NPCs in the zone
        for npc, original_x, original_y in zone.npcs:
            # Use the NPC's current position (npc.x, npc.y) not the original spawn position
            npc_x = npc.x
            npc_y = npc.y

            # Calculate distance
            dx = player_x - npc_x
            dy = player_y - npc_y
            distance = math.sqrt(dx * dx + dy * dy)

            # Check if within interaction range
            if distance < DIALOGUE_RADIUS:
                if distance < closest_distance:
                    closest_distance = distance
                    closest_npc = npc

        # Start dialogue with the closest NPC
        if closest_npc:
            self.current_interacting_npc = closest_npc
            self.game.show_dialogue = True
            closest_npc.start_interaction()

    def _handle_crafting_click(self, pos):
        """Handle clicks in crafting menu - MODIFIED: Crafted items added at top"""
        if not hasattr(self.game.crafting, 'clickable_rects'):
            return False

        for recipe_name, rect in self.game.crafting.clickable_rects.items():
            if rect and rect.collidepoint(pos):
                if self.game.can_craft_item(recipe_name):
                    crafted_item = self.game.crafting.craft_item(recipe_name, self.game.player.inventory)
                    if crafted_item:
                        # MODIFIED: Add crafted items at the beginning for newest-first display
                        self.game.player.inventory.insert(0, crafted_item)
                        return True
        return False

    def handle_continuous_input(self):
        """Handle continuous input (movement keys held down) - REMOVED animation updates"""
        if self.game.state != GameState.EXPLORATION:
            return

        keys = pygame.key.get_pressed()
        current_speed = PLAYER_MOVEMENT_SPEED * (2 if self.game.speed_boost_active else 1)

        # Track movement directions for facing direction
        moving_right = keys[pygame.K_RIGHT] or keys[pygame.K_d]
        moving_left = keys[pygame.K_LEFT] or keys[pygame.K_a]
        moving_up = keys[pygame.K_UP] or keys[pygame.K_w]
        moving_down = keys[pygame.K_DOWN] or keys[pygame.K_s]

        # Update movement
        if moving_right:
            self.game.player.x += current_speed
        if moving_left:
            self.game.player.x -= current_speed
        if moving_up:
            self.game.player.y -= current_speed
        if moving_down:
            self.game.player.y += current_speed

        # Update facing direction only (not animation - that happens in main loop)
        self.game.player.update_movement_direction(moving_right, moving_left)

    def _collect_trash(self):
        """Handle trash collection with alien artifacts - MODIFIED: All new items added at top"""
        zone = self.game.get_current_zone()
        collected_items, zone_restored = zone.cleanup_trash(
            int(self.game.player.x),
            int(self.game.player.y),
            TRASH_COLLECTION_RADIUS
        )

        # Process collected items
        for item in collected_items:
            if isinstance(getattr(item, 'item_type', None),
                          (FoodType, ArtType)):  # Handle food and art (including alien artifacts)
                new_item = Item(
                    name=item.name,
                    item_type=item.item_type,
                    quantity=1,
                    description=item.description,
                    hp_bonus=getattr(item, 'hp_bonus', 0),
                    art_message=getattr(item, 'art_message', '')
                )

                # MODIFIED: Add all food and art items at the beginning for newest-first display
                self.game.player.inventory.insert(0, new_item)  # Insert at beginning

                # Special message for alien artifacts
                if hasattr(item, 'item_type') and item.item_type == ArtType.ALIEN_ARTIFACT:
                    # Count total artifacts
                    artifact_count = sum(1 for inv_item in self.game.player.inventory
                                         if hasattr(inv_item,
                                                    'item_type') and inv_item.item_type == ArtType.ALIEN_ARTIFACT)
            else:
                self._add_to_inventory_at_top(item)  # Use new method for top insertion

        if zone_restored:
            self.game._handle_zone_restored()

    def _add_to_inventory_at_top(self, item):
        """Add item to inventory at top (stack non-food/art items) - NEW: For newest-first display"""
        if getattr(item, 'item_type', None) in [FoodType.FRUIT, ArtType.POETRY]:  # Art items don't stack
            self.game.player.inventory.insert(0, item)  # Insert at beginning
            return

        # Stack existing non-food items (but insert at top if new)
        for inv_item in self.game.player.inventory:
            if (inv_item.name == item.name and
                    not isinstance(getattr(inv_item, 'item_type', None), FoodType) and
                    not isinstance(getattr(inv_item, 'item_type', None), ArtType)):  # Don't stack art
                inv_item.quantity += item.quantity
                return

        # Add new item at beginning if not found
        self.game.player.inventory.insert(0, item)

    def _handle_player_stats_click(self, pos):
        """Handle clicks in player stats menu"""
        if not self.game.show_player_stats:
            return False

        player = self.game.player

        # Check upgrade buttons
        for i in range(1, 4):  # HP(1), ATTACK(2), BLOCK(3)
            button_rect = getattr(self.game.renderer, f"upgrade_button_{i}_rect", None)
            if button_rect and button_rect.collidepoint(pos) and player.xp >= 100:
                if i == 1:  # HP upgrade
                    player.max_hp += 5
                    player.hp += 5
                elif i == 2:  # Attack upgrade
                    player.base_attack += 5
                elif i == 3:  # Block chance upgrade
                    player.block_chance = min(player.block_chance + 5, 100)  # Cap at 100%
                player.xp -= 100
                return True

        return False

    def _handle_inventory_click(self, pos):
        """Handle inventory clicks with proper Magic Pickle handling"""
        for item in self.game.player.inventory:
            if hasattr(item, 'rect') and item.rect and item.rect.collidepoint(pos):
                if item.is_equippable:
                    # Toggle equipment
                    if item in self.game.player.equipped_items:
                        self.game.player.unequip_item(item)
                    else:
                        self.game.player.equip_item(item)
                elif hasattr(item, 'item_type') and item.item_type == FoodType.FRUIT:
                    # Apple - restore HP
                    hp_restored = item.hp_bonus
                    self.game.player.hp = min(
                        self.game.player.hp + hp_restored,
                        self.game.player.max_hp
                    )
                    self.game.player.inventory.remove(item)
                elif hasattr(item, 'item_type') and item.item_type == FoodType.DOHNUT:
                    # Dohnut - restore HP
                    hp_restored = item.hp_bonus
                    self.game.player.hp = min(
                        self.game.player.hp + hp_restored,
                        self.game.player.max_hp
                    )
                    self.game.player.inventory.remove(item)
                elif hasattr(item, 'item_type') and item.item_type == FoodType.BREAD:
                    # Bread - only speed boost (22 seconds)
                    self.game.activate_speed_boost(22)
                    self.game.player.inventory.remove(item)
                elif hasattr(item, 'item_type') and item.item_type == FoodType.MAGIC_PICKLE:  # NEW
                    # Magic Pickle - full heal + extended speed boost (60 seconds)
                    old_hp = self.game.player.hp
                    self.game.player.hp = self.game.player.max_hp  # Full heal
                    hp_restored = self.game.player.max_hp - old_hp
                    self.game.activate_speed_boost(60)  # Double the duration of bread
                    self.game.player.inventory.remove(item)
                elif hasattr(item, 'item_type') and item.item_type == ArtType.POETRY:
                    # Handle poem click - ensure message is loaded
                    if not hasattr(item, 'art_message') or not item.art_message:
                        item._load_art_message()
                    self.game.renderer.art_display.show_art_item_dialogue(item)
                    break
                elif hasattr(item, 'item_type') and item.item_type == ArtType.PAINTING:
                    self.game.renderer.art_display.show_painting_item_viewer(item)
                    break
                elif hasattr(item, 'item_type') and item.item_type == ArtType.ALIEN_ARTIFACT:
                    # Handle alien artifact click - ensure message is loaded
                    if not hasattr(item, 'art_message') or not item.art_message:
                        item._load_alien_artifact_message()
                    self.game.renderer.art_display.show_art_item_dialogue(item)
                    break