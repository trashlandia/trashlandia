# systems/save_system.py
"""
Save/Load System for preserving zone restoration progress
"""
import json
import os
from typing import Dict, Set


class SaveSystem:
    """Handles saving and loading game progress"""

    def __init__(self):
        self.save_file_path = "game_progress.json"
        self.default_save_data = {
            "restored_zones": [],
            "unlocked_doors": [],
            "player_level": 1,
            "player_xp": 0,
            "player_max_hp": 100,
            "player_base_attack": 10,
            "player_block_chance": 40
        }

    def save_progress(self, game):
        """Save current game progress"""
        try:
            save_data = {
                "restored_zones": [zone_name for zone_name, zone in game.zones.items() if zone.is_restored],
                "unlocked_doors": self._get_unlocked_doors(game),
                "player_level": game.player.level,
                "player_xp": game.player.xp,
                "player_max_hp": game.player.max_hp,
                "player_base_attack": game.player.base_attack,
                "player_block_chance": game.player.block_chance
            }

            with open(self.save_file_path, 'w') as f:
                json.dump(save_data, f, indent=2)

            return True

        except Exception as e:
            print(f"Error saving progress: {e}")
            return False

    def load_progress(self, game):
        """Load saved game progress"""
        try:
            if not os.path.exists(self.save_file_path):
                return False

            with open(self.save_file_path, 'r') as f:
                save_data = json.load(f)

            # Restore zone states
            for zone_name in save_data.get("restored_zones", []):
                if zone_name in game.zones:
                    game.zones[zone_name].is_restored = True
                    # Clear remaining trash/enemies in restored zones
                    game.zones[zone_name].trash_items = []
                    game.zones[zone_name].enemies = []

            # Restore player stats
            game.player.level = save_data.get("player_level", 1)
            game.player.xp = save_data.get("player_xp", 0)
            game.player.max_hp = save_data.get("player_max_hp", 100)
            game.player.hp = game.player.max_hp  # Full health on respawn
            game.player.base_attack = save_data.get("player_base_attack", 10)
            game.player.block_chance = save_data.get("player_block_chance", 40)

            return True

        except Exception as e:
            print(f"Error loading progress: {e}")
            return False

    def _get_unlocked_doors(self, game):
        """Get list of doors that should be unlocked based on progress"""
        unlocked = ["Train Station"]  # Train station is always accessible

        # Add doors for restored zones
        for zone_name, zone in game.zones.items():
            if zone.is_restored:
                unlocked.append(zone_name)

        return unlocked

    def clear_save(self):
        """Clear save file (for new game)"""
        try:
            if os.path.exists(self.save_file_path):
                os.remove(self.save_file_path)
                return True
        except Exception as e:
            print(f"Error clearing save: {e}")
            return False