# systems/crafting.py
import random
import pygame
from typing import List, Dict, Optional
from config.settings import *
from models.item import Item


class CraftingSystem:
    """Handles item crafting, recipes, and crafting UI"""

    def __init__(self):
        self.recipes = self._initialize_recipes()

    def _initialize_recipes(self):
        """Initialize all crafting recipes organized by material type"""
        recipes = {
            # Metal recipes
            "Spoon": {
                "materials": {TrashType.METAL: 3},
                "hp_bonus": 0,
                "attack_bonus": 1,
                "description": "Spoon from recycled metal (+1 Attack)"
            },
            "Boots": {
                "materials": {TrashType.METAL: 8},
                "hp_bonus": 5,
                "attack_bonus": 2,
                "description": "Reinforced footwear (+5 HP, +2 Attack)"
            },
            "Helmet": {
                "materials": {TrashType.METAL: 10},
                "hp_bonus": 8,
                "attack_bonus": 0,
                "description": "Protective headgear (+8 HP)"
            },
            "Spear": {
                "materials": {TrashType.METAL: 13},
                "hp_bonus": 0,
                "attack_bonus": 11,
                "description": "Spear from recycled metal (+11 Attack)"
            },
            "Sword": {
                "materials": {TrashType.METAL: 16},
                "hp_bonus": 0,
                "attack_bonus": 15,
                "description": "Sword from recycled metal (+15 Attack)"
            },
            "Club": {
                "materials": {TrashType.METAL: 19},
                "hp_bonus": 0,
                "attack_bonus": 18,
                "description": "Heavy blunt weapon (+18 Attack)"
            },
            "Chainmail": {
                "materials": {TrashType.METAL: 25},
                "hp_bonus": 19,
                "attack_bonus": 0,
                "description": "Flexible armor (+19 HP)"
            },

            # Glass recipes
            "Shank": {
                "materials": {TrashType.GLASS: 3},
                "hp_bonus": 0,
                "attack_bonus": 1,
                "description": "Sharp chunk of glass (+1 Attack)"
            },
            "Arrow": {
                "materials": {TrashType.GLASS: 7},
                "hp_bonus": 0,
                "attack_bonus": 4,
                "description": "Glass sharp arrow (+4 Attack)"
            },
            "Dagger": {
                "materials": {TrashType.GLASS: 8},
                "hp_bonus": 0,
                "attack_bonus": 5,
                "description": "Razor-sharp glass blade (+5 Attack)"
            },
            "Gem": {
                "materials": {TrashType.GLASS: 9},
                "hp_bonus": 5,
                "attack_bonus": 0,
                "description": "Small healing gemstone (+5 HP)"
            },
            "Prism": {
                "materials": {TrashType.GLASS: 15},
                "hp_bonus": 10,
                "attack_bonus": 3,
                "description": "Glass shield (+10 HP, +3 Attack)"
            },
            "Shiny-Armor": {
                "materials": {TrashType.GLASS: 17},
                "hp_bonus": 15,
                "attack_bonus": 0,
                "description": "Translucent protective armor (+15 HP)"
            },
            "Crystal": {
                "materials": {TrashType.GLASS: 18},
                "hp_bonus": 10,
                "attack_bonus": 15,
                "description": "Large healing gemstone (+10 HP, +15 Attack)"
            },

            # Plastic recipes
            "Stun Dart": {
                "materials": {TrashType.PLASTIC: 3},
                "hp_bonus": 0,
                "attack_bonus": 1,
                "description": "Light projectile (+1 Attack)"
            },
            "Spikes": {
                "materials": {TrashType.PLASTIC: 5},
                "hp_bonus": 0,
                "attack_bonus": 2,
                "description": "Plastic sharp rods (+2 Attack)"
            },
            "Shield": {
                "materials": {TrashType.PLASTIC: 7},
                "hp_bonus": 5,
                "attack_bonus": 0,
                "description": "Plastic shield (+5 HP)"
            },
            "Crossbow": {
                "materials": {TrashType.PLASTIC: 11},
                "hp_bonus": 0,
                "attack_bonus": 5,
                "description": "Ranged weapon (+5 Attack)"
            },
            "Raincoat": {
                "materials": {TrashType.PLASTIC: 12},
                "hp_bonus": 7,
                "attack_bonus": 0,
                "description": "Water-resistant coat (+7 HP)"
            },
            "Bomb": {
                "materials": {TrashType.PLASTIC: 15},
                "hp_bonus": 0,
                "attack_bonus": 8,
                "description": "Explosive throwable (+8 Attack)"
            },
            "Goggles": {
                "materials": {TrashType.PLASTIC: 18},
                "hp_bonus": 13,
                "attack_bonus": 0,
                "description": "Impact-resistant eyewear (+13 HP)"
            },

            # Paper recipes
            "Papercut": {
                "materials": {TrashType.PAPER: 5},
                "hp_bonus": 0,
                "attack_bonus": 1,
                "description": "Sharp folded paper (+1 Attack)"
            },
            "Lantern": {
                "materials": {TrashType.PAPER: 6},
                "hp_bonus": 4,
                "attack_bonus": 0,
                "description": "Guiding light (+4 HP)"
            },
            "Paper Hat": {
                "materials": {TrashType.PAPER: 7},
                "hp_bonus": 5,
                "attack_bonus": 0,
                "description": "Healing hat (+5 HP)"
            },
            "Magic Spell": {
                "materials": {TrashType.PAPER: 8},
                "hp_bonus": 3,
                "attack_bonus": 2,
                "description": "Deceptively strong (+3 HP, +2 Attack)"
            },
            "Origami": {
                "materials": {TrashType.PAPER: 11},
                "hp_bonus": 0,
                "attack_bonus": 6,
                "description": "Folded sharp edges (+6 Attack)"
            },
            "Talisman": {
                "materials": {TrashType.PAPER: 13},
                "hp_bonus": 5,
                "attack_bonus": 5,
                "description": "Magical charm (+5 HP, +5 Attack)"
            },
            "Scroll": {
                "materials": {TrashType.PAPER: 17},
                "hp_bonus": 8,
                "attack_bonus": 8,
                "description": "Ancient knowledge (+8 HP, +8 Attack)"
            },

            # Combo recipes (multiple materials)
            "Bio Filter": {
                "materials": {TrashType.GLASS: 11, TrashType.PLASTIC: 12},
                "hp_bonus": 17,
                "attack_bonus": 0,
                "description": "Protective filter (+17 HP)"
            },
            "Hybrid Shield": {
                "materials": {TrashType.METAL: 19, TrashType.GLASS: 19},
                "hp_bonus": 25,
                "attack_bonus": 0,
                "description": "Extra strong defense (+18 HP)"
            },
            "Omni-Shield": {
                "materials": {TrashType.METAL: 20, TrashType.PLASTIC: 19},
                "hp_bonus": 30,
                "attack_bonus": 0,
                "description": "Extra strong defense (+30 HP)"
            },
            "Guardian": {
                "materials": {TrashType.GLASS: 23, TrashType.PAPER: 25},
                "hp_bonus": 50,
                "attack_bonus": 20,
                "description": "Health and attack (+50 HP, +20 Attack)"
            },
            "Double Bow": {
                "materials": {TrashType.PLASTIC: 24, TrashType.GLASS: 24},
                "hp_bonus": 0,
                "attack_bonus": 60,
                "description": "Twice the bow (+60 Attack)"
            },
            "Eco-Blade": {
                "materials": {TrashType.METAL: 24, TrashType.PLASTIC: 24},
                "hp_bonus": 0,
                "attack_bonus": 90,
                "description": "Recycled strong blade (+90 Attack)"
            },
            "Hot Blade": {
                "materials": {TrashType.METAL: 25, TrashType.GLASS: 25},
                "hp_bonus": 0,
                "attack_bonus": 150,
                "description": "Sword with sticky plastic (+150 Attack)"
            }
        }

        # Convert to the internal format used by the crafting system
        formatted_recipes = {}
        for name, data in recipes.items():
            formatted_recipes[name] = {
                "materials": data["materials"],
                "result": Item(
                    name=name,
                    description=data["description"],
                    is_equippable=True,
                    hp_bonus=data["hp_bonus"],
                    attack_bonus=data["attack_bonus"]
                ),
                "rect": None
            }
        return formatted_recipes

    def categorize_recipes(self) -> Dict[str, List[tuple]]:
        """Categorize recipes for display in crafting menu"""
        categories = {category: [] for category in CRAFTING_CATEGORIES}

        for recipe_name, recipe_data in self.recipes.items():
            materials = recipe_data["materials"]
            material_types = set(materials.keys())

            if len(material_types) > 1:
                categories["Combo"].append((recipe_name, recipe_data))
            else:
                material_type = next(iter(material_types))
                if material_type == TrashType.METAL:
                    categories["Metal"].append((recipe_name, recipe_data))
                elif material_type == TrashType.GLASS:
                    categories["Glass"].append((recipe_name, recipe_data))
                elif material_type == TrashType.PLASTIC:
                    categories["Plastic"].append((recipe_name, recipe_data))
                elif material_type == TrashType.PAPER:
                    categories["Paper"].append((recipe_name, recipe_data))

        return categories

    def draw_crafting_menu(self, screen: pygame.Surface, fonts: Dict[str, pygame.font.Font],
                           player_inventory: List[Item]) -> Dict[str, pygame.Rect]:
        """Draw the crafting menu overlay and return clickable rects"""
        font = fonts['normal']
        font_small = fonts['small']
        font_tiny = fonts['tiny']

        # Semi-transparent overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(180)
        overlay.fill(BLACK)
        screen.blit(overlay, (0, 0))

        panel_width, panel_height = CRAFTING_PANEL_SIZE
        panel_rect = pygame.Rect(0, 0, panel_width, panel_height)
        panel_rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        pygame.draw.rect(screen, UI_COLORS['panel_bg'], panel_rect)
        pygame.draw.rect(screen, WHITE, panel_rect, 3)

        # Title
        title = font.render("CRAFTING", True, WHITE)
        screen.blit(title, (panel_rect.centerx - title.get_width() // 2, panel_rect.y + 15))

        # Get categorized recipes
        categories = self.categorize_recipes()

        # Grid settings - 5 columns (one for each category)
        column_width = (panel_rect.width - 60) // 5
        start_x = panel_rect.x + 30
        start_y = panel_rect.y + 60
        item_height = 60  # Reduced from 70 to fit more items
        items_per_column = 7  # Now showing all 7 items
        vertical_spacing = 5  # Reduced spacing between items

        # Store clickable rects in instance variable
        self.clickable_rects = {}

        # Draw category columns
        for i, (category_name, recipes) in enumerate(categories.items()):
            column_x = start_x + i * column_width

            # Draw category header
            header = font_small.render(category_name, True, WHITE)
            screen.blit(header, (column_x + (column_width - header.get_width()) // 2, start_y))

            # Draw recipes in this category
            for j, (recipe_name, recipe_data) in enumerate(recipes):
                item_y = start_y + 30 + j * (item_height + vertical_spacing)

                # Check if recipe fits in panel (now showing all 7)
                if j >= items_per_column:
                    break

                # Check if craftable
                can_craft = self.can_craft(recipe_name, player_inventory)
                item_color = UI_COLORS['craftable'] if can_craft else UI_COLORS['not_craftable']

                # Draw recipe box
                item_rect = pygame.Rect(column_x, item_y, column_width - 20, item_height)
                pygame.draw.rect(screen, item_color, item_rect)
                pygame.draw.rect(screen, BLACK, item_rect, 1)

                # Store rect for click detection
                self.clickable_rects[recipe_name] = item_rect
                recipe_data["rect"] = item_rect  # Also store in recipe data

                # Draw recipe content
                self._draw_recipe_item(screen, item_rect, recipe_name, recipe_data, font_tiny)

        # Instructions
        instruction = font_tiny.render("Press C to close | Click item to craft", True, WHITE)
        screen.blit(instruction, (panel_rect.x + 20, panel_rect.bottom - 30))

        return self.clickable_rects

    def _draw_recipe_item(self, screen: pygame.Surface, item_rect: pygame.Rect,
                          recipe_name: str, recipe_data: Dict, font_tiny):
        """Draw individual recipe item in crafting menu"""
        # Recipe name (truncate if too long)
        name = recipe_name if len(recipe_name) < 12 else recipe_name[:10] + "..."
        name_surf = font_tiny.render(name, True, BLACK)
        screen.blit(name_surf, (item_rect.x + 10, item_rect.y + 8))

        # Materials needed
        materials_text = ", ".join([f"{v} {k.value}" for k, v in recipe_data["materials"].items()])
        # Truncate materials text if too long
        if len(materials_text) > 25:
            materials_text = materials_text[:22] + "..."
        mats_surf = font_tiny.render(materials_text, True, BLACK)
        screen.blit(mats_surf, (item_rect.x + 10, item_rect.y + 25))

        # Show bonuses
        result_item = recipe_data["result"]
        bonus_text = []
        if result_item.hp_bonus > 0:
            bonus_text.append(f"+{result_item.hp_bonus}HP")
        if result_item.attack_bonus > 0:
            bonus_text.append(f"+{result_item.attack_bonus}ATK")

        if bonus_text:
            bonus_str = " ".join(bonus_text)
            bonus_surf = font_tiny.render(bonus_str, True, BLACK)
            screen.blit(bonus_surf, (item_rect.x + 10, item_rect.y + 42))

    def handle_crafting_click(self, pos: tuple, player_inventory: List[Item]) -> Optional[str]:
        """Handle clicks in crafting menu and return crafted item name if successful"""
        for recipe_name, recipe_data in self.recipes.items():
            if "rect" in recipe_data and recipe_data["rect"] and recipe_data["rect"].collidepoint(pos):
                if self.craft_item(recipe_name, player_inventory):
                    print(f"Successfully crafted {recipe_name}")
                    return recipe_name
                else:
                    print(f"Cannot craft {recipe_name} - insufficient materials")
                    return None
        return None

    def get_recipe_tooltip(self, recipe_name: str) -> List[str]:
        """Get tooltip information for a recipe"""
        if recipe_name not in self.recipes:
            return []

        recipe_data = self.recipes[recipe_name]
        result_item = recipe_data["result"]

        tooltip = [
            recipe_name,
            result_item.description,
            "",
            "Materials needed:"
        ]

        for material, amount in recipe_data["materials"].items():
            tooltip.append(f"  {amount} {material.value}")

        tooltip.append("")
        tooltip.append("Bonuses:")
        if result_item.hp_bonus > 0:
            tooltip.append(f"  +{result_item.hp_bonus} HP")
        if result_item.attack_bonus > 0:
            tooltip.append(f"  +{result_item.attack_bonus} Attack")

        return tooltip

    def get_craftable_count(self, recipe_name: str, inventory: List[Item]) -> int:
        """Get how many times a recipe can be crafted with current inventory"""
        if recipe_name not in self.recipes:
            return 0

        material_counts = self._count_materials(inventory)
        recipe_materials = self.recipes[recipe_name]["materials"]

        max_craftable = float('inf')
        for material, needed in recipe_materials.items():
            available = material_counts.get(material, 0)
            max_craftable = min(max_craftable, available // needed)

        return int(max_craftable) if max_craftable != float('inf') else 0

    def can_craft(self, recipe_name: str, inventory: List[Item]) -> bool:
        """Check if a recipe can be crafted with current inventory"""
        if recipe_name not in self.recipes:
            return False

        material_counts = self._count_materials(inventory)
        return all(material_counts.get(mat, 0) >= needed
                   for mat, needed in self.recipes[recipe_name]["materials"].items())

    def craft_item(self, recipe_name: str, inventory: List[Item]) -> Optional[Item]:
        """Craft an item, consuming materials from inventory"""
        if not self.can_craft(recipe_name, inventory):
            return None

        for material, needed in self.recipes[recipe_name]["materials"].items():
            self._consume_materials(inventory, material, needed)

        result = self.recipes[recipe_name]["result"]
        return Item(name=result.name, description=result.description, is_equippable=result.is_equippable,
                    hp_bonus=result.hp_bonus, attack_bonus=result.attack_bonus)

    def _count_materials(self, inventory: List[Item]) -> Dict[TrashType, int]:
        """Count available materials in inventory"""
        counts = {}
        for item in inventory:
            if isinstance(getattr(item, 'item_type', None), TrashType):
                counts[item.item_type] = counts.get(item.item_type, 0) + item.quantity
        return counts

    def _consume_materials(self, inventory: List[Item], material: TrashType, amount: int):
        """Remove specified amount of material from inventory"""
        remaining, to_remove = amount, []

        for item in inventory:
            if getattr(item, 'item_type', None) == material and remaining > 0:
                if item.quantity <= remaining:
                    remaining -= item.quantity
                    to_remove.append(item)
                else:
                    item.quantity -= remaining
                    remaining = 0

        for item in to_remove:
            inventory.remove(item)

    def get_materials_summary(self, inventory: List[Item]) -> Dict[TrashType, int]:
        """Get a summary of available crafting materials"""
        return self._count_materials(inventory)

    def get_recipes_by_availability(self, inventory: List[Item]) -> Dict[str, List[str]]:
        """Get recipes categorized by whether they can be crafted"""
        craftable = []
        not_craftable = []

        for recipe_name in self.recipes:
            if self.can_craft(recipe_name, inventory):
                craftable.append(recipe_name)
            else:
                not_craftable.append(recipe_name)

        return {
            'craftable': craftable,
            'not_craftable': not_craftable
        }