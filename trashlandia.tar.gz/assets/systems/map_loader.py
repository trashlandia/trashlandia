# systems/map_loader.py
import os
import traceback
import pygame
from config.settings import ASSET_SEARCH_PATHS, SCREEN_WIDTH, SCREEN_HEIGHT

try:
    import pytmx
except ImportError:
    pytmx = None
    print("[MAP] ERROR: pytmx is not installed - maps will use the fallback background. "
          "For the web build, add 'pytmx' to the dependencies block at the top of main.py")


class MapLoader:
    def __init__(self, filename):
        self.filename = filename
        self.tmx_data = None
        self.width = 4000  # Default fallback
        self.height = 3000  # Default fallback
        self.world_boundary = pygame.Rect(0, 0, self.width, self.height)
        self._load_map()

    def _load_map(self):
        """Load map from various possible paths with web compatibility"""
        if not self.filename:
            return

        if pytmx is None:
            return

        found_any = False
        for path_prefix in ASSET_SEARCH_PATHS:
            full_path = os.path.join(path_prefix, self.filename)
            if not os.path.exists(full_path):
                continue

            found_any = True
            try:
                self.tmx_data = pytmx.load_pygame(full_path)
                self.width = self.tmx_data.width * self.tmx_data.tilewidth
                self.height = self.tmx_data.height * self.tmx_data.tileheight
                self.world_boundary = pygame.Rect(0, 0, self.width, self.height)
                print(f"[MAP] Loaded: {full_path}")
                return
            except Exception as e:
                # File exists but failed to parse - usually a bad tileset image path
                print(f"[MAP] ERROR parsing {full_path}: {e}")
                traceback.print_exc()

        if not found_any:
            print(f"[MAP] File not found: {self.filename} (searched {ASSET_SEARCH_PATHS})")
        else:
            print(f"[MAP] Found {self.filename} but could not load it - see error above")

    def draw(self, surface, camera):
        """Draw only the tiles that are visible on screen"""
        if not self.tmx_data:
            self._draw_fallback_background(surface, camera)
            return

        tw = self.tmx_data.tilewidth
        th = self.tmx_data.tileheight
        cam_x = int(camera.x)
        cam_y = int(camera.y)

        # Range of tile columns/rows that are on screen
        start_x = max(0, cam_x // tw)
        start_y = max(0, cam_y // th)
        end_x = min(self.tmx_data.width, (cam_x + SCREEN_WIDTH) // tw + 2)
        end_y = min(self.tmx_data.height, (cam_y + SCREEN_HEIGHT) // th + 2)

        get_image = self.tmx_data.get_tile_image_by_gid

        for layer in self.tmx_data.visible_layers:
            if not hasattr(layer, 'data'):  # skip object/image layers
                continue
            rows = layer.data
            for y in range(start_y, end_y):
                row = rows[y]
                for x in range(start_x, end_x):
                    gid = row[x]
                    if gid:
                        tile = get_image(gid)
                        if tile:
                            surface.blit(tile, (x * tw - cam_x, y * th - cam_y))

    def _draw_fallback_background(self, surface, camera):
        """Draw a simple background when no map is loaded"""
        # Create a simple gradient background
        for y in range(0, SCREEN_HEIGHT, 2):
            color_value = 50 + (y // 3) % 50
            color = (color_value // 2, color_value, color_value // 3)
            pygame.draw.line(surface, color, (0, y), (SCREEN_WIDTH, y))

        # Draw a grid pattern
        grid_color = (100, 100, 100, 50)
        for x in range(0, SCREEN_WIDTH, 50):
            adjusted_x = x - (camera.x % 50)
            pygame.draw.line(surface, grid_color, (adjusted_x, 0), (adjusted_x, SCREEN_HEIGHT), 1)

        for y in range(0, SCREEN_HEIGHT, 50):
            adjusted_y = y - (camera.y % 50)
            pygame.draw.line(surface, grid_color, (0, adjusted_y), (SCREEN_WIDTH, adjusted_y), 1)