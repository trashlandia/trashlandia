# systems/camera.py
"""Camera System - Handles camera movement and viewport management"""
from config.settings import SCREEN_WIDTH, SCREEN_HEIGHT

class Camera:
    """Camera system that follows the player and manages the viewport"""

    def __init__(self):
        self.x = self.y = self.target_x = self.target_y = 0
        self.smoothing = 0.1

    def update(self, target_x, target_y):
        """Update camera position to follow target"""
        self.target_x = target_x - SCREEN_WIDTH // 2
        self.target_y = target_y - SCREEN_HEIGHT // 2

        # Snap immediately for zone transitions, smooth otherwise
        if abs(self.target_x - self.x) > SCREEN_WIDTH or abs(self.target_y - self.y) > SCREEN_HEIGHT:
            self.x, self.y = self.target_x, self.target_y
        else:
            self.x += (self.target_x - self.x) * self.smoothing
            self.y += (self.target_y - self.y) * self.smoothing

    def apply(self, x, y):
        """Apply camera offset to world coordinates to get screen coordinates"""
        return int(x - self.x), int(y - self.y)

    def apply_rect(self, rect):
        """Apply camera offset to a pygame Rect"""
        return rect.move(-int(self.x), -int(self.y))

    def get_offset(self):
        """Get current camera offset"""
        return int(self.x), int(self.y)