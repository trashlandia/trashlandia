# systems/highscore_system.py
"""
Highscore System - Manages player names, game timing, and highscore storage
FIXED: Timer continues running when respawning at train station, only resets on new game
"""
import json
import os
import time
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict


@dataclass
class HighscoreEntry:
    """Represents a single highscore entry"""
    player_name: str
    completion_time: float  # Time in seconds
    player_hp: int
    player_attack: int
    timestamp: str  # When the score was achieved

    def get_formatted_time(self) -> str:
        """Get formatted time string (MM:SS)"""
        minutes = int(self.completion_time // 60)
        seconds = int(self.completion_time % 60)
        return f"{minutes:02d}:{seconds:02d}"


class HighscoreSystem:
    """Handles highscore tracking, storage, and display"""

    def __init__(self):
        self.highscore_file = "highscores.json"
        self.start_time = None
        self.paused_time = 0  # NEW: Track total paused time
        self.pause_start_time = None  # NEW: Track when pause started
        self.is_paused = False  # NEW: Track if timer is currently paused
        self.player_name = ""
        self.highscores: List[HighscoreEntry] = []
        self.load_highscores()

    def start_game_timer(self):
        """Start timing the game from the beginning"""
        self.start_time = time.time()
        self.paused_time = 0  # Reset paused time for new game
        self.pause_start_time = None
        self.is_paused = False

    def pause_timer(self):
        """Pause the game timer (when player dies)"""
        if not self.start_time or self.is_paused:
            return

        self.pause_start_time = time.time()
        self.is_paused = True

    def resume_timer(self):
        """Resume the game timer (when respawning at train station)"""
        if not self.start_time or not self.is_paused:
            return

        if self.pause_start_time:
            # Add the time spent paused to our total paused time
            self.paused_time += time.time() - self.pause_start_time

        self.pause_start_time = None
        self.is_paused = False

    def set_player_name(self, name: str):
        """Set the current player's name"""
        self.player_name = name.strip()[:20]  # Limit to 20 characters
        if not self.player_name:
            self.player_name = "Anonymous"

    def record_victory(self, player_hp: int, player_attack: int) -> bool:
        """Record a victory when boss is defeated"""
        if not self.start_time:
            return False

        # Calculate actual game time (excluding paused time)
        current_time = time.time()
        if self.is_paused and self.pause_start_time:
            # If currently paused, don't count the current pause period
            completion_time = self.pause_start_time - self.start_time - self.paused_time
        else:
            # Normal case - total time minus paused periods
            completion_time = current_time - self.start_time - self.paused_time

        # Create new highscore entry
        entry = HighscoreEntry(
            player_name=self.player_name,
            completion_time=completion_time,
            player_hp=player_hp,
            player_attack=player_attack,
            timestamp=time.strftime("%Y-%m-%d %H:%M:%S")
        )

        # Add to highscores and sort
        self.highscores.append(entry)
        self.sort_highscores()

        # Save to file
        success = self.save_highscores()

        if success:
            print(f"New highscore recorded! Time: {entry.get_formatted_time()}")

        return success

    def sort_highscores(self):
        """Sort highscores by completion time (fastest first)"""
        self.highscores.sort(key=lambda x: x.completion_time)

    def get_top_scores(self, limit: int = 50) -> List[HighscoreEntry]:
        """Get top N highscores"""
        return self.highscores[:limit]

    def get_player_rank(self) -> Optional[int]:
        """Get current player's best rank (1-based)"""
        if not self.player_name:
            return None

        for i, entry in enumerate(self.highscores, 1):
            if entry.player_name == self.player_name:
                return i
        return None

    def load_highscores(self) -> bool:
        """Load highscores from file"""
        try:
            if not os.path.exists(self.highscore_file):
                self.highscores = []
                return True

            with open(self.highscore_file, 'r') as f:
                data = json.load(f)

            self.highscores = []
            for item in data:
                entry = HighscoreEntry(**item)
                self.highscores.append(entry)

            self.sort_highscores()
            return True

        except Exception as e:
            print(f"Error loading highscores: {e}")
            self.highscores = []
            return False

    def save_highscores(self) -> bool:
        """Save highscores to file"""
        try:
            # Keep only top 100 scores to prevent file from growing too large
            top_scores = self.highscores[:100]

            data = [asdict(entry) for entry in top_scores]

            with open(self.highscore_file, 'w') as f:
                json.dump(data, f, indent=2)

            return True

        except Exception as e:
            print(f"Error saving highscores: {e}")
            return False

    def reset_timer(self):
        """Reset the game timer completely (for new game only)"""
        self.start_time = None
        self.paused_time = 0
        self.pause_start_time = None
        self.is_paused = False

    def get_current_game_time(self) -> Optional[float]:
        """Get current game time if timer is running (excluding paused time)"""
        if not self.start_time:
            return None

        current_time = time.time()

        if self.is_paused and self.pause_start_time:
            # If currently paused, don't count the current pause period
            return self.pause_start_time - self.start_time - self.paused_time
        else:
            # Normal case - total time minus paused periods
            return current_time - self.start_time - self.paused_time

    def get_formatted_current_time(self) -> str:
        """Get formatted current game time"""
        current_time = self.get_current_game_time()
        if current_time:
            minutes = int(current_time // 60)
            seconds = int(current_time % 60)
            return f"{minutes:02d}:{seconds:02d}"
        return "00:00"