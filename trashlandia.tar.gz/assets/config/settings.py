# config/settings.py
"""Game Configuration and Constants"""
from enum import Enum

# Screen & Performance
SCREEN_WIDTH, SCREEN_HEIGHT, FPS = 1024, 768, 60

# Colors
BLACK, WHITE, GREEN, BROWN = (0, 0, 0), (255, 255, 255), (34, 139, 34), (139, 69, 19)
BLUE, RED, YELLOW, GRAY = (30, 144, 255), (220, 20, 60), (255, 215, 0), (128, 128, 128)
DARK_GREEN, PURPLE = (0, 100, 0), (147, 112, 219)
DOOR_COLOR = (150, 75, 0)

# Game Balance
PLAYER_MOVEMENT_SPEED = 3
TRASH_COLLECTION_RADIUS, COMBAT_COLLISION_RADIUS, DIALOGUE_RADIUS = 30, 40, 30
XP_PER_LEVEL, HP_GAIN_PER_LEVEL = 5, 25
ZONE_RESTORATION_THRESHOLD = 0.8

# Zone enemy configurations - UPDATED: Added 5 new zones (4-8)
ZONE_ENEMY_CONFIG = {
    # Zone 1: Oozing Canal City
    1: {
        'base_hp': 80,
        'hp_per_level': 20,
        'base_attack': 8,
        'attack_per_level': 2,
        'base_speed': 0.8,
        'speed_per_level': 0.1,
        'speed_multiplier': 2.0
    },
    # Zone 2: Forest of Rusting Trees
    2: {
        'base_hp': 200,
        'hp_per_level': 5,
        'base_attack': 12,
        'attack_per_level': 3,
        'base_speed': 1.0,
        'speed_per_level': 0.15,
        'speed_multiplier': 2.5
    },
    # Zone 3: Wasteland Plains
    3: {
        'base_hp': 600,
        'hp_per_level': 8,
        'base_attack': 20,
        'attack_per_level': 7,
        'base_speed': 1.2,
        'speed_per_level': 0.2,
        'speed_multiplier': 3.0
    },
    # Zone 4: Toxic Swamplands - NEW
    4: {
        'base_hp': 900,
        'hp_per_level': 8,
        'base_attack': 27,
        'attack_per_level': 7,
        'base_speed': 1.4,
        'speed_per_level': 0.3,
        'speed_multiplier': 3.0
    },
    # Zone 5: Burning Deserts - NEW
    5: {
        'base_hp': 1000,
        'hp_per_level': 9,
        'base_attack': 33,
        'attack_per_level': 7,
        'base_speed': 1.5,
        'speed_per_level': 0.3,
        'speed_multiplier': 3.0
    },
    # Zone 6: Frozen Wasteland - NEW
    6: {
        'base_hp': 1600,
        'hp_per_level': 9,
        'base_attack': 45,
        'attack_per_level': 12,
        'base_speed': 1.6,
        'speed_per_level': 0.3,
        'speed_multiplier': 3
    },
    # Zone 7: Volcanic Peaks - NEW
    7: {
        'base_hp': 2200,
        'hp_per_level': 9,
        'base_attack': 50,
        'attack_per_level': 12,
        'base_speed': 1.5,
        'speed_per_level': 0.4,
        'speed_multiplier': 3
    },
    # Zone 8: Dark Abyss - NEW
    8: {
        'base_hp': 3400,
        'hp_per_level': 9,
        'base_attack': 60,
        'attack_per_level': 12,
        'base_speed': 1.6,
        'speed_per_level': 0.4,
        'speed_multiplier': 3
    },
    # Special Zone (Boss zone uses zone 3 config but with 4x stats)
    10: {
        'base_hp': 1800 * 6,
        'hp_per_level': 200 * 6,
        'base_attack': 10 * 2,
        'attack_per_level': 1 * 2,
        'base_speed': 1.2 * 0.25,  # Slower movement
        'speed_per_level': 0.2 * 0.25,
        'speed_multiplier': 3.0
    }
}

# Trash & food spawn configuration
TRASH_BASE_DENSITY = 20
TRASH_DENSITY_PER_LEVEL = 0
FOOD_BASE_CHANCE = 0.3
FOOD_CHANCE_PER_LEVEL = 0.0
NPC_BASE_COUNT = 4
NPC_COUNT_PER_DENSITY = 0

# UI constants
UI_PANEL_PADDING = 20
INVENTORY_PANEL_SIZE = (SCREEN_WIDTH - 100, SCREEN_HEIGHT - 100)
CRAFTING_PANEL_SIZE = (SCREEN_WIDTH - 200, SCREEN_HEIGHT - 150)
STATS_PANEL_SIZE = (SCREEN_WIDTH - 200, SCREEN_HEIGHT - 450)
DIALOGUE_PANEL_SIZE = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)

# UI Layout Constants
MINIMAP_SIZE = (300, 100)
MINIMAP_POSITION = ((SCREEN_WIDTH - 300) // 2, 20)
INVENTORY_GRID_SETTINGS = {
    'item_height': 35,
    'section_padding': 15,
    'max_items_visible': 15
}

# UI Colors
UI_COLORS = {
    'panel_bg': (70, 70, 80),
    'overlay_bg': (0, 0, 0, 180),
    'equipped_item': YELLOW,
    'craftable': GREEN,
    'not_craftable': RED,
    'scroll_bar': (60, 60, 60),
    'scroll_thumb': (150, 150, 150),
    'light_gray': (220, 220, 220),
    'special_door': (255, 165, 0)  # Orange color for special door
}

# Combat UI Constants
COMBAT_UI = {
    'button_size': (220, 60),
    'button_gap': lambda: (SCREEN_WIDTH - (3 * 220)) // 4,
    'button_y': SCREEN_HEIGHT - 150,
    'health_bar_size': (120, 12),
    'log_size': (400, 150),
    'log_position': lambda: ((SCREEN_WIDTH - 400) // 2, SCREEN_HEIGHT - 280),
    'stats_panel_size': (200, 120),
    'boss_health_bar_size': (300, 20)  # Larger health bar for boss
}

# Font Sizes (for consistent UI)
FONT_SIZES = {
    'large': 72,
    'normal': 36,
    'small': 24,
    'tiny': 18
}

# Crafting Categories
CRAFTING_CATEGORIES = ["Metal", "Glass", "Plastic", "Paper", "Combo"]

class GameState(Enum):
    MENU, EXPLORATION, COMBAT, INVENTORY, DIALOGUE, GAME_OVER, TRAIN_TRANSITION, SPECIAL_ZONE = (
        "menu", "exploration", "combat", "inventory", "dialogue", "game_over", "train_transition", "special_zone"
    )

class TrashType(Enum):
    PAPER, METAL, PLASTIC, GLASS = "paper", "metal", "plastic", "glass"

class EnemyType(Enum):
    GREEDY, ANGRY, SELFISH, TOXIC, BOSS = "greedy", "angry", "selfish", "toxic", "boss"

class FoodType(Enum):
    FRUIT = "fruit"
    BREAD = "bread"
    DOHNUT = "dohnut"
    MAGIC_PICKLE = "magic_pickle"

class ArtType(Enum):
    POETRY = "poetry"
    PAINTING = "painting"
    ALIEN_ARTIFACT = "alien_artifact"  # NEW: Added alien artifact type

class GameObjectType(Enum):
    TRASH, ENEMY, NPC, DOOR, SPECIAL_DOOR = "trash", "enemy", "npc", "door", "special_door"

# Color mappings
TRASH_COLORS = {TrashType.PAPER: WHITE, TrashType.METAL: GRAY, TrashType.PLASTIC: BLUE, TrashType.GLASS: GREEN}
ENEMY_COLORS = {
    EnemyType.GREEDY: YELLOW,
    EnemyType.ANGRY: RED,
    EnemyType.SELFISH: PURPLE,
    EnemyType.TOXIC: GREEN,
    EnemyType.BOSS: (255, 0, 255)  # Purple for boss
}
FOOD_COLORS = {
    FoodType.FRUIT: (255, 100, 100),
    FoodType.BREAD: (210, 180, 140),
    FoodType.DOHNUT: (139, 69, 19),
    FoodType.MAGIC_PICKLE: (0, 255, 0)  # NEW: Bright green for magic pickle
}

ART_COLORS = {
    ArtType.POETRY: (255, 182, 193),  # Light pink color for poetry
    ArtType.PAINTING: (255, 215, 0),   # Golden color for paintings
    ArtType.ALIEN_ARTIFACT: (0, 255, 255)  # NEW: Cyan color for alien artifacts
}

# UPDATED: Added paths for new door images and zone maps
ASSET_PATHS = {
    'trash_images': {
        TrashType.PAPER: "trash1.png",
        TrashType.METAL: "trash2.png",
        TrashType.PLASTIC: "trash3.png",
        TrashType.GLASS: "trash4.png"
    },
    'food_images': {
        FoodType.FRUIT: "food1.png",
        FoodType.BREAD: "food2.png",
        FoodType.DOHNUT: "food3.png",
        FoodType.MAGIC_PICKLE: "food4.png"
    },
    'art_images': {
        ArtType.POETRY: "art1.png",
        ArtType.PAINTING: "art2.png",
        ArtType.ALIEN_ARTIFACT: "art3.png"  # NEW: Added alien artifact image
    },
    'painting_display_images': {
        ArtType.PAINTING: [
            "painting1.jpg",
            "painting2.jpg",
            "painting3.jpg",
            "painting4.jpg",
            "painting5.jpg",
            "painting6.jpg",
            "painting7.jpg",
            "painting8.jpg"
        ]
    },
    'poem_texts': {
        ArtType.POETRY: [
            "poem1.txt",
            "poem2.txt",
            "poem3.txt",
            "poem4.txt",
            "poem5.txt",
            "poem6.txt",
            "poem7.txt",
            "poem8.txt"
        ]
    },
    'alien_artifact_texts': {
        ArtType.ALIEN_ARTIFACT: [
            "This strange crystalline structure pulses with otherworldly energy. Ancient symbols dance across its surface, telling stories of distant civilizations among the stars.",
            "A metallic orb of impossible geometry hovers silently. Its surface reflects not light, but memories of a thousand worlds, each more beautiful than the last.",
            "Tendrils of pure energy flow through this translucent artifact. As you approach, whispers of cosmic knowledge fill your mind with visions of galactic harmony."
        ]
    },
    'player_images': {
        'right': "guy1.png",
        'left': "guy2.png"
    },
    'npc_images': {
        1: 'npc1.png',  # Gunar
        2: 'npc2.png',  # Sweet Pea
        3: 'npc3.png',  # Conductor
        4: 'npc4.png',   # Delilah the Cat - make sure this image exists
        4: 'npc5.png'   # Alien
    },

    'enemy_images': {
        'regular': "enemy1.png",
        'boss': "enemy2.png"  # Special boss enemy
    },
    'door_images': {
        "Oozing Canal City": "door1.png",
        "Forest of Rusting Trees": "door2.png",
        "Wasteland Plains": "door3.png",
        "Train Station": "train.png",
        "Toxic Swamplands": "door5.png",    # NEW Zone 4
        "Burning Deserts": "door6.png",     # NEW Zone 5
        "Frozen Wasteland": "door7.png",    # NEW Zone 6
        "Volcanic Peaks": "door8.png",      # NEW Zone 7
        "Dark Abyss": "door9.png",         # NEW Zone 8
        "Special Zone": "door4.png",         # Special door
        "Final Victory Zone": "door10.png"

    },
    'zone_maps': {
        "Oozing Canal City": "map1.tmx",
        "Forest of Rusting Trees": "map2.tmx",
        "Wasteland Plains": "map3.tmx",
        "Train Station": "maptrainstation.tmx",
        "Toxic Swamplands": "map5.tmx",     # NEW Zone 4
        "Burning Deserts": "map6.tmx",      # NEW Zone 5
        "Frozen Wasteland": "map7.tmx",     # NEW Zone 6
        "Volcanic Peaks": "map8.tmx",       # NEW Zone 7
        "Dark Abyss": "map9.tmx",          # NEW Zone 8
        "Special Zone": "map4.tmx",          # Special zone map
        "Final Victory Zone": "map10.tmx"
    }
}

# Search paths for assets
ASSET_SEARCH_PATHS = ["", "assets/", "images/", "maps/", "data/"]

# Music settings (OGG only - required for pygbag/browser)
MUSIC_VOLUME = 0.5
MUSIC_SEARCH_PATHS = ["images/", "", "assets/"]
INTRO_MUSIC = "music2.ogg"
ZONE_MUSIC = {
    "Oozing Canal City": "music10.ogg", "Forest of Rusting Trees": "music7.ogg",
    "Wasteland Plains": "music12.ogg", "Train Station": "music6.ogg",
    "Toxic Swamplands": "music3.ogg", "Burning Deserts": "music.ogg",
    "Frozen Wasteland": "music9.ogg", "Volcanic Peaks": "music8.ogg",
    "Dark Abyss": "music4.ogg", "BOSS ENEMY LEVEL": "music5.ogg",
    "Final Victory Zone": "music11.ogg"
}

# Leveling: levels now come from events instead of XP
ENEMIES_PER_LEVEL = 1   # 1 = every kill is a level; raise it to slow leveling down

# XP awarded per enemy kill = XP_PER_ENEMY_LEVEL * enemy.level
XP_PER_ENEMY_LEVEL = 20   # the old hardcoded value was 5
