# Web Deployment Checklist - Our Trashy Adventure

## Before Building - Preparation Phase

### 1. Asset Organization
- [ ] Place all images in the `images/` folder
- [ ] Place all TMX map files in the `maps/` folder  
- [ ] Place other assets in the `assets/` folder
- [ ] Create a `data/` folder for any JSON or text files

### 2. Required Asset Files
Make sure you have these files in the correct folders:

**images/ folder should contain:**
- [ ] guy1.png, guy2.png, guy3.png, guyspritesheet.png
- [ ] trash1.png, trash2.png, trash3.png, trash4.png
- [ ] food1.png, food2.png, food3.png, food4.png
- [ ] enemy1.png, enemy2.png
- [ ] door1.png, door2.png, door3.png, door4.png, door5.png
- [ ] door6.png, door7.png, door8.png, door9.png, door10.png
- [ ] npc1.png, npc2.png, npc3.png, npc4.png, npc5.png
- [ ] train.png

**maps/ folder should contain:**
- [ ] map1.tmx, map2.tmx, map3.tmx, maptrainstation.tmx
- [ ] map4.tmx, map5.tmx, map6.tmx, map7.tmx, map8.tmx
- [ ] map9.tmx, map10.tmx

### 3. Test Game Locally
- [ ] Run `python main.py` to test the game works on your computer
- [ ] Fix any errors before proceeding to web build

## Building for Web - Pygbag Process

### 1. Install Pygbag
```bash
pip install pygbag