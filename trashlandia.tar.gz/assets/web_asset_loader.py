# web_asset_loader.py
import pygame
import asyncio
from pathlib import Path


class WebAssetLoader:
    """Asset loader optimized for web deployment with pygbag"""

    def __init__(self):
        self.assets = {}
        self.asset_base_path = ""

    async def preload_assets(self, asset_list):
        """Preload all necessary assets for web deployment"""
        for asset_path in asset_list:
            try:
                # Convert path to web-compatible format
                web_path = str(Path(asset_path)).replace('\\', '/')
                if web_path not in self.assets:
                    # Use pygbag's asset loading mechanism
                    self.assets[web_path] = await self.load_image(web_path)
            except Exception as e:
                print(f"Failed to preload {asset_path}: {e}")

    async def load_image(self, path, size=None):
        """Load image with proper web handling"""
        try:
            # First try direct loading
            image = pygame.image.load(path).convert_alpha()
            if size:
                image = pygame.transform.scale(image, size)
            return image
        except:
            # Fallback for web - create placeholder
            print(f"Creating placeholder for: {path}")
            if size:
                surf = pygame.Surface(size, pygame.SRCALPHA)
            else:
                surf = pygame.Surface((64, 64), pygame.SRCALPHA)

            # Color code by file type
            if "trash" in path:
                surf.fill((100, 100, 255, 200))
            elif "enemy" in path:
                surf.fill((255, 100, 100, 200))
            elif "npc" in path:
                surf.fill((100, 255, 100, 200))
            elif "door" in path:
                surf.fill((200, 200, 100, 200))
            else:
                surf.fill((200, 200, 200, 200))

            return surf

    def get_image(self, path, size=None):
        """Get a preloaded image or load it synchronously"""
        web_path = str(Path(path)).replace('\\', '/')
        if web_path in self.assets:
            img = self.assets[web_path]
            if size and (img.get_width() != size[0] or img.get_height() != size[1]):
                return pygame.transform.scale(img, size)
            return img

        # Fallback for synchronous loading (not ideal for web)
        try:
            return self.load_image(path, size)
        except:
            return self.get_placeholder(size or (64, 64))

    def get_placeholder(self, size):
        """Create a placeholder surface"""
        surf = pygame.Surface(size, pygame.SRCALPHA)
        surf.fill((255, 0, 255))  # Magenta for missing textures
        return surf


# Global instance
asset_loader = WebAssetLoader()