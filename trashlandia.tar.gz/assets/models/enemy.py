# models/enemy.py
"""Enemy model - Hostile creatures with configurable stats and behaviors"""
import pygame
import random
import os
from config.settings import (
    EnemyType,
    ENEMY_COLORS,
    GRAY,
    ZONE_ENEMY_CONFIG,
    COMBAT_UI,
    SCREEN_WIDTH,
    WHITE,
    BLACK
)


class Enemy:
    """Enemy creature class with configurable stats and behaviors"""

    IMAGE_PATHS = ["enemy1.png", os.path.join("assets", "enemy1.png"), os.path.join("images", "enemy1.png")]

    def __init__(self, enemy_type: EnemyType, level: int, zone_level: int = 1):
        """Initialize enemy with type, level, and zone-specific stats"""
        self.type = enemy_type
        self.level = level
        self._init_stats(zone_level)
        self._init_position()
        self.image = self._load_image()
        self._init_movement()

    def _init_stats(self, zone_level):
        """Initialize enemy stats based on zone configuration"""
        zone_config = ZONE_ENEMY_CONFIG.get(zone_level, ZONE_ENEMY_CONFIG[1])

        self.max_hp = zone_config['base_hp'] + (self.level * zone_config['hp_per_level'])
        self.hp = self.max_hp
        self.attack = zone_config['base_attack'] + (self.level * zone_config['attack_per_level'])
        self._calculate_speed(zone_config)

    def _calculate_speed(self, zone_config):
        """Calculate movement speed based on zone configuration"""
        self.base_speed = zone_config['base_speed']
        self.speed_per_level = zone_config['speed_per_level']
        self.move_speed = self.base_speed + (self.level * self.speed_per_level)
        self.move_speed *= zone_config['speed_multiplier']

    def _init_position(self):
        """Initialize position attributes (will be set by Zone)"""
        self.x = self.y = 0
        self.world_width = 4000  # Default values, updated by Zone
        self.world_height = 3000  # Default values, updated by Zone

    def _init_movement(self):
        """Initialize movement attributes"""
        self.move_direction = [0, 0]
        self.move_timer = 0

    def _load_image(self):
        """Load enemy image or return None if not found"""
        for path in self.IMAGE_PATHS:
            if os.path.exists(path):
                try:
                    return pygame.image.load(path).convert_alpha()
                except pygame.error as e:
                    print(f"Error loading {path}: {e}")
        return None

    def update(self):
        """Update enemy movement while staying within world bounds"""
        if self.move_timer <= 0:
            self._choose_new_direction()
        else:
            self._move_and_constrain()
            self.move_timer -= 1

    def _choose_new_direction(self):
        """Choose a new random movement direction"""
        self.move_direction = [random.uniform(-1, 1), random.uniform(-1, 1)]
        self._normalize_direction()
        self.move_timer = random.randint(60, 180)  # 1-3 seconds at 60 FPS

    def _normalize_direction(self):
        """Normalize the direction vector"""
        length = (self.move_direction[0] ** 2 + self.move_direction[1] ** 2) ** 0.5
        if length > 0:
            self.move_direction[0] /= length
            self.move_direction[1] /= length

    def _move_and_constrain(self):
        """Move enemy and constrain to world bounds"""
        new_x = self.x + self.move_direction[0] * self.move_speed
        new_y = self.y + self.move_direction[1] * self.move_speed

        # Constrain position with enemy radius of 15 pixels
        self.x = max(15, min(self.world_width - 15, new_x))
        self.y = max(15, min(self.world_height - 15, new_y))

    # Drawing methods
    def draw(self, screen, x, y, game):
        """Draw enemy with optional combat cooldown indicator"""
        self._draw_combat_cooldown(screen, x, y, game)
        self._draw_enemy(screen, x, y)

    def _draw_combat_cooldown(self, screen, x, y, game):
        """Draw combat cooldown indicator if active"""
        if game and game.is_combat_on_cooldown(self):
            pygame.draw.circle(screen, WHITE, (int(x), int(y)), 20, 2)

    def _draw_enemy(self, screen, x, y):
        """Draw enemy image or fallback circle"""
        if self.image:
            self._draw_enemy_image(screen, x, y)
        else:
            self._draw_enemy_circle(screen, x, y)

    def _draw_enemy_image(self, screen, x, y):
        """Draw enemy using loaded image"""
        size = (self.image.get_width() * 5, self.image.get_height() * 5) if self.type == EnemyType.BOSS else (30, 30)
        img = pygame.transform.scale(self.image, size)
        screen.blit(img, img.get_rect(center=(int(x), int(y))))

    def _draw_enemy_circle(self, screen, x, y):
        """Draw enemy as colored circle if no image available"""
        pygame.draw.circle(screen, self.get_color(), (int(x), int(y)), 15)
        pygame.draw.circle(screen, BLACK, (int(x), int(y)), 15, 2)

    def get_color(self):
        """Get color for this enemy type"""
        return ENEMY_COLORS.get(self.type, GRAY)

    # Combat UI methods
    def draw_combat_stats(self, screen, fonts, positions):
        """Draw enemy stats panel in combat"""
        panel_size = COMBAT_UI['stats_panel_size']
        panel_rect = self._create_stats_panel(screen, panel_size)
        self._draw_stats_content(screen, fonts, panel_rect)

    def _create_stats_panel(self, screen, size):
        """Create and position stats panel"""
        panel_rect = pygame.Rect(SCREEN_WIDTH - size[0] - 20, 70, *size)
        pygame.draw.rect(screen, (40, 40, 50), panel_rect)
        pygame.draw.rect(screen, WHITE, panel_rect, 2)
        return panel_rect

    def _draw_stats_content(self, screen, fonts, panel_rect):
        """Draw content inside stats panel"""
        self._draw_panel_title(screen, fonts, panel_rect)
        self._draw_stat_lines(screen, fonts, panel_rect)

    def _draw_panel_title(self, screen, fonts, panel_rect):
        """Draw panel title"""
        label = fonts['small'].render("ENEMY STATS", True, (200, 50, 50))
        screen.blit(label, (panel_rect.x + 10, panel_rect.y + 5))

    def _draw_stat_lines(self, screen, fonts, panel_rect):
        """Draw individual stat lines"""
        stats = [
            f"Type: {self.type.value.upper()}",
            f"Level: {self.level}",
            f"HP: {self.hp}/{self.max_hp}",
            f"Attack: {self.attack}"
        ]

        for i, stat in enumerate(stats):
            text = fonts['tiny'].render(stat, True, WHITE)
            screen.blit(text, (panel_rect.x + 10, panel_rect.y + 25 + i * 18))

    def draw_health_bar(self, screen, x, y, bar_size):
        """Draw enemy health bar"""
        bar_rect = pygame.Rect(x - bar_size[0] // 2, y, *bar_size)
        fill_width = (self.hp / self.max_hp) * bar_size[0]

        pygame.draw.rect(screen, (50, 50, 50), bar_rect)
        pygame.draw.rect(screen, (200, 30, 30), (bar_rect.x, bar_rect.y, fill_width, bar_rect.height))
        pygame.draw.rect(screen, WHITE, bar_rect, 1)