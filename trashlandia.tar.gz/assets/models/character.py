# models/character.py - UPDATED VERSION
"""Character model - Player character data with drawing capabilities"""
import pygame
import os
from dataclasses import dataclass, field
from typing import List, Dict, Optional, ClassVar
from models.item import Item
from config.settings import *


@dataclass
class Character:
    """Player character class with drawing and UI methods"""
    name: str
    hp: int
    max_hp: int
    level: int
    xp: int
    skills: Dict[str, int]
    inventory: List[Item]
    equipped_items: List[Item] = field(default_factory=list)
    base_attack: int = 8
    attack_bonus: int = 0
    block_chance: int = 30  # CHANGED: Updated from 10 to 30 for 30% starting block chance
    x: float = 0
    y: float = 0
    enemies_defeated: int = 0  # NEW: kill counter used for leveling

    # Class variables for shared image resources
    _player_images: ClassVar[Dict[str, pygame.Surface]] = {}
    _player_images_loaded: ClassVar[bool] = False
    _facing_right: bool = True

    # NEW: Sprite sheet animation variables
    _sprite_sheet: ClassVar[Optional[pygame.Surface]] = None
    _sprite_frames: ClassVar[Dict[str, List[pygame.Surface]]] = {}
    _sprite_sheet_loaded: ClassVar[bool] = False
    _current_direction: str = 'down'  # Track current movement direction
    _animation_frame: int = 0
    _animation_timer: float = 0
    _animation_speed: float = 0.15  # Time between frames in seconds
    _is_moving: bool = False

    def __post_init__(self):
        """Initialize character after creation"""
        if not Character._player_images_loaded:
            Character.load_player_images()
        if not Character._sprite_sheet_loaded:
            Character.load_sprite_sheet()

    @classmethod
    def load_sprite_sheet(cls):
        """Load and process the sprite sheet for exploration animation - UPDATED for 9 columns"""
        if cls._sprite_sheet_loaded:
            return

        # Try to load the sprite sheet
        sprite_sheet = cls._load_image_from_paths("guyspritesheet.png")
        if not sprite_sheet:
            print("Warning: Could not load guyspritesheet.png, falling back to static sprites")
            cls._sprite_sheet_loaded = True
            return

        cls._sprite_sheet = sprite_sheet

        # Extract frames from sprite sheet
        # CHANGED: Sprite sheet is now 9 columns x 4 rows (was 8x4)
        sheet_width = sprite_sheet.get_width()
        sheet_height = sprite_sheet.get_height()
        frame_width = sheet_width // 9  # CHANGED: 9 columns instead of 8
        frame_height = sheet_height // 4  # Still 4 rows

        directions = ['up', 'left', 'down', 'right']

        for row, direction in enumerate(directions):
            frames = []
            for col in range(9):  # CHANGED: 9 frames per direction instead of 8
                x = col * frame_width
                y = row * frame_height

                frame_rect = pygame.Rect(x, y, frame_width, frame_height)
                frame = pygame.Surface((frame_width, frame_height), pygame.SRCALPHA)
                frame.blit(sprite_sheet, (0, 0), frame_rect)

                # CHANGED: Scale to double the previous size (96x96 instead of 48x48) for exploration mode
                frame = pygame.transform.scale(frame, (96, 96))
                frames.append(frame)

            cls._sprite_frames[direction] = frames

        cls._sprite_sheet_loaded = True

    @classmethod
    def load_player_images(cls):
        """Load player sprite images"""
        if cls._player_images_loaded:
            return

        for direction, filename in ASSET_PATHS['player_images'].items():
            # CHANGED: Double the size for exploration mode (96x96 instead of 48x48)
            image = cls._load_image_from_paths(filename, (96, 96))
            if image:
                cls._player_images[direction] = image

        cls._player_images_loaded = True

        # Create combat version (DOUBLED from 96x96 to 192x192)
        if 'right' in cls._player_images:
            cls._player_images['combat'] = pygame.transform.scale(
                cls._player_images['right'], (192, 192)  # CHANGED: Doubled from (96, 96)
            )

    @staticmethod
    def _load_image_from_paths(filename: str, size: tuple = None) -> Optional[pygame.Surface]:
        """Try to load image from multiple possible paths"""
        for path_prefix in ASSET_SEARCH_PATHS:
            full_path = os.path.join(path_prefix, filename) if path_prefix else filename
            if os.path.exists(full_path):
                try:
                    image = pygame.image.load(full_path).convert_alpha()
                    if size:
                        image = pygame.transform.scale(image, size)
                    return image
                except pygame.error as e:
                    print(f"Error loading {full_path}: {e}")
        return None

    @property
    def total_attack(self):
        """Calculate total attack including bonuses from equipment"""
        return self.base_attack + self.attack_bonus

    def update_facing_direction(self, moving_right: bool = None, moving_left: bool = None):
        """Update which direction the character is facing"""
        if moving_right:
            self._facing_right = True
        elif moving_left:
            self._facing_right = False

    def update_movement_direction(self, moving_right: bool, moving_left: bool):
        """Update facing direction based on movement"""
        if moving_right:
            self._facing_right = True
        elif moving_left:
            self._facing_right = False
        # If both or neither are pressed, maintain current direction

    def update_exploration_animation(self, dt: float, moving_up: bool = False, moving_down: bool = False,
                                     moving_left: bool = False, moving_right: bool = False):
        """Update animation state for exploration mode - UPDATED for 9 frames"""
        # Determine if player is moving
        self._is_moving = moving_up or moving_down or moving_left or moving_right

        # Update direction based on movement
        if moving_up:
            self._current_direction = 'up'
        elif moving_down:
            self._current_direction = 'down'
        elif moving_left:
            self._current_direction = 'left'
        elif moving_right:
            self._current_direction = 'right'

        # Update animation timer and frame
        if self._is_moving:
            self._animation_timer += dt
            if self._animation_timer >= self._animation_speed:
                self._animation_timer = 0
                # CHANGED: 9 frames per direction instead of 8
                self._animation_frame = (self._animation_frame + 1) % 9
        else:
            # When not moving, reset to first frame
            self._animation_frame = 0
            self._animation_timer = 0

    def get_current_sprite(self, combat_mode: bool = False, exploration_mode: bool = False) -> Optional[pygame.Surface]:
        """Get the current sprite based on mode and animation state"""
        if combat_mode and 'combat' in Character._player_images:
            return Character._player_images['combat']

        # NEW: Use sprite sheet for exploration mode if available
        if exploration_mode and self._sprite_frames and self._current_direction in self._sprite_frames:
            frames = self._sprite_frames[self._current_direction]
            if frames:
                return frames[self._animation_frame]

        # Fallback to static sprites
        direction = 'right' if self._facing_right else 'left'
        return Character._player_images.get(direction)

    def draw(self, screen: pygame.Surface, x: int, y: int,
             speed_boost_active: bool = False, combat_mode: bool = False, exploration_mode: bool = False):
        """Draw the character using the correct sprite"""
        # CHANGED: Adjust speed boost effect radius for larger exploration sprite
        boost_radius = 25 if not exploration_mode else 50
        if speed_boost_active:
            pygame.draw.circle(screen, YELLOW, (int(x), int(y)), boost_radius, 3)

        # Get and draw the appropriate sprite
        sprite = self.get_current_sprite(combat_mode, exploration_mode)
        if sprite:
            sprite_rect = sprite.get_rect(center=(int(x), int(y)))
            screen.blit(sprite, sprite_rect)
        else:
            # CHANGED: Adjust fallback circle radius for exploration mode
            if exploration_mode:
                radius = 48  # Double the original 24 for exploration
            elif combat_mode:
                radius = 96  # Keep combat mode large
            else:
                radius = 24  # Default size

            pygame.draw.circle(screen, PURPLE, (int(x), int(y)), radius)
            pygame.draw.circle(screen, WHITE, (int(x), int(y)), radius, 2)

    def draw_stats_ui(self, screen: pygame.Surface, fonts: Dict[str, pygame.font.Font],
                      zone_name: str, zone, combat_cooldown: int = 0, speed_boost: int = 0):
        """Draw player stats UI in top-left corner - FIXED: Accurate trash counting"""
        font_small = fonts['small']
        font_tiny = fonts['tiny']

        # Main stats
        stats = [
            f"Zone: {zone_name}",
            f"Player Level: {self.level}",
            f"XP: {self.xp}",
            f"HP: {self.hp}/{self.max_hp}",
            f"Attack Damage: {self.total_attack}",
            f"Enemies: {len(zone.enemies)}/{zone.initial_enemy_count}"
        ]

        for i, stat in enumerate(stats):
            text = font_small.render(stat, True, WHITE)
            screen.blit(text, (10, 10 + i * 25))

        y_offset = 160
        if hasattr(zone, 'is_restored') and zone.is_restored:
            restoration_text = "Zone RESTORED! +1 Level"
            text = font_small.render(restoration_text, True, GREEN)
            screen.blit(text, (10, 165))
        else:
            # Get current trash count directly from the zone
            current_trash_count = len(zone.trash_items)

            # Each zone has exactly 20 items total (including art items)
            total_original_items = 20
            items_collected = total_original_items - current_trash_count

            # Display the accurate count
            restoration_text = f"Trash remaining: {current_trash_count}/{total_original_items}"

            # Progress bar - based on actual collection progress
            progress = items_collected / total_original_items

            bar_width = 200
            filled_width = int(bar_width * progress)

            # Draw progress bar
            pygame.draw.rect(screen, (50, 50, 50), (10, y_offset, bar_width, 20))
            pygame.draw.rect(screen, GREEN, (10, y_offset, filled_width, 20))
            pygame.draw.rect(screen, WHITE, (10, y_offset, bar_width, 20), 1)  # Border

            # Display the text
            text = font_small.render(restoration_text, True, WHITE)
            screen.blit(text, (10, 165))

            # Optional: Show collection progress percentage
            progress_text = f"Progress: {int(progress * 100)}%"
            progress_surf = font_tiny.render(progress_text, True, WHITE)
            screen.blit(progress_surf, (220, y_offset + 3))

        # Status effects
        y_offset = 195
        if combat_cooldown > 0:
            cooldown_text = f"Combat Immunity: {combat_cooldown}s"
            text = font_small.render(cooldown_text, True, YELLOW)
            screen.blit(text, (10, y_offset))
            y_offset += 25

        if speed_boost > 0:
            speed_text = f"Speed Boost: {speed_boost}s"
            text = font_small.render(speed_text, True, YELLOW)
            screen.blit(text, (10, y_offset))

    def draw_stats_menu(self, screen: pygame.Surface, fonts: Dict[str, pygame.font.Font]) -> Dict[int, pygame.Rect]:
        """Draw the player stats upgrade menu and return button rects"""
        font = fonts['normal']
        font_small = fonts['small']
        font_tiny = fonts['tiny']

        # Semi-transparent overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(180)
        overlay.fill(BLACK)
        screen.blit(overlay, (0, 0))

        # Main panel
        panel_width, panel_height = STATS_PANEL_SIZE
        panel_rect = pygame.Rect(0, 0, panel_width, panel_height)
        panel_rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)

        pygame.draw.rect(screen, UI_COLORS['panel_bg'], panel_rect)
        pygame.draw.rect(screen, WHITE, panel_rect, 3)

        # Title
        title = font.render("PLAYER STATS", True, WHITE)
        screen.blit(title, (panel_rect.centerx - title.get_width() // 2, panel_rect.y + 15))

        # Draw player image (guy3.png) - same position as inventory
        player_image = self._load_image_from_paths("guy3.png", (96, 96))
        if player_image:
            screen.blit(player_image, player_image.get_rect(center=(panel_rect.centerx, panel_rect.y + 75)))
        else:
            # Fallback: draw the player using existing method if guy3.png not found
            self.draw(screen, panel_rect.centerx, panel_rect.y + 75, combat_mode=False)

        # Column setup (moved down to accommodate the image)
        column_width = (panel_rect.width - 60) // 4
        start_x = panel_rect.x + 30
        start_y = panel_rect.y + 160  # Increased from 60 to 160 to make room for image
        button_height = 40

        upgrade_button_rects = {}

        # Stats data
        headers = ["XP", "HP", "ATTACK", "BLOCK"]
        values = [
            str(self.xp),
            f"{self.hp}/{self.max_hp}",
            str(self.total_attack),
            f"{self.block_chance}%"
        ]

        # Draw columns
        for i, (header, value) in enumerate(zip(headers, values)):
            column_x = start_x + i * column_width

            # Header
            header_text = font_small.render(header, True, WHITE)
            screen.blit(header_text, (column_x + (column_width - header_text.get_width()) // 2, start_y))

            # Value
            value_text = font.render(value, True, GREEN if i == 0 else WHITE)
            screen.blit(value_text, (column_x + (column_width - value_text.get_width()) // 2, start_y + 40))

            # Upgrade buttons
            if i > 0 and self.xp >= 100:
                button_width = column_width - 20
                button_rect = pygame.Rect(column_x + 10, panel_rect.bottom - 80, button_width, button_height)
                upgrade_button_rects[i] = button_rect

                # Draw button
                pygame.draw.rect(screen, GREEN, button_rect)
                pygame.draw.rect(screen, WHITE, button_rect, 2)

                # Button text
                text = font_tiny.render("UPGRADE (+5)", True, BLACK)
                text_rect = text.get_rect(center=button_rect.center)
                screen.blit(text, text_rect)

        # Instructions
        instruction = font_tiny.render("Press G to close", True, WHITE)
        screen.blit(instruction, (panel_rect.x + 20, panel_rect.bottom - 30))

        return upgrade_button_rects

    def handle_stat_upgrade(self, stat_index: int) -> bool:
        """Handle stat upgrade purchase"""
        if self.xp < 100:
            return False

        if stat_index == 1:  # HP upgrade
            self.max_hp += 5
            self.hp += 5
            self.xp -= 100
            return True
        elif stat_index == 2:  # Attack upgrade
            self.base_attack += 5
            self.xp -= 100
            return True
        elif stat_index == 3:  # Block upgrade
            self.block_chance = min(self.block_chance + 5, 100)
            self.xp -= 100
            return True

        return False

    def draw_combat_stats(self, screen: pygame.Surface, fonts: Dict[str, pygame.font.Font],
                          position: tuple = (20, 70)):
        """Draw character stats during combat"""
        font_small = fonts['small']
        font_tiny = fonts['tiny']

        panel_width, panel_height = COMBAT_UI['stats_panel_size']
        player_panel_rect = pygame.Rect(position[0], position[1], panel_width, panel_height)

        pygame.draw.rect(screen, (40, 40, 50), player_panel_rect)
        pygame.draw.rect(screen, WHITE, player_panel_rect, 2)

        # Stats label
        label = font_small.render("YOUR STATS", True, (50, 150, 50))
        screen.blit(label, (player_panel_rect.x + 10, player_panel_rect.y + 5))

        # Stats
        stats = [
            f"Level: {self.level}",
            f"HP: {self.hp}/{self.max_hp}",
            f"Attack: {self.total_attack}"
        ]

        for i, stat in enumerate(stats):
            text = font_tiny.render(stat, True, WHITE)
            screen.blit(text, (player_panel_rect.x + 10, player_panel_rect.y + 25 + i * 18))

    def draw_health_bar(self, screen: pygame.Surface, x: int, y: int,
                        bar_size: tuple = (120, 12)):
        """Draw character health bar"""
        bar_width, bar_height = bar_size
        bar_rect = pygame.Rect(x - bar_width // 2, y, bar_width, bar_height)

        fill_width = (self.hp / self.max_hp) * bar_width
        pygame.draw.rect(screen, (50, 50, 50), bar_rect)
        pygame.draw.rect(screen, (50, 200, 50),
                         (bar_rect.x, bar_rect.y, fill_width, bar_rect.height))
        pygame.draw.rect(screen, WHITE, bar_rect, 1)

        # Health text
        hp_text = f"{self.hp}/{self.max_hp}"
        # Note: Font would need to be passed in for this to work
        # text_surf = font_tiny.render(hp_text, True, WHITE)
        # screen.blit(text_surf, (x - bar_width // 2, y + bar_height + 2))

    def _apply_item_effects(self, item, apply=True):
        """Apply or remove item effects"""
        multiplier = 1 if apply else -1
        self.max_hp += item.hp_bonus * multiplier
        self.attack_bonus += item.attack_bonus * multiplier

        if apply:
            self.hp += item.hp_bonus
        else:
            self.hp = min(self.hp, self.max_hp)

    def equip_item(self, item):
        """Equip an item and apply its effects"""
        if item.is_equippable and item not in self.equipped_items:
            self.equipped_items.append(item)
            self._apply_item_effects(item, True)

            bonuses = []
            if item.hp_bonus > 0: bonuses.append(f"HP +{item.hp_bonus}")
            if item.attack_bonus > 0: bonuses.append(f"Attack +{item.attack_bonus}")
            bonus_str = ", ".join(bonuses) if bonuses else "no bonuses"

    def unequip_item(self, item):
        """Unequip an item and remove its effects"""
        if item in self.equipped_items:
            self.equipped_items.remove(item)
            self._apply_item_effects(item, False)

            bonuses = []
            if item.hp_bonus > 0: bonuses.append(f"HP -{item.hp_bonus}")
            if item.attack_bonus > 0: bonuses.append(f"Attack -{item.attack_bonus}")
            bonus_str = ", ".join(bonuses) if bonuses else "no bonuses"

    def get_inventory_by_category(self) -> Dict[str, List[Item]]:
        """Categorize inventory items for display - NEW: Added art category"""
        categories = {
            'trash': [item for item in self.inventory if isinstance(getattr(item, 'item_type', None), TrashType)],
            'food': [item for item in self.inventory if isinstance(getattr(item, 'item_type', None), FoodType)],
            'art': [item for item in self.inventory if isinstance(getattr(item, 'item_type', None), ArtType)],
            # NEW: Art category
            'crafted': [item for item in self.inventory if item.is_equippable]
        }
        return categories

    def check_level_up(self):
        """Disabled: levels are no longer earned from XP (see level_up)."""
        pass

    def level_up(self, levels: int = 1, heal: bool = True):
        """Gain levels: +max HP per level, optionally with a full heal"""
        for _ in range(levels):
            self.level += 1
            self.max_hp += HP_GAIN_PER_LEVEL
        if heal:
            self.hp = self.max_hp

    def add_to_inventory(self, item):
        """Add any item to inventory with proper stacking - NEW: Added art item support"""
        if getattr(item, 'item_type', None) in [FoodType.FRUIT, FoodType.BREAD,
                                                ArtType.POETRY]:  # NEW: Art items don't stack
            # Food and art items are always added as new items
            self.inventory.append(item)
        else:
            # Stack existing non-food items
            for inv_item in self.inventory:
                if inv_item.name == item.name and not inv_item.is_equippable:
                    inv_item.quantity += item.quantity
                    return
            # Add new item if not found
            self.inventory.append(item)

    def constrain_position(self, world_width, world_height):
        """Keep player within world bounds"""
        self.x = max(24, min(world_width - 24, self.x))
        self.y = max(24, min(world_height - 24, self.y))

    def handle_inventory_click(self, item, game):
        """Handle inventory clicks - NO XP CHANGES"""
        if item.is_equippable:
            if item in self.equipped_items:
                self.unequip_item(item)
            else:
                self.equip_item(item)
        elif getattr(item, 'item_type', None) == FoodType.FRUIT:
            self.hp = min(self.hp + item.hp_bonus, self.max_hp)
            self.inventory.remove(item)
        elif getattr(item, 'item_type', None) == FoodType.BREAD:
            game.activate_speed_boost(10)  # Only speed boost, no HP change
            self.inventory.remove(item)