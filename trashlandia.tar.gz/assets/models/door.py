# models/door.py
import pygame
import os
import math
from config.settings import GameObjectType, DOOR_COLOR, ASSET_SEARCH_PATHS


class Door:
    """Door that transports player between zones with direction tracking"""

    def __init__(self, target_zone, x, y, is_right_door=True, door_image=None, is_train_door=False,
                 is_special_door=False):
        self.type = GameObjectType.DOOR
        # Convert coordinates to integers to handle string inputs
        self.x = int(float(x))
        self.y = int(float(y))
        self.target_zone = target_zone
        self.is_right_door = is_right_door
        self.door_image_file = door_image
        self.image = None

        # Door type flags
        self.is_train_door = is_train_door
        self.is_special_door = is_special_door
        self.is_victory_door = False

        # Properties
        self.radius = 20
        self.rect = pygame.Rect(self.x - 20, self.y - 30, 40, 60)
        self.dialogue = ["Cleanup Trash in zones 1-8"] if is_special_door else []

        # Load the door image
        self._load_door_image()

    def _load_door_image(self):
        """Load door image, with custom image support and automatic type detection"""
        # Determine image file based on custom image or target zone
        if self.door_image_file:
            image_file = self.door_image_file
            # Auto-detect victory door from filename
            if self.door_image_file == "door10.png":
                self.is_victory_door = True
        elif self.is_train_door:
            image_file = "train.png"
        elif self.is_special_door:
            image_file = "door4.png"
        else:
            # Use specific door images for each zone
            door_images = {
                "Oozing Canal City": "door1.png",
                "Forest of Rusting Trees": "door2.png",
                "Wasteland Plains": "door3.png",
                "Train Station": "train.png",
                "Toxic Swamplands": "door5.png",
                "Burning Deserts": "door6.png",
                "Frozen Wasteland": "door7.png",
                "Volcanic Peaks": "door8.png",
                "Dark Abyss": "door9.png",
                "BOSS ENEMY LEVEL": "door4.png",
                "Final Victory Zone": "door10.png"
            }
            image_file = door_images.get(self.target_zone, "door1.png")

        # Try to load the image from various paths
        for path in ASSET_SEARCH_PATHS:
            try:
                full_path = os.path.join(path, image_file)
                if os.path.exists(full_path):
                    self.image = pygame.image.load(full_path).convert_alpha()
                    # Scale based on door type
                    if self.is_train_door or self.is_special_door or self.is_victory_door:
                        self.image = pygame.transform.scale(self.image, (64, 96))
                    else:
                        self.image = pygame.transform.scale(self.image, (50, 80))
                    return
            except pygame.error as e:
                print(f"Error loading {full_path}: {e}")
                continue

        # Fallback - create a colored rectangle if image not found
        print(f"Could not find {image_file} - creating colored rectangle")
        if self.is_victory_door or (self.door_image_file and "door10" in self.door_image_file):
            size = (64, 96)
            self.image = pygame.Surface(size)
            self.image.fill((255, 215, 0))  # Gold color for victory door
        elif self.is_train_door:
            size = (64, 96)
            self.image = pygame.Surface(size)
            self.image.fill((100, 50, 0))  # Brown for train door
        elif self.is_special_door:
            size = (64, 96)
            self.image = pygame.Surface(size)
            self.image.fill((255, 165, 0))  # Orange for special door
        else:
            size = (50, 80)
            self.image = pygame.Surface(size)
            self.image.fill(DOOR_COLOR)  # Default door color

    def check_collision(self, player_rect):
        """More precise collision checking"""
        return self.rect.colliderect(player_rect)

    def draw(self, screen, camera=None):
        """Draw the door with special effects for victory door"""
        screen_x, screen_y = camera.apply(self.x, self.y) if camera else (self.x, self.y)

        # Special glow effect for victory door
        if hasattr(self, 'is_victory_door') and self.is_victory_door:
            current_time = pygame.time.get_ticks()
            # Create pulsing glow
            pulse = abs(math.sin(current_time * 0.005))
            glow_radius = int(40 + 20 * pulse)
            glow_color = (255, 215, 0, int(100 * pulse))  # Golden glow

            # Draw glow effect
            glow_surface = pygame.Surface((glow_radius * 2, glow_radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(glow_surface, glow_color, (glow_radius, glow_radius), glow_radius)
            screen.blit(glow_surface, (screen_x - glow_radius + 32, screen_y - glow_radius + 48))

        # Draw the door image
        if self.image:
            door_rect = self.image.get_rect(center=(screen_x, screen_y))
            screen.blit(self.image, door_rect)
        else:
            # Fallback drawing with different colors for different door types
            if self.is_victory_door:
                color = (255, 215, 0)  # Gold for victory door
            elif self.is_special_door:
                color = (255, 165, 0)  # Orange for special door
            elif self.is_train_door:
                color = (100, 50, 0)  # Brown for train door
            else:
                color = DOOR_COLOR  # Default color

            pygame.draw.rect(screen, color, (screen_x - 25, screen_y - 40, 50, 80))

    def draw_dialogue(self, screen, fonts):
        """Draw the dialogue interface for this door with image above"""
        from config.settings import DIALOGUE_PANEL_SIZE, SCREEN_WIDTH, SCREEN_HEIGHT, BLACK, WHITE

        font_small = fonts['small']
        font_tiny = fonts['tiny']

        # Create dialogue panel (same size and position as NPC dialogue)
        panel_size = DIALOGUE_PANEL_SIZE
        rect = pygame.Rect(
            SCREEN_WIDTH // 4, SCREEN_HEIGHT - panel_size[1] - 50,
            panel_size[0], panel_size[1]
        )

        # Semi-transparent background
        dialog_surface = pygame.Surface((rect.width, rect.height))
        dialog_surface.set_alpha(220)
        dialog_surface.fill(BLACK)
        screen.blit(dialog_surface, rect)

        # Border
        pygame.draw.rect(screen, WHITE, rect, 2)

        # Draw door image at 2x size above the text
        if self.image:
            if self.is_special_door or self.is_train_door or self.is_victory_door:
                scaled_image = pygame.transform.scale(self.image, (120, 200))
            else:
                scaled_image = pygame.transform.scale(self.image, (100, 160))

            image_rect = scaled_image.get_rect(center=(rect.centerx, rect.top - scaled_image.get_height() // 2 - 10))
            screen.blit(scaled_image, image_rect)

        # Title based on door type
        if self.is_victory_door:
            title_text = "Victory Portal"
        elif self.is_special_door:
            title_text = "Special Boss Door"
        elif self.is_train_door:
            title_text = f"Train to {self.target_zone}"
        else:
            title_text = f"Door to {self.target_zone}"

        title_surf = font_small.render(title_text, True, WHITE)
        screen.blit(title_surf, (rect.x + 10, rect.y + 10))

        # Dialogue text
        y_offset = 50
        dialogue_lines = self.dialogue if self.dialogue else []
        for line in dialogue_lines:
            if y_offset + 25 > rect.height - 20:  # Prevent text overflow
                break
            surf = font_tiny.render(line, True, WHITE)
            screen.blit(surf, (rect.x + 20, rect.y + y_offset))
            y_offset += 25

        # Instructions
        instruction_text = "Press X to close"
        instruction_surf = font_tiny.render(instruction_text, True, (200, 200, 200))
        screen.blit(instruction_surf, (rect.x + 20, rect.bottom - 30))

    # Legacy compatibility methods to match your existing code structure
    def _load_image(self):
        """Legacy method - redirects to new method"""
        return self._load_door_image()