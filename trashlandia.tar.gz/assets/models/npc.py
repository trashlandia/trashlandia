# models/npc.py
import random
import pygame
import os
from typing import ClassVar, Dict, Optional
from config.settings import *


class NPC:
    """Non-player character class with drawing and dialogue capabilities"""

    # Class variables for shared image resources
    _npc_images: ClassVar[Dict[int, pygame.Surface]] = {}
    _images_loaded: ClassVar[bool] = False

    def __init__(self, name="Gunar", npc_type=1):
        self.name = name
        self.npc_type = npc_type
        self.color = (0, 0, 0)  # Default fallback color
        self.move_speed = 0.5
        self.move_direction = [0, 0]
        self.move_timer = 0
        self.x = 0
        self.y = 0
        self.original_x = 0
        self.original_y = 0
        # Add world boundary tracking
        self.world_width = 4000
        self.world_height = 3000

        # NEW: Add victory zone flag
        self.is_victory_zone_npc = False

        # Quest system variables
        self.quest_completed = False
        self.quest_requirements = self._get_quest_requirements(npc_type)
        self.quest_reward_xp = 100
        self.give_items_button_rect = None

        # Load images if not already loaded
        if not NPC._images_loaded:
            NPC.load_npc_images()

        # Set up dialogue based on NPC type
        self.dialogue = self._get_dialogue_for_type(npc_type)

    def _get_quest_requirements(self, npc_type: int) -> Dict:
        """Get quest requirements based on NPC type"""
        quest_map = {
            1: {"item_type": FoodType.FRUIT, "quantity": 5, "item_name": "Apple"},  # npc1.png - Gunar
            2: {"item_type": FoodType.BREAD, "quantity": 5, "item_name": "Bread"},  # npc2.png - Sweet Pea
            3: {"item_type": FoodType.DOHNUT, "quantity": 5, "item_name": "Dohnut"},  # npc3.png - Conductor
            4: {"item_type": TrashType.PAPER, "quantity": 5, "item_name": "Paper"},  # npc4.png - Cat (Delilah)
            5: {"item_types": [TrashType.METAL, TrashType.GLASS], "quantities": [6, 6],
                "item_names": ["Metal", "Glass"]}  # npc5.png - Alien
        }
        return quest_map.get(npc_type, {"item_type": FoodType.FRUIT, "quantity": 10, "item_name": "Apple"})

    @classmethod
    def load_npc_images(cls):
        """Load NPC images for all types"""
        if cls._images_loaded:
            return

        # Updated to include npc5.png for the Alien
        npc_image_files = {
            1: "npc1.png",  # Gunar
            2: "npc2.png",  # Sweet Pea
            3: "npc3.png",  # Conductor
            4: "npc4.png",  # Delilah (Cat)
            5: "npc5.png"  # Alien (NEW)
        }

        for npc_type, filename in npc_image_files.items():
            image = cls._load_image_from_paths(filename)
            if image:
                # Scale to 45x45 (1.5x original size of 30x30)
                image = pygame.transform.scale(image, (45, 45))
                cls._npc_images[npc_type] = image

        cls._images_loaded = True

    @staticmethod
    def _load_image_from_paths(filename: str) -> Optional[pygame.Surface]:
        """Try to load image from multiple possible paths"""
        for path_prefix in ASSET_SEARCH_PATHS:
            full_path = os.path.join(path_prefix, filename) if path_prefix else filename
            if os.path.exists(full_path):
                try:
                    return pygame.image.load(full_path).convert_alpha()
                except pygame.error as e:
                    print(f"Error loading {full_path}: {e}")
        return None

    def _get_dialogue_for_type(self, npc_type: int) -> list:
        """Get dialogue lines based on NPC type with quest info - MODIFIED for victory zone"""

        # Check if this NPC is in victory zone and modify dialogue accordingly
        if hasattr(self, 'is_victory_zone_npc') and self.is_victory_zone_npc:
            return [
                "Find the Alien Artifacts to fix the spaceship!",
                "",
                "The Alien needs special artifacts to finish fixing...",
                "Search the world for these mysterious items!",
                "",
                "Press X to close at any time"
            ]

        # Original dialogue for non-victory zone NPCs
        base_dialogues = {
            1: [
                "Hello! I'm Gunar!",
                "Thank you for collecting trash!",
                "Every piece you clean helps restore our world!",
                "",
                "Hej! Jeg er Gunar!",
                "Tak for at samle affald!",
                "Hver genstand, du rengør hjælper med at genoprette vores verden",
                "",
                f"Quest: Bring me 5 Apples for 100 XP!",
                "",
                "Press X to close at any time"
            ],
            2: [
                "Greetings traveler!",
                "I'm SWEEEEEEEEET   PEEEEEEEEEEAAAAA.",
                "They call me a dog ruff ruff!",
                "Let me know if you find any bread!",
                "I LOVE BREAD",
                "ruff ruff!",
                "",
                f"Quest: Bring me 5 Bread for 100 XP!",
                "",
                "Press X to close at any time"
            ],
            3: [
                "Hello I am the train conductor man!",
                "I know a lot about these doors and my favorite food... dohnuts!",
                "",
                "Special doors are available for those who cleanup all",
                "this yucky trash that is in our land.... ",
                "help us to CLEANUP ALL THE TRASH!",
                "",
                f"Quest: Bring me 5 Dohnuts for 100 XP!",
                "",
                "Press X to close at any time"
            ],
            4: [  # Cat NPC (Delilah)
                "MEOW! My name is Delilah...",
                "I want some paper! Do you have any paper",
                "to give to me that I can play with???",
                "",
                "*purr purr*",
                "",
                "I love playing with crinkly paper!",
                "It makes such fun sounds when I bat at it!",
                "",
                f"Quest: Bring me 5 Paper for 100 XP!",
                "",
                "Press X to close at any time"
            ],
            5: [  # Alien NPC
                "Calling me by a name is not important... "
                "Where I come from is not important...",
                "I can see you like collecting.... hmmmmmm....",
                "Fix spaceship with re-using this waste?",
                "I could use lots of... METAL and GLASS",
                "",
                "*strange alien sounds*",
                "My ship needs these materials to function properly.",
                "Without them, I am stranded on your planet.",
                f"Quest: Bring me 6 Metal and 6 Glass for 100 XP!",
                "",
                "Press X to close at any time"
            ]
        }
        return base_dialogues.get(npc_type, ["Hello!", "Press X to close"])

    def get_image(self) -> Optional[pygame.Surface]:
        """Get the appropriate image for this NPC"""
        return NPC._npc_images.get(self.npc_type)

    def can_complete_quest(self, player_inventory: list) -> bool:
        """Check if player has enough items to complete the quest"""
        if self.quest_completed:
            return False

        # Handle multi-item quests (like the Alien's quest)
        if "item_types" in self.quest_requirements:
            # Multi-item quest (Alien)
            item_types = self.quest_requirements["item_types"]
            required_quantities = self.quest_requirements["quantities"]

            for i, required_type in enumerate(item_types):
                required_quantity = required_quantities[i]
                item_count = 0

                for item in player_inventory:
                    if hasattr(item, 'item_type') and item.item_type == required_type:
                        item_count += getattr(item, 'quantity', 1)
                    elif hasattr(item, 'trash_type') and item.trash_type == required_type:
                        item_count += getattr(item, 'quantity', 1)

                if item_count < required_quantity:
                    return False
            return True
        else:
            # Single-item quest (existing NPCs)
            required_type = self.quest_requirements["item_type"]
            required_quantity = self.quest_requirements["quantity"]

            item_count = 0
            for item in player_inventory:
                if hasattr(item, 'item_type') and item.item_type == required_type:
                    item_count += getattr(item, 'quantity', 1)
                elif hasattr(item, 'trash_type') and item.trash_type == required_type:
                    item_count += getattr(item, 'quantity', 1)

            return item_count >= required_quantity

    def complete_quest(self, player_inventory: list, player) -> bool:
        """Complete the quest - remove items and give XP"""
        if not self.can_complete_quest(player_inventory) or self.quest_completed:
            return False

        # Handle multi-item quests (like the Alien's quest)
        if "item_types" in self.quest_requirements:
            # Multi-item quest (Alien)
            item_types = self.quest_requirements["item_types"]
            required_quantities = self.quest_requirements["quantities"]

            for i, required_type in enumerate(item_types):
                required_quantity = required_quantities[i]
                items_to_remove = []
                remaining_needed = required_quantity

                for item in player_inventory:
                    if remaining_needed <= 0:
                        break

                    item_matches = False
                    if hasattr(item, 'item_type') and item.item_type == required_type:
                        item_matches = True
                    elif hasattr(item, 'trash_type') and item.trash_type == required_type:
                        item_matches = True

                    if item_matches:
                        item_quantity = getattr(item, 'quantity', 1)

                        if item_quantity <= remaining_needed:
                            items_to_remove.append(item)
                            remaining_needed -= item_quantity
                        else:
                            item.quantity -= remaining_needed
                            remaining_needed = 0

                # Remove items from inventory
                for item in items_to_remove:
                    player_inventory.remove(item)
        else:
            # Single-item quest (existing NPCs)
            required_type = self.quest_requirements["item_type"]
            required_quantity = self.quest_requirements["quantity"]
            items_to_remove = []
            remaining_needed = required_quantity

            for item in player_inventory:
                if remaining_needed <= 0:
                    break

                item_matches = False
                if hasattr(item, 'item_type') and item.item_type == required_type:
                    item_matches = True
                elif hasattr(item, 'trash_type') and item.trash_type == required_type:
                    item_matches = True

                if item_matches:
                    item_quantity = getattr(item, 'quantity', 1)

                    if item_quantity <= remaining_needed:
                        items_to_remove.append(item)
                        remaining_needed -= item_quantity
                    else:
                        item.quantity -= remaining_needed
                        remaining_needed = 0

            # Remove items from inventory
            for item in items_to_remove:
                player_inventory.remove(item)

        # Give XP to player
        player.xp += self.quest_reward_xp
        player.hp = player.max_hp
        self.quest_completed = True

        return True

    def draw(self, screen: pygame.Surface, x: int, y: int):
        """Draw this NPC at the specified screen position"""
        image = self.get_image()
        if image:
            img_rect = image.get_rect(center=(int(x), int(y)))
            screen.blit(image, img_rect)
        else:
            # Fallback to circle if no image (scaled to 1.5x)
            pygame.draw.circle(screen, self.color, (int(x), int(y)), 18)
            pygame.draw.circle(screen, WHITE, (int(x), int(y)), 18, 1)

    def draw_dialogue(self, screen: pygame.Surface, fonts: Dict[str, pygame.font.Font], player_inventory: list = None):
        """Draw the dialogue interface for this NPC with quest button"""
        font_small = fonts['small']
        font_tiny = fonts['tiny']

        # Create dialogue panel
        panel_size = DIALOGUE_PANEL_SIZE
        rect = pygame.Rect(
            SCREEN_WIDTH // 4, SCREEN_HEIGHT - panel_size[1] - 50,
            panel_size[0], panel_size[1]
        )

        # Semi-transparent background
        dialog_surface = pygame.Surface((rect.width, rect.height))
        dialog_surface.set_alpha(220)
        dialog_surface.fill(BLACK)
        screen.blit(dialog_surface, rect)

        # Border
        pygame.draw.rect(screen, WHITE, rect, 2)

        # Draw NPC image at 2x size above the dialogue box
        npc_image = self.get_image()
        if npc_image:
            # Scale to 2x size (original is 45x45, scaled to 90x90)
            scaled_image = pygame.transform.scale(npc_image, (90, 90))
            image_rect = scaled_image.get_rect(center=(rect.centerx, rect.top - 50))
            screen.blit(scaled_image, image_rect)

        # Title
        title_surf = font_small.render(f"Speaking to {self.name}:", True, WHITE)
        screen.blit(title_surf, (rect.x + 10, rect.y + 10))

        # Dialogue text (leave space for button at bottom)
        y_offset = 50
        text_area_height = rect.height - 80  # Reserve 80px for button area

        for line in self.dialogue:
            if y_offset + 25 > text_area_height:  # Prevent text overflow
                break
            surf = font_tiny.render(line, True, WHITE)
            screen.blit(surf, (rect.x + 20, rect.y + y_offset))
            y_offset += 25

        # Draw quest button at bottom
        self._draw_quest_button(screen, rect, fonts, player_inventory)

    def _draw_quest_button(self, screen: pygame.Surface, dialogue_rect: pygame.Rect,
                           fonts: Dict[str, pygame.font.Font], player_inventory: list = None):
        """Draw the GIVE ITEMS quest button"""
        if self.quest_completed:
            # Show completed status
            button_text = "QUEST COMPLETED!"
            button_color = (50, 150, 50)  # Green
            text_color = WHITE
            can_click = False
        else:
            # Check if player can complete quest
            can_complete = self.can_complete_quest(player_inventory) if player_inventory else False

            if can_complete:
                button_text = "GIVE ITEMS"
                button_color = (100, 150, 100)  # Light green
                text_color = WHITE
                can_click = True
            else:
                # Handle different quest types for button text
                if "item_types" in self.quest_requirements:
                    # Multi-item quest (Alien)
                    item_names = self.quest_requirements["item_names"]
                    quantities = self.quest_requirements["quantities"]
                    button_text = f"GIVE ITEMS (Need {quantities[0]} {item_names[0]} & {quantities[1]} {item_names[1]})"
                else:
                    # Single-item quest
                    required_qty = self.quest_requirements["quantity"]
                    item_name = self.quest_requirements["item_name"]
                    button_text = f"GIVE ITEMS (Need {required_qty} {item_name})"

                button_color = (100, 100, 100)  # Gray
                text_color = (150, 150, 150)  # Light gray text
                can_click = False

        # Button dimensions and position
        button_width = dialogue_rect.width - 40
        button_height = 30
        button_x = dialogue_rect.x + 20
        button_y = dialogue_rect.bottom - 45

        # Create button rect for click detection
        self.give_items_button_rect = pygame.Rect(button_x, button_y, button_width, button_height)

        # Draw button background
        pygame.draw.rect(screen, button_color, self.give_items_button_rect)
        pygame.draw.rect(screen, WHITE if can_click else (100, 100, 100), self.give_items_button_rect, 2)

        # Draw button text
        button_font = fonts['tiny']
        text_surf = button_font.render(button_text, True, text_color)
        text_rect = text_surf.get_rect(center=self.give_items_button_rect.center)
        screen.blit(text_surf, text_rect)

    def handle_click(self, pos: tuple, player_inventory: list, player) -> bool:
        """Handle click on NPC dialogue elements"""
        if (self.give_items_button_rect and
                self.give_items_button_rect.collidepoint(pos) and
                not self.quest_completed):

            if self.can_complete_quest(player_inventory):
                return self.complete_quest(player_inventory, player)

        return False

    def is_near_player(self, player_x: float, player_y: float, interaction_radius: float = DIALOGUE_RADIUS) -> bool:
        """Check if this NPC is within interaction range of the player"""
        distance = ((self.x - player_x) ** 2 + (self.y - player_y) ** 2) ** 0.5
        return distance < interaction_radius

    def start_interaction(self):
        """Called when player starts interacting with this NPC"""
        pass

    def end_interaction(self):
        """Called when player ends interaction with this NPC"""
        pass

    def set_world_bounds(self, world_width: int, world_height: int):
        """Set the world boundaries for this NPC"""
        self.world_width = world_width
        self.world_height = world_height

    def update(self):
        """Update NPC movement - skip movement for victory zone NPCs"""
        # NEW: Don't move if this is a victory zone NPC
        if hasattr(self, 'is_victory_zone_npc') and self.is_victory_zone_npc:
            return  # Stay completely still

        if hasattr(self, 'is_conductor') and self.is_conductor:
            self._update_conductor_movement()
        else:
            self._update_regular_movement()

    def _update_conductor_movement(self):
        """Simple random movement for conductor"""
        margin = 100  # Distance from edge

        # Change direction occasionally
        if random.random() < 0.01:  # 1% chance each frame to change direction
            self.move_direction = [
                random.uniform(-1, 1),
                random.uniform(-1, 1)
            ]
            # Normalize direction vector
            length = (self.move_direction[0] ** 2 + self.move_direction[1] ** 2) ** 0.5
            if length > 0:
                self.move_direction[0] /= length
                self.move_direction[1] /= length

        # Calculate next position
        next_x = self.x + self.move_direction[0] * self.move_speed
        next_y = self.y + self.move_direction[1] * self.move_speed

        # Keep within bounds (smaller area than full world)
        min_x = self.world_width * 0.3
        max_x = self.world_width * 0.7
        min_y = self.world_height * 0.4
        max_y = self.world_height * 0.8

        if next_x < min_x or next_x > max_x:
            self.move_direction[0] *= -1
            next_x = self.x + self.move_direction[0] * self.move_speed

        if next_y < min_y or next_y > max_y:
            self.move_direction[1] *= -1
            next_y = self.y + self.move_direction[1] * self.move_speed

        # Apply movement
        self.x = next_x
        self.y = next_y

    def _update_regular_movement(self):
        """Regular random wandering movement for other NPCs"""
        margin = 50  # Distance from edge to bounce

        if self.move_timer <= 0:
            # Choose new random direction and duration
            self.move_direction = [
                random.uniform(-1, 1),
                random.uniform(-1, 1)
            ]
            # Normalize direction vector
            length = (self.move_direction[0] ** 2 + self.move_direction[1] ** 2) ** 0.5
            if length > 0:
                self.move_direction[0] /= length
                self.move_direction[1] /= length
            self.move_timer = random.randint(60, 180)  # 1-3 seconds at 60 FPS
        else:
            self.move_timer -= 1

        # Calculate next position
        next_x = self.x + self.move_direction[0] * self.move_speed
        next_y = self.y + self.move_direction[1] * self.move_speed

        # Check for boundary collisions and bounce
        if next_x <= margin or next_x >= self.world_width - margin:
            self.move_direction[0] *= -1  # Reverse X direction
            next_x = self.x + self.move_direction[0] * self.move_speed
            # Reset movement timer to get new random direction soon
            self.move_timer = random.randint(30, 60)

        if next_y <= margin or next_y >= self.world_height - margin:
            self.move_direction[1] *= -1  # Reverse Y direction
            next_y = self.y + self.move_direction[1] * self.move_speed
            # Reset movement timer to get new random direction soon
            self.move_timer = random.randint(30, 60)

        # Apply the movement
        self.x = next_x
        self.y = next_y

        # Final safety check - clamp to boundaries
        self.x = max(margin, min(self.world_width - margin, self.x))
        self.y = max(margin, min(self.world_height - margin, self.y))

    def set_original_position(self, x, y):
        """Set the original position (maintained for compatibility)"""
        self.original_x = x
        self.original_y = y
        self.x = x
        self.y = y

    def constrain_to_bounds(self, world_width: int, world_height: int, margin: int = 15):
        """Keep NPC within world bounds"""
        self.x = max(margin, min(world_width - margin, self.x))
        self.y = max(margin, min(world_height - margin, self.y))

    def get_info_text(self) -> str:
        """Get brief info text about this NPC"""
        type_names = {
            1: "Gunar the Environmentalist",
            2: "Sweet Pea the Dog",
            3: "Train Conductor Man",
            4: "Delilah the Cat",
            5: "Alien"  # NEW: Added Alien NPC info
        }
        return type_names.get(self.npc_type, f"NPC #{self.npc_type}")

    def can_give_quest(self) -> bool:
        """Check if this NPC can give quests"""
        return not self.quest_completed

    def get_dialogue_options(self) -> list:
        """Get available dialogue options"""
        return ["Continue"]