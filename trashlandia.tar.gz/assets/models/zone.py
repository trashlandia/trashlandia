# models/zone.py - FIXED: Magic Pickle collection in hub zones + Alien Artifacts in Victory Zone
"""Zone model - Game world areas with train station hub system"""
import random
import math
import os
import pygame
import json
from typing import List, Tuple
from config.settings import *
from models.item import Item
from models.enemy import Enemy
from models.npc import NPC
from models.door import Door


class Zone:
    """Game world zone containing trash, enemies, NPCs, and doors"""

    def __init__(self, name: str, trash_density: int, world_width: int = 4000, world_height: int = 3000,
                 is_hub: bool = False, is_special: bool = False):
        self.name = name
        self.trash_density = trash_density
        self.world_width, self.world_height = world_width, world_height
        self.is_hub = is_hub
        self.is_special = is_special
        self.cleaned_amount = 0
        self.trash_items: List[Tuple[Item, int, int]] = []
        self.enemies: List[Tuple[Enemy, int, int]] = []
        self.npcs: List[Tuple[NPC, int, int]] = []
        self.doors: List[Door] = []
        self.is_restored = False
        self.initial_enemy_count = 0

    def cleanup_trash(self, x: int, y: int, radius: int = 30) -> tuple:
        """Collect trash near the given position - FIXED: Allow collection in hub zones"""
        items_collected = []
        remaining_items = []

        for item, tx, ty in self.trash_items:
            distance = math.sqrt((tx - x) ** 2 + (ty - y) ** 2)
            if distance < radius:
                items_collected.append(item)
            else:
                remaining_items.append((item, tx, ty))

        self.trash_items = remaining_items
        zone_restored = False

        if items_collected:
            self.cleaned_amount += len(items_collected)
            # Hub zones don't get "restored" like regular zones
            if len(self.trash_items) == 0 and not self.is_restored and not self.is_hub:
                self._restore_zone()
                zone_restored = True

        return items_collected, zone_restored

    def get_remaining_trash_count(self):
        """Returns the actual number of trash items remaining"""
        return len(self.trash_items)

    def _restore_zone(self):
        """Mark zone as restored when all trash is collected"""
        if not self.is_restored and not self.is_hub:
            self.is_restored = True
            self.enemies.clear()

    def handle_restoration(self, player):
        """Handle zone restoration - Award XP instead of HP/level"""
        zone_level = self._get_zone_level()

        # Calculate XP reward based on zone difficulty
        xp_reward = 80

        # Award XP
        player.xp += xp_reward

    def _generate_victory_zone_content(self):
        """Generate special content for the Final Victory Zone with spaceship, stationary NPCs, and alien artifacts"""
        if self.name != "Final Victory Zone":
            return

        # Center position for spaceship
        center_x = self.world_width // 2
        center_y = self.world_height // 2

        # Generate all 5 NPC types in a circle around the center
        npc_configs = [
            ("Alien", 5),
            ("Sweet Pea", 2),
            ("Train Conductor Man", 3),
            ("Delilah", 4),
            ("Gunar", 1)
        ]

        # Calculate circle positions for NPCs around the spaceship
        circle_radius = 350  # Distance from center
        angle_step = (2 * math.pi) / len(npc_configs)  # Equal spacing

        # Store NPC and spaceship positions for collision avoidance
        occupied_positions = [(center_x, center_y)]  # Spaceship position

        for i, (npc_name, npc_type) in enumerate(npc_configs):
            npc = NPC(npc_name, npc_type)
            npc.set_world_bounds(self.world_width, self.world_height)

            # Calculate position in circle around center
            angle = i * angle_step
            x = center_x + int(circle_radius * math.cos(angle))
            y = center_y + int(circle_radius * math.sin(angle))

            # Store NPC position
            occupied_positions.append((x, y))

            # Make NPC stationary by setting move_speed to 0
            npc.move_speed = 0
            npc.is_victory_zone_npc = True  # Flag to identify victory zone NPCs

            # CRITICAL FIX: Update dialogue AFTER setting the victory zone flag
            npc.dialogue = npc._get_dialogue_for_type(npc_type)

            npc.set_original_position(x, y)
            self.npcs.append((npc, x, y))

        # NEW: Generate 3 alien artifacts with proper spacing
        self._generate_alien_artifacts(occupied_positions, center_x, center_y)

    def _generate_alien_artifacts(self, occupied_positions, spaceship_x, spaceship_y):
        """Generate 3 alien artifacts in the victory zone with proper spacing - FIXED METHOD"""
        alien_artifact_count = 3
        min_distance = 200  # Minimum distance from spaceship and NPCs
        artifacts_generated = 0

        def is_too_close_to_occupied_positions(x, y):
            """Check if position is too close to spaceship or any NPC"""
            for occupied_x, occupied_y in occupied_positions:
                distance = math.sqrt((x - occupied_x) ** 2 + (y - occupied_y) ** 2)
                if distance < min_distance:
                    return True
            return False

        for artifact_num in range(1, alien_artifact_count + 1):
            attempts = 0
            max_attempts = 50  # Try up to 50 times to find a good position

            while attempts < max_attempts:
                # Generate random position within world bounds
                x = random.randint(200, self.world_width - 200)
                y = random.randint(200, self.world_height - 200)

                if not is_too_close_to_occupied_positions(x, y):
                    # FIXED: Create alien artifact with artifact_index set BEFORE __post_init__
                    # We need to bypass the normal Item creation to set artifact_index first
                    alien_artifact = Item.__new__(Item)  # Create without calling __init__

                    # Set the required attributes manually
                    alien_artifact.name = f"Alien Artifact {artifact_num}"
                    alien_artifact.item_type = ArtType.ALIEN_ARTIFACT
                    alien_artifact.quantity = 1
                    alien_artifact.description = f"A mysterious alien artifact from the stars. This is artifact #{artifact_num} of an ancient collection."
                    alien_artifact.is_equippable = False
                    alien_artifact.hp_bonus = 0
                    alien_artifact.attack_bonus = 0
                    alien_artifact.rect = None
                    alien_artifact.art_message = ""
                    alien_artifact.painting_index = -1
                    alien_artifact.poem_index = -1

                    # CRITICAL FIX: Set artifact_index BEFORE calling __post_init__
                    alien_artifact.artifact_index = artifact_num - 1  # 0-based index for accessing text arrays

                    # Now call __post_init__ to complete initialization
                    alien_artifact.__post_init__()

                    self.trash_items.append((alien_artifact, x, y))
                    artifacts_generated += 1

                    # Add this position to occupied positions to avoid clustering
                    occupied_positions.append((x, y))
                    break

                attempts += 1

            if attempts >= max_attempts:
                print(f"Warning: Could not find suitable position for Alien Artifact {artifact_num} after {max_attempts} attempts")

    def _generate_content(self, game):
        """Generate all zone content including doors - MODIFIED for victory zone"""
        if self.name == "Final Victory Zone":
            # Special handling for victory zone
            self._generate_victory_zone_content()
            # Add train door to return to train station
            train_door = Door(
                "Train Station",
                self.world_width - 200,
                self.world_height // 2,
                True,
                is_train_door=True
            )
            self.doors.append(train_door)
            return
        elif self.is_special:
            self._generate_special_enemy()
            # Add train door to return to train station
            train_door = Door(
                "Train Station",
                self.world_width - 200,
                self.world_height // 2,
                True,
                is_train_door=True
            )
            self.doors.append(train_door)
            return
        elif not self.is_hub:
            self._generate_doors(game)
            self._generate_trash()
            self._generate_enemies()
            self._generate_npcs()
        else:
            self._generate_doors(game)
            self._generate_hub_npcs()
            self._generate_hub_content()  # This creates Magic Pickles

    def _get_zone_art_items(self):
        """Get the specific art items for this zone - FIXED: Direct zone name mapping"""
        if self.is_hub:
            return {'paintings': [], 'poems': []}  # Hub zones don't have art items

        # FIXED: Map directly by zone name instead of using _get_zone_level()
        zone_art_mapping = {
            "Oozing Canal City": {  # Zone 1
                'paintings': [0],  # painting1 (0-based index)
                'poems': [0]  # poem1 (0-based index)
            },
            "Forest of Rusting Trees": {  # Zone 2
                'paintings': [1],  # painting2
                'poems': [1]  # poem2
            },
            "Wasteland Plains": {  # Zone 3
                'paintings': [2],  # painting3
                'poems': [2]  # poem3
            },
            "Toxic Swamplands": {  # Zone 4 - NEW (was missing!)
                'paintings': [3],  # painting4
                'poems': [3]  # poem4
            },
            "Burning Deserts": {  # Zone 5 - NEW (was missing!)
                'paintings': [4],  # painting5
                'poems': [4]  # poem5
            },
            "Frozen Wasteland": {  # Zone 6 - NEW (was missing!)
                'paintings': [5],  # painting6
                'poems': [5]  # poem6
            },
            "Volcanic Peaks": {  # Zone 7 - NEW (was missing!)
                'paintings': [6],  # painting7
                'poems': [6]  # poem7
            },
            "Dark Abyss": {  # Zone 8 - NEW (was missing!)
                'paintings': [7],  # painting8
                'poems': [7]  # poem8
            }
        }

        # FIXED: Use self.name directly instead of zone_level
        return zone_art_mapping.get(self.name, {'paintings': [], 'poems': []})

    def _generate_special_enemy(self):
        """Generate one powerful enemy for the special zone"""
        if not self.is_special:
            return

        # Create one very powerful enemy
        enemy = Enemy(EnemyType.BOSS, 10, 3)

        # Make it 12x stronger and bigger
        enemy.max_hp *= 70
        enemy.hp = enemy.max_hp
        enemy.attack *= 4
        enemy.move_speed *= 0.22

        # Place it in the center of the zone
        x = self.world_width // 2
        y = self.world_height // 2
        self.enemies.append((enemy, x, y))
        self.initial_enemy_count = 1

        # Try to load special enemy image
        paths = ["enemy2.png", "images/enemy2.png", "assets/enemy2.png"]
        for path in paths:
            try:
                if os.path.exists(path):
                    enemy.image = pygame.image.load(path).convert_alpha()
                    break
            except pygame.error as e:
                print(f"Error loading {path}: {e}")

    def _generate_doors(self, game):
        """Generate doors with train station hub system - MODIFIED: Only train doors for regular zones"""
        self.doors = []

        if self.is_hub:
            # Train Station: Create doors to all main zones
            self._generate_hub_doors(game)
        else:
            # Regular zones: ONLY create train door on the right side
            self._generate_train_door_only()

    def _generate_train_door_only(self):
        """Generate only a train door for regular zones - no regular doors"""
        # Every regular zone gets a train door on the far right, centered vertically
        train_door = Door(
            "Train Station",
            self.world_width - 200,
            self.world_height // 2,
            True,
            is_train_door=True
        )
        self.doors.append(train_door)

    def _generate_hub_doors(self, game):
        """Generate doors for the train station hub with proper positioning - UPDATED: Added 5 new zones"""
        # Create doors to all main zones (excluding hub, special zones, AND Final Victory Zone)
        main_zones = [
            zone for zone in game.zone_order
            if zone != "Train Station"
               and zone != "Final Victory Zone"  # ADDED: Explicitly exclude Final Victory Zone
               and not game.zones[zone].is_special
        ]

        center_x = self.world_width // 2
        center_y = self.world_height // 2
        door_spacing = 200  # Space between doors

        # Position first 3 doors (original zones) - left, top, right
        original_zones = main_zones[:3]  # First 3 zones
        new_zones = main_zones[3:]  # Last 5 zones

        for i, zone_name in enumerate(original_zones):
            if i == 0:  # Left door
                x = center_x - door_spacing
                y = center_y
            elif i == 1:  # Top door
                x = center_x
                y = center_y - door_spacing
            elif i == 2:  # Right door
                x = center_x + door_spacing
                y = center_y

            door = Door(zone_name, x, y, False, is_train_door=False)
            self.doors.append(door)

        # Position 5 new doors in a separate area (bottom section)
        # Arrange them in a semi-circle or line pattern at the bottom
        new_zone_start_y = center_y + door_spacing + 100  # Further down from center

        for i, zone_name in enumerate(new_zones):
            # Arrange the 5 new doors in a horizontal line at the bottom
            x_offset = (i - 2) * (door_spacing // 2)  # Center the 5 doors horizontally
            x = center_x + x_offset
            y = new_zone_start_y

            door = Door(zone_name, x, y, False, is_train_door=False)
            self.doors.append(door)

        # Add special door at the very bottom center
        special_door = Door(
            "BOSS ENEMY LEVEL",
            center_x,  # X position (center)
            self.world_height - 100,  # Y position (near bottom)
            False,
            is_train_door=False,
            is_special_door=True
        )
        self.doors.append(special_door)

        # After creating all doors, set the door positions for the conductor NPC
        if self.is_hub and self.npcs:
            for npc_tuple in self.npcs:
                npc = npc_tuple[0]
                if hasattr(npc, 'is_conductor') and npc.is_conductor:
                    npc.door_positions = [(door.x, door.y) for door in self.doors]
                    npc.current_door_index = 0
                    npc.pause_at_door = 0
                    break  # Only need to set for conductor

    def _position_hub_doors(self):
        """Position doors in hub zones around the center"""
        # Doors are already positioned in _generate_hub_doors with proper spacing
        # This method can be used for any additional positioning logic
        pass

    def update_enemies(self):
        """Update all enemies in the zone"""
        if self.is_hub:
            return  # Hub zones don't have enemies

        updated_enemies = []
        for enemy, x, y in self.enemies:
            enemy.x = x
            enemy.y = y
            enemy.update()
            updated_enemies.append((enemy, enemy.x, enemy.y))
        self.enemies = updated_enemies

    def update_npcs(self):
        """Update all NPCs in the zone"""
        updated_npcs = []
        for npc, x, y in self.npcs:
            npc.x = x
            npc.y = y
            npc.update()  # This will call our movement code
            updated_npcs.append((npc, npc.x, npc.y))
        self.npcs = updated_npcs

    def _generate_trash(self):
        """Generate trash items in the zone with zone-specific art items - FIXED"""
        if self.is_hub:
            return  # Hub zones don't have trash

        zone_level = self._get_zone_level()
        actual_trash_density = TRASH_BASE_DENSITY + (zone_level * TRASH_DENSITY_PER_LEVEL)
        actual_food_chance = FOOD_BASE_CHANCE + (zone_level * FOOD_CHANCE_PER_LEVEL)

        # Get door positions and create buffer zones
        door_buffer = 150  # Minimum distance from doors
        door_positions = [(door.x, door.y) for door in self.doors]

        # FIXED: Get zone-specific art items using corrected method
        zone_art = self._get_zone_art_items()
        art_items_count = 0

        def is_too_close_to_door(x, y):
            """Check if position is too close to any door"""
            for door_x, door_y in door_positions:
                distance = math.sqrt((x - door_x) ** 2 + (y - door_y) ** 2)
                if distance < door_buffer:
                    return True
            return False

        # Place zone-specific poetry items with door buffer check
        for poem_index in zone_art['poems']:
            attempts = 0
            while attempts < 10:  # Try up to 10 times to find a valid position
                poetry_x = random.randint(100, self.world_width - 100)
                poetry_y = random.randint(100, self.world_height - 100)
                if not is_too_close_to_door(poetry_x, poetry_y):
                    poetry_item = Item(
                        name=f"Poem {poem_index + 1}",
                        item_type=ArtType.POETRY,
                        quantity=1,
                        description=f"A beautiful piece of poetry (Poem {poem_index + 1}).",
                        poem_index=poem_index
                    )
                    self.trash_items.append((poetry_item, poetry_x, poetry_y))
                    art_items_count += 1
                    break
                attempts += 1

        # Place zone-specific painting items with door buffer check
        for painting_index in zone_art['paintings']:
            attempts = 0
            while attempts < 10:  # Try up to 10 times to find a valid position
                painting_x = random.randint(100, self.world_width - 100)
                painting_y = random.randint(100, self.world_height - 100)
                if not is_too_close_to_door(painting_x, painting_y):
                    painting_item = Item(
                        name=f"Painting {painting_index + 1}",
                        item_type=ArtType.PAINTING,
                        quantity=1,
                        description=f"A beautiful painting #{painting_index + 1} that can be viewed.",
                        painting_index=painting_index
                    )
                    self.trash_items.append((painting_item, painting_x, painting_y))
                    art_items_count += 1
                    break
                attempts += 1

        # Calculate remaining trash items needed (subtract art items from total)
        remaining_trash = actual_trash_density - art_items_count
        if remaining_trash > 0:
            # Calculate how many of each trash type we want (roughly equal)
            trash_types = list(TrashType)
            items_per_type = max(1, remaining_trash // len(trash_types))
            extra_items = remaining_trash % len(trash_types)

            # Generate each type of trash
            for i, trash_type in enumerate(trash_types):
                # Last type gets any extra items if division wasn't even
                count = items_per_type + (1 if i < extra_items else 0)

                for _ in range(count):
                    attempts = 0
                    while attempts < 10:  # Try up to 10 times to find a valid position
                        x = random.randint(100, self.world_width - 100)
                        y = random.randint(100, self.world_height - 100)

                        if not is_too_close_to_door(x, y):
                            if random.random() < actual_food_chance:
                                food_choice = random.random()
                                if food_choice < 0.4:
                                    item = Item(
                                        name="Apple",
                                        item_type=FoodType.FRUIT,
                                        quantity=1,
                                        description="Apple that restores HP.",
                                        hp_bonus=random.randint(20, 30)
                                    )
                                elif food_choice < 0.8:
                                    item = Item(
                                        name="Bread",
                                        item_type=FoodType.BREAD,
                                        quantity=1,
                                        description="Bread that provides speed boost.",
                                        hp_bonus=0
                                    )
                                else:
                                    item = Item(
                                        name="Dohnut",
                                        item_type=FoodType.DOHNUT,
                                        quantity=1,
                                        description="Dohnut that restores HP.",
                                        hp_bonus=random.randint(50, 70)
                                    )
                            else:
                                # Generate regular trash item of the current type
                                item = Item(
                                    name=f"{trash_type.value.capitalize()} Waste",
                                    item_type=trash_type,
                                    quantity=random.randint(1, 3),
                                    description=f"Common {trash_type.value} trash."
                                )

                            self.trash_items.append((item, x, y))
                            break
                        attempts += 1

    def _get_zone_level(self):
        """Determine zone level based on zone name - UPDATED: Added new zones"""
        zone_levels = {
            "Oozing Canal City": 1,
            "Forest of Rusting Trees": 2,
            "Wasteland Plains": 3,
            "Train Station": 0,  # Hub zones are level 0
            "Toxic Swamplands": 4,  # NEW Zone 4
            "Burning Deserts": 5,  # NEW Zone 5
            "Frozen Wasteland": 6,  # NEW Zone 6
            "Volcanic Peaks": 7,  # NEW Zone 7
            "Dark Abyss": 8,  # NEW Zone 8
            "BOSS ENEMY LEVEL": 3  # Boss zone
        }
        return zone_levels.get(self.name, 1)

    def _generate_enemies(self):
        """Generate enemies in non-hub zones - UPDATED: Added scaling for new zones"""
        if self.is_hub:
            return  # Hub zones don't have enemies

        zone_level = self._get_zone_level()

        # Custom enemy counts per zone - UPDATED: Added counts for new zones
        enemy_counts = {
            1: 10,  # Zone 1 (Oozing Canal City)
            2: 10,  # Zone 2 (Forest of Rusting Trees)
            3: 30,  # Zone 3 (Wasteland Plains)
            4: 10,  # Zone 4 (Toxic Swamplands) - NEW
            5: 10,  # Zone 5 (Burning Deserts) - NEW
            6: 10,  # Zone 6 (Frozen Wasteland) - NEW
            7: 10,  # Zone 7 (Volcanic Peaks) - NEW
            8: 10  # Zone 8 (Dark Abyss) - NEW
        }

        enemy_count = enemy_counts.get(zone_level, 4)  # Default to 4 if zone not found
        self.initial_enemy_count = enemy_count

        for _ in range(enemy_count):
            regular_enemy_types = [et for et in EnemyType if et != EnemyType.BOSS]
            enemy_type = random.choice(regular_enemy_types)
            enemy = Enemy(enemy_type, zone_level, zone_level)
            enemy.world_width = self.world_width
            enemy.world_height = self.world_height
            x = random.randint(200, self.world_width - 200)
            y = random.randint(200, self.world_height - 200)
            self.enemies.append((enemy, x, y))

    def _generate_hub_npcs(self):
        """Generate NPCs for the hub zone with simple movement"""
        # Generate Train Conductor for the hub
        conductor = NPC("Train Conductor Man", 3)
        x = self.world_width // 2
        y = self.world_height // 2 + 100  # Position below center
        conductor.set_original_position(x, y)
        conductor.set_world_bounds(self.world_width, self.world_height)

        # Set movement properties (simpler version)
        conductor.move_speed = 0.5  # Moderate speed
        conductor.is_conductor = True  # Mark as conductor

        self.npcs.append((conductor, x, y))

    def _generate_npcs(self):
        """Generate exactly 3 NPCs in non-hub zones - UPDATED: Added Cat NPC (type 4)"""
        if self.is_hub:
            return  # Hub zones don't have NPCs

        # Generate 3 NPCs: Gunar (type 1), Sweet Pea (type 2), and Delilah the Cat (type 4)
        npc_configs = [
            ("Gunar", 1),
            ("Sweet Pea", 2),
            ("Delilah", 4),  # NEW: Added Cat NPC
            ("Alien", 5)
        ]

        for i, (npc_name, npc_type) in enumerate(npc_configs):
            npc = NPC(npc_name, npc_type)
            npc.set_world_bounds(self.world_width, self.world_height)

            # Position NPCs in different areas of the zone to avoid clustering
            if i == 0:  # Gunar - left side of zone
                x = random.randint(200, self.world_width // 2 - 100)
                y = random.randint(200, self.world_height - 200)
            elif i == 1:  # Sweet Pea - right side of zone
                x = random.randint(self.world_width // 2 + 100, self.world_width - 200)
                y = random.randint(200, self.world_height - 200)
            else:  # Delilah the Cat - center area
                x = random.randint(self.world_width // 3, 2 * self.world_width // 3)
                y = random.randint(self.world_height // 3, 2 * self.world_height // 3)

            npc.set_original_position(x, y)
            self.npcs.append((npc, x, y))

    def _generate_hub_content(self):
        """Generate content specifically for the Train Station hub - includes Magic Pickles"""
        if not self.is_hub or self.name != "Train Station":
            return

        # Generate 3-5 Magic Pickles scattered around the hub
        magic_pickle_count = random.randint(3, 5)

        # Get door positions to avoid spawning too close
        door_buffer = 150
        door_positions = [(door.x, door.y) for door in self.doors]

        def is_too_close_to_door(x, y):
            """Check if position is too close to any door"""
            for door_x, door_y in door_positions:
                distance = math.sqrt((x - door_x) ** 2 + (y - door_y) ** 2)
                if distance < door_buffer:
                    return True
            return False

        pickles_generated = 0
        for _ in range(magic_pickle_count):
            attempts = 0
            while attempts < 15:  # Try multiple times to find good positions
                x = random.randint(200, self.world_width - 200)
                y = random.randint(200, self.world_height - 200)

                if not is_too_close_to_door(x, y):
                    magic_pickle = Item(
                        name="Magic Pickle",
                        item_type=FoodType.MAGIC_PICKLE,
                        quantity=1,
                        description="Magical pickle that fully heals and provides extended speed boost.",
                        hp_bonus=0  # Full heal handled in consumption
                    )
                    self.trash_items.append((magic_pickle, x, y))
                    pickles_generated += 1
                    break
                attempts += 1