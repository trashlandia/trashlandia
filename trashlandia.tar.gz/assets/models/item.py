# models/item.py
import random
import pygame
import os
import math
from dataclasses import dataclass
from typing import Union, Dict, Optional, ClassVar
from config.settings import *


@dataclass
class Item:
    """Game item class with drawing capabilities and image management"""
    name: str = "Item"
    item_type: Union[TrashType, FoodType, ArtType, None] = None
    quantity: int = 1
    description: str = ""
    is_equippable: bool = False
    hp_bonus: int = 0
    attack_bonus: int = 0
    rect: object = None
    art_message: str = ""  # For poetry
    painting_index: int = -1  # For tracking which painting this is
    poem_index: int = -1  # For tracking which poem this is

    # Class variables for shared image resources
    _trash_images: ClassVar[Dict[TrashType, pygame.Surface]] = {}
    _food_images: ClassVar[Dict[FoodType, pygame.Surface]] = {}
    _art_images: ClassVar[Dict[ArtType, pygame.Surface]] = {}
    _painting_display_images: ClassVar[Dict[ArtType, list]] = {}  # List of JPEG surfaces for paintings
    _images_loaded: ClassVar[bool] = False
    _art_messages: ClassVar[Dict[str, str]] = {}

    def __post_init__(self):
        """Initialize item stats after creation"""
        equipment_stats = {
            "Metal Sword": (0, 5),
            "Metal Spoon": (0, 1),
            "Glass Knife": (0, 9),
            "Paper Knife": (0, 2),
            "Bio Filter": (30, 0),
            "Metal Knife": (0, 5)
        }

        if self.name in equipment_stats:
            self.is_equippable = True
            self.hp_bonus, self.attack_bonus = equipment_stats[self.name]
        elif self.name == "Apple":
            self.item_type = FoodType.FRUIT
        elif self.name == "Bread":
            self.item_type = FoodType.BREAD
        elif self.name == "Dohnut":
            self.item_type = FoodType.DOHNUT
            if not hasattr(self, 'hp_bonus') or self.hp_bonus == 0:
                self.hp_bonus = random.randint(15, 45)  # Slightly better than Apple
        elif self.name == "Magic Pickle":  # NEW: Add Magic Pickle handling
            self.item_type = FoodType.MAGIC_PICKLE
            self.hp_bonus = 0  # Full heal is handled in consumption logic
        elif self.name.startswith("Poem"):
            self.item_type = ArtType.POETRY
            # Initialize poem_index before loading message
            try:
                self.poem_index = int(self.name.split()[1]) - 1  # Convert to 0-based index
            except (IndexError, ValueError):
                self.poem_index = 0
            self._load_art_message()
        elif self.name.startswith("Painting"):
            self.item_type = ArtType.PAINTING
            if not hasattr(self, 'painting_index') or self.painting_index < 0:
                try:
                    num = int(self.name.split()[1])
                    self.painting_index = num - 1  # Convert to 0-based index
                except (IndexError, ValueError):
                    self.painting_index = 0  # Default to first painting
        elif self.name.startswith("Alien Artifact"):  # NEW: Handle alien artifacts
            self.item_type = ArtType.ALIEN_ARTIFACT
            self._load_alien_artifact_message()

        if not Item._images_loaded:
            Item.load_all_images()

    def _load_art_message(self):
        """Load art message from file with web compatibility"""
        if self.item_type == ArtType.POETRY and hasattr(self, 'poem_index') and self.poem_index >= 0:
            try:
                # Try different paths for the poem file
                possible_paths = [
                    f"poem{self.poem_index + 1}.txt",
                    f"data/poem{self.poem_index + 1}.txt",
                    f"assets/poem{self.poem_index + 1}.txt"
                ]

                for path in possible_paths:
                    try:
                        # For regular file system
                        if os.path.exists(path):
                            with open(path, 'r', encoding='utf-8') as f:
                                self.art_message = f.read()
                            return
                    except:
                        # For web environment or other issues
                        try:
                            with open(path, 'r', encoding='utf-8') as f:
                                self.art_message = f.read()
                            return
                        except:
                            continue

                # Fallback: Use embedded poem texts
                fallback_poems = [
                    "The waste stretches far,\nEarth's forgotten scars remain,\nHope blooms in cleanup.",
                    "Rusting trees stand tall,\nWhispering of better days,\nRecycling brings life.",
                    "Plains of discarded dreams,\nWhere plastic flowers once grew,\nRestoration starts.",
                    "Toxic swamps await,\nHealing through careful effort,\nBeauty returns soon.",
                    "Deserts burning bright,\nCooled by environmental care,\nOasis appears.",
                    "Frozen wastelands thaw,\nWith warmth of conservation,\nLife begins anew.",
                    "Volcanic peaks smoke,\nCalmed by sustainable ways,\nNew growth emerges.",
                    "Dark abyss recedes,\nLight returns with each small step,\nWorld restored at last."
                ]

                if self.poem_index < len(fallback_poems):
                    self.art_message = fallback_poems[self.poem_index]
                else:
                    self.art_message = "A beautiful piece of poetry about environmental restoration."

            except Exception as e:
                print(f"Error loading poem: {e}")
                self.art_message = "A beautiful piece of poetry about environmental restoration."

    def _load_alien_artifact_message(self):
        """Load alien artifact message with web compatibility"""
        if self.item_type == ArtType.ALIEN_ARTIFACT and hasattr(self, 'artifact_index'):
            # Use embedded messages for web compatibility
            artifact_messages = [
                "This strange crystalline structure pulses with otherworldly energy. Ancient symbols dance across its surface, telling stories of distant civilizations among the stars.",
                "A metallic orb of impossible geometry hovers silently. Its surface reflects not light, but memories of a thousand worlds, each more beautiful than the last.",
                "Tendrils of pure energy flow through this translucent artifact. As you approach, whispers of cosmic knowledge fill your mind with visions of galactic harmony."
            ]

            if hasattr(self, 'artifact_index') and self.artifact_index < len(artifact_messages):
                self.art_message = artifact_messages[self.artifact_index]
            else:
                self.art_message = "An alien artifact of unknown origin and purpose."

    @classmethod
    def load_all_images(cls):
        """Load all item images - paintings as JPEGs, others as PNGs"""
        if cls._images_loaded:
            return

        for trash_type, filename in ASSET_PATHS['trash_images'].items():
            image = cls._load_image_from_paths(filename)
            if image:
                cls._trash_images[trash_type] = image.convert_alpha()

        for food_type, filename in ASSET_PATHS['food_images'].items():
            image = cls._load_image_from_paths(filename)
            if image:
                cls._food_images[food_type] = image.convert_alpha()

        for art_type, filename in ASSET_PATHS['art_images'].items():
            image = cls._load_image_from_paths(filename)
            if image:
                cls._art_images[art_type] = image.convert_alpha()

        if 'painting_display_images' in ASSET_PATHS:
            cls._painting_display_images = {}
            for art_type, filenames in ASSET_PATHS['painting_display_images'].items():
                image_list = []
                for filename in filenames:
                    loaded = False
                    for path_prefix in ASSET_SEARCH_PATHS:
                        full_path = os.path.join(path_prefix, filename) if path_prefix else filename
                        if os.path.exists(full_path):
                            try:
                                image = pygame.image.load(full_path).convert()
                                image_list.append(image)
                                loaded = True
                                break
                            except pygame.error as e:
                                print(f"Error loading painting {filename}: {e}")
                    if not loaded:
                        print(f"Creating placeholder for missing painting: {filename}")
                        placeholder = pygame.Surface((100, 100))
                        placeholder.fill(ART_COLORS[ArtType.PAINTING])
                        image_list.append(placeholder)

                cls._painting_display_images[art_type] = image_list

        cls._images_loaded = True

    @staticmethod
    def _load_image_from_paths(filename: str) -> Optional[pygame.Surface]:
        """Try to load image from multiple possible paths (supports both JPG and PNG)"""
        for path_prefix in ASSET_SEARCH_PATHS:
            full_path = os.path.join(path_prefix, filename) if path_prefix else filename
            if os.path.exists(full_path):
                try:
                    if filename.lower().endswith('.png'):
                        return pygame.image.load(full_path).convert_alpha()
                    return pygame.image.load(full_path).convert()
                except pygame.error as e:
                    print(f"Error loading {full_path}: {e}")
            elif filename.lower().endswith('.jpg'):
                jpeg_path = os.path.join(path_prefix,
                                         filename.replace('.jpg', '.jpeg')) if path_prefix else filename.replace('.jpg',
                                                                                                                 '.jpeg')
                if os.path.exists(jpeg_path):
                    try:
                        return pygame.image.load(jpeg_path).convert()
                    except pygame.error as e:
                        print(f"Error loading {jpeg_path}: {e}")
        return None

    def get_image(self, size: tuple = (24, 24)) -> Optional[pygame.Surface]:
        """Get the appropriate image for this item (PNG icons)"""
        if not Item._images_loaded:
            Item.load_all_images()

        if isinstance(self.item_type, TrashType):
            image = Item._trash_images.get(self.item_type)
        elif isinstance(self.item_type, FoodType):
            image = Item._food_images.get(self.item_type)
        elif isinstance(self.item_type, ArtType):
            image = Item._art_images.get(self.item_type)
        else:
            return None

        if image and size != image.get_size():
            return pygame.transform.scale(image, size)
        return image

    def get_painting_display_image(self) -> Optional[pygame.Surface]:
        """Get specific JPEG painting image"""
        if (isinstance(self.item_type, ArtType) and
                self.item_type == ArtType.PAINTING and
                hasattr(self, 'painting_index')):

            paintings = Item._painting_display_images.get(ArtType.PAINTING, [])

            if 0 <= self.painting_index < len(paintings):
                return paintings[self.painting_index]
            return None

        return None

    def draw(self, screen: pygame.Surface, x: int, y: int, size: tuple = (24, 24)):
        """Draw this item at the specified screen position"""
        image = self.get_image(size)
        if image:
            img_rect = image.get_rect(center=(int(x), int(y)))
            screen.blit(image, img_rect)
        else:
            color = self._get_fallback_color()
            pygame.draw.circle(screen, color, (int(x), int(y)), size[0] // 2)

    def _get_fallback_color(self) -> tuple:
        """Get fallback color for items without images"""
        if isinstance(self.item_type, TrashType):
            return TRASH_COLORS.get(self.item_type, GRAY)
        elif isinstance(self.item_type, FoodType):
            return FOOD_COLORS.get(self.item_type, WHITE)
        elif isinstance(self.item_type, ArtType):
            return ART_COLORS.get(self.item_type, WHITE)
        return WHITE

    def draw_inventory_item(self, screen: pygame.Surface, x: int, y: int, width: int, height: int,
                            is_equipped: bool = False, font_tiny=None):
        """Draw this item in inventory with all details"""
        # Item background
        item_color = UI_COLORS['equipped_item'] if is_equipped else UI_COLORS['panel_bg']
        item_rect = pygame.Rect(x, y, width, height)
        pygame.draw.rect(screen, item_color, item_rect)
        pygame.draw.rect(screen, WHITE, item_rect, 1)

        # Store rect for click detection
        self.rect = item_rect

        # Draw item icon
        icon_size = min(20, height - 6)
        icon_x = x + icon_size // 2 + 3
        icon_y = y + height // 2

        image = self.get_image((icon_size, icon_size))
        if image:
            img_rect = image.get_rect(center=(icon_x, icon_y))
            screen.blit(image, img_rect)

        # Draw item information
        if font_tiny:
            self._draw_item_text(screen, x, y, width, height, font_tiny, icon_size, is_equipped)

    def _draw_item_text(self, screen: pygame.Surface, x: int, y: int, width: int, height: int,
                        font_tiny, icon_size: int, is_equipped: bool):
        """Draw item text information in inventory"""
        text_start_x = x + icon_size + 8

        # Item name
        name_surf = font_tiny.render(self.name, True, WHITE)
        screen.blit(name_surf, (text_start_x, y + 3))

        # Additional info on second line
        info_line = ""
        info_color = WHITE

        if self.is_equippable:
            bonus_parts = []
            if self.hp_bonus > 0:
                bonus_parts.append(f"+{self.hp_bonus}HP")
            if self.attack_bonus > 0:
                bonus_parts.append(f"+{self.attack_bonus}ATK")
            info_line = " ".join(bonus_parts)
            info_color = GREEN if not is_equipped else WHITE
        elif isinstance(self.item_type, FoodType):
            if self.item_type in [FoodType.FRUIT, FoodType.DOHNUT]:
                info_line = f"+{self.hp_bonus}HP"
            elif self.item_type == FoodType.BREAD:
                info_line = "Speed Boost"
                info_color = YELLOW
            elif self.item_type == FoodType.MAGIC_PICKLE:
                info_line = "Full Heal + Speed"
                info_color = (0, 255, 0)  # Bright green
        elif isinstance(self.item_type, ArtType):
            if self.item_type == ArtType.POETRY:
                info_line = "Click to read"
            elif self.item_type == ArtType.PAINTING:
                info_line = "Click to view"
            elif self.item_type == ArtType.ALIEN_ARTIFACT:  # NEW: Handle alien artifacts
                info_line = "Click to examine"
            info_color = (200, 200, 255)  # Light blue for art

        # Draw the info line if it exists
        if info_line:
            info_surf = font_tiny.render(info_line, True, info_color)
            screen.blit(info_surf, (text_start_x, y + 20))

        # Draw quantity if more than 1 (except for art items)
        if hasattr(self, 'quantity') and self.quantity > 1 and not isinstance(self.item_type, ArtType):
            qty_surf = font_tiny.render(f"x{self.quantity}", True, (200, 200, 200))
            qty_x = x + width - qty_surf.get_width() - 10
            screen.blit(qty_surf, (qty_x, y + 20))

    def get_category_for_crafting(self) -> str:
        """Get crafting category for this item (used by crafting system)"""
        if not hasattr(self, 'item_type') or not isinstance(self.item_type, TrashType):
            return "Other"

        type_to_category = {
            TrashType.METAL: "Metal",
            TrashType.GLASS: "Glass",
            TrashType.PLASTIC: "Plastic",
            TrashType.PAPER: "Paper"
        }
        return type_to_category.get(self.item_type, "Other")

    def can_stack_with(self, other: 'Item') -> bool:
        """Check if this item can stack with another item - Art items don't stack"""
        if isinstance(self.item_type, ArtType) or isinstance(other.item_type, ArtType):
            return False

        return (self.name == other.name and
                not self.is_equippable and
                self.item_type == other.item_type)

    def stack_with(self, other: 'Item'):
        """Stack this item with another compatible item"""
        if self.can_stack_with(other):
            self.quantity += other.quantity

    def get_tooltip_text(self) -> list:
        """Get tooltip text for this item"""
        lines = [self.name]

        if self.description:
            lines.append(self.description)

        if self.is_equippable:
            if self.hp_bonus > 0:
                lines.append(f"HP Bonus: +{self.hp_bonus}")
            if self.attack_bonus > 0:
                lines.append(f"Attack Bonus: +{self.attack_bonus}")
        elif isinstance(self.item_type, FoodType):
            if self.item_type in [FoodType.FRUIT, FoodType.DOHNUT]:
                lines.append(f"Restores {self.hp_bonus} HP")
            elif self.item_type == FoodType.BREAD:
                lines.append("Grants speed boost")
            elif self.item_type == FoodType.MAGIC_PICKLE:  # NEW: Add Magic Pickle tooltip
                lines.append("Fully heals HP")
                lines.append("Grants extended speed boost")
        elif isinstance(self.item_type, ArtType):
            if self.item_type == ArtType.POETRY:
                lines.append("Click to read poetry")
            elif self.item_type == ArtType.PAINTING:
                lines.append("Click to view painting")
            elif self.item_type == ArtType.ALIEN_ARTIFACT:  # NEW: Handle alien artifacts
                lines.append("Click to examine alien artifact")

        if hasattr(self, 'quantity') and self.quantity > 1:
            lines.append(f"Quantity: {self.quantity}")

        return lines

    class ArtDisplayManager:
        """Handles display of art items (poetry and paintings)"""

        def __init__(self, screen, fonts):
            self.screen = screen
            self.fonts = fonts
            self.show_art_dialogue = False
            self.current_art_item = None
            self.art_dialogue_scroll_pos = 0
            self.show_painting_viewer = False
            self.current_painting_item = None
            self.art_dialogue_dragging = False

        def show_art_item_dialogue(self, art_item):
            """Show dialogue for an art item"""
            self.current_art_item = art_item
            self.show_art_dialogue = True
            self.art_dialogue_scroll_pos = 0

        def show_painting_item_viewer(self, painting_item):
            """Show viewer for a painting item"""
            self.current_painting_item = painting_item
            self.show_painting_viewer = True

        def draw_art_dialogue(self):
            """Draw scrollable art item dialogue box - handles both poetry and alien artifacts with crystal"""
            if not self.show_art_dialogue or not self.current_art_item:
                return

            # Semi-transparent overlay
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            overlay.set_alpha(180)
            overlay.fill(BLACK)
            self.screen.blit(overlay, (0, 0))

            # Expanded dialogue panel (scroll dimensions)
            panel_width = int(SCREEN_WIDTH * 0.8)
            panel_height = int(SCREEN_HEIGHT * 0.85)
            panel_rect = pygame.Rect(0, 0, panel_width, panel_height)
            panel_rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)

            # Determine the type and draw appropriate background
            is_alien_artifact = (hasattr(self.current_art_item, 'item_type') and
                                 self.current_art_item.item_type == ArtType.ALIEN_ARTIFACT)

            if is_alien_artifact:
                self._draw_alien_artifact_background(panel_rect)
            else:
                self._draw_scroll_background(panel_rect)

            # Title area with decorative header - adjusted positioning for crystal
            title_y_offset = 60 if not is_alien_artifact else 100  # More space for crystal

            if is_alien_artifact:
                title_text = f"Alien Artifact {getattr(self.current_art_item, 'artifact_index', 0) + 1}"
                self._draw_alien_artifact_title(panel_rect.centerx, panel_rect.y + title_y_offset, title_text)
            else:
                title_text = "Poetry Reading"
                if hasattr(self.current_art_item, 'poem_index'):
                    title_text = f"Poem {self.current_art_item.poem_index + 1}"
                self._draw_scroll_title(panel_rect.centerx, panel_rect.y + title_y_offset, title_text)

            # Text content area - adjusted for crystal space
            scroll_border = 40
            content_y_start = 120 if not is_alien_artifact else 180  # More space for alien artifacts

            content_rect = pygame.Rect(
                panel_rect.x + scroll_border,
                panel_rect.y + content_y_start,
                panel_rect.width - (scroll_border * 2),
                panel_rect.height - content_y_start - 100  # Adjusted bottom margin
            )
            self.art_dialogue_content_rect = content_rect
            self.art_dialogue_visible_height = content_rect.height

            # Draw background for text area
            if is_alien_artifact:
                self._draw_alien_tech_background(content_rect)
            else:
                self._draw_aged_paper_background(content_rect)

            # Process the text content (rest remains the same)
            message = self.current_art_item.art_message
            font = self.fonts['normal']
            line_height = 35
            padding = 20
            max_width = content_rect.width - 60

            # Split into paragraphs and wrap lines
            paragraphs = message.split('\n')
            wrapped_lines = []

            for para in paragraphs:
                if not para.strip():
                    wrapped_lines.append("")
                    continue

                words = para.split()
                if not words:
                    wrapped_lines.append("")
                    continue

                current_line = ""
                for word in words:
                    test_line = f"{current_line} {word}" if current_line else word
                    if font.size(test_line)[0] <= max_width:
                        current_line = test_line
                    else:
                        if current_line:
                            wrapped_lines.append(current_line)
                        current_line = word

                if current_line:
                    wrapped_lines.append(current_line)

            # Calculate total content height
            total_content_height = len(wrapped_lines) * line_height + (padding * 2)
            self.art_dialogue_total_height = total_content_height

            # Calculate maximum scroll position
            max_scroll = max(0, total_content_height - content_rect.height)
            self.art_dialogue_scroll_pos = max(0, min(self.art_dialogue_scroll_pos, max_scroll))

            # Create clipping region for text
            clip_rect = pygame.Rect(content_rect)
            old_clip = self.screen.get_clip()
            self.screen.set_clip(clip_rect)

            # Draw text lines with scroll offset
            start_y = content_rect.y + padding - self.art_dialogue_scroll_pos

            # Different text colors for different artifact types
            text_color = (0, 255, 255) if is_alien_artifact else (40, 30, 20)  # Cyan for alien, brown for poetry

            for i, line in enumerate(wrapped_lines):
                line_y = start_y + (i * line_height)

                if line_y + line_height >= content_rect.y and line_y <= content_rect.bottom:
                    if line.strip():
                        text_surf = font.render(line, True, text_color)
                        self.screen.blit(text_surf, (content_rect.x + padding, line_y))

            # Restore clipping
            self.screen.set_clip(old_clip)

            # Draw scroll bar if needed
            if max_scroll > 0:
                if is_alien_artifact:
                    self._draw_alien_scrollbar(content_rect, max_scroll)
                else:
                    self._draw_scroll_scrollbar(content_rect, max_scroll)

            # Close button
            if is_alien_artifact:
                self._draw_alien_close_button(panel_rect)
            else:
                self._draw_scroll_close_button(panel_rect)

        def _draw_alien_artifact_background(self, panel_rect):
            """Draw alien technology-style background - extended for crystal space"""
            # Extend panel upward to accommodate crystal
            extended_rect = pygame.Rect(
                panel_rect.x,
                panel_rect.y - 100,  # Extra space for crystal
                panel_rect.width,
                panel_rect.height + 100
            )

            # Main panel - dark metallic color
            tech_color = (20, 25, 35)  # Dark blue-gray
            pygame.draw.rect(self.screen, tech_color, extended_rect)

            # Tech border with glowing effect
            border_colors = [(0, 100, 150), (0, 150, 200), (0, 200, 255)]
            for i, color in enumerate(border_colors):
                border_rect = pygame.Rect(
                    extended_rect.x - i - 1,
                    extended_rect.y - i - 1,
                    extended_rect.width + (i + 1) * 2,
                    extended_rect.height + (i + 1) * 2
                )
                pygame.draw.rect(self.screen, color, border_rect, 2)

            # Tech pattern overlay
            pattern_color = (0, 80, 120)
            for y in range(extended_rect.y + 10, extended_rect.bottom - 10, 20):
                pygame.draw.line(self.screen, pattern_color,
                                 (extended_rect.x + 10, y),
                                 (extended_rect.right - 10, y), 1)

        def _draw_alien_artifact_title(self, center_x, y, title_text):
            """Draw alien technology-style title with animated crystal"""
            # Create sparkling crystal at the top
            crystal_y = y - 80
            self._draw_sparkling_crystal(center_x, crystal_y)

            # Glowing title effect (moved down to accommodate crystal)
            title_y = y + 40
            glow_colors = [(0, 255, 255, 100), (0, 200, 255, 150), (0, 150, 200, 200)]

            for i, color in enumerate(glow_colors):
                offset = len(glow_colors) - i
                title_surf = self.fonts['large'].render(title_text, True, color[:3])
                title_rect = title_surf.get_rect(center=(center_x + offset, title_y + offset))
                self.screen.blit(title_surf, title_rect)

            # Main title in bright cyan
            title_color = (0, 255, 255)
            title_surf = self.fonts['large'].render(title_text, True, title_color)
            title_rect = title_surf.get_rect(center=(center_x, title_y))
            self.screen.blit(title_surf, title_rect)

            # Tech decorative elements
            flourish_color = (0, 200, 255)
            flourish_y = title_y + title_surf.get_height() // 2

            # Left tech line
            left_end = center_x - title_surf.get_width() // 2 - 20
            pygame.draw.line(self.screen, flourish_color, (left_end - 40, flourish_y), (left_end, flourish_y), 3)
            pygame.draw.circle(self.screen, flourish_color, (left_end - 40, flourish_y), 6)

            # Right tech line
            right_start = center_x + title_surf.get_width() // 2 + 20
            pygame.draw.line(self.screen, flourish_color, (right_start, flourish_y), (right_start + 40, flourish_y), 3)
            pygame.draw.circle(self.screen, flourish_color, (right_start + 40, flourish_y), 6)

        def _draw_sparkling_crystal(self, center_x, center_y):
            """Draw an animated sparkling crystal image"""
            current_time = pygame.time.get_ticks()

            # Main crystal - diamond shape
            crystal_size = 60
            crystal_points = [
                (center_x, center_y - crystal_size // 2),  # Top
                (center_x + crystal_size // 3, center_y),  # Right
                (center_x, center_y + crystal_size // 2),  # Bottom
                (center_x - crystal_size // 3, center_y)  # Left
            ]

            # Draw crystal with gradient effect
            crystal_colors = [
                (100, 200, 255),  # Light blue
                (50, 150, 255),  # Medium blue
                (0, 100, 200)  # Dark blue
            ]

            # Draw multiple layers for depth
            for i, color in enumerate(crystal_colors):
                offset = i * 3
                offset_points = [
                    (point[0] - offset if j % 2 == 0 else point[0] + offset,
                     point[1] - offset if j < 2 else point[1] + offset)
                    for j, point in enumerate(crystal_points)
                ]
                pygame.draw.polygon(self.screen, color, offset_points)

            # Add crystal facets (internal lines)
            facet_color = (200, 255, 255)
            pygame.draw.line(self.screen, facet_color,
                             (center_x - crystal_size // 4, center_y - crystal_size // 4),
                             (center_x + crystal_size // 4, center_y + crystal_size // 4), 2)
            pygame.draw.line(self.screen, facet_color,
                             (center_x + crystal_size // 4, center_y - crystal_size // 4),
                             (center_x - crystal_size // 4, center_y + crystal_size // 4), 2)

            # Animated sparkles around crystal
            num_sparkles = 8
            sparkle_radius = crystal_size + 20

            for i in range(num_sparkles):
                angle = (current_time / 1000.0 + i * math.pi * 2 / num_sparkles) % (math.pi * 2)
                sparkle_x = center_x + math.cos(angle) * sparkle_radius
                sparkle_y = center_y + math.sin(angle) * sparkle_radius

                # Sparkle animation - pulsing size
                pulse = abs(math.sin(current_time / 300.0 + i))
                sparkle_size = int(3 + pulse * 4)

                # Draw sparkle as a small star
                self._draw_sparkle(sparkle_x, sparkle_y, sparkle_size)

            # Central glow effect
            glow_radius = int(crystal_size // 2 + 10 * abs(math.sin(current_time / 500.0)))
            glow_surface = pygame.Surface((glow_radius * 2, glow_radius * 2), pygame.SRCALPHA)

            # Create radial glow
            for r in range(glow_radius, 0, -2):
                alpha = int(30 * (1 - r / glow_radius))
                if alpha > 0:
                    pygame.draw.circle(glow_surface, (0, 255, 255, alpha),
                                       (glow_radius, glow_radius), r)

            self.screen.blit(glow_surface,
                             (center_x - glow_radius, center_y - glow_radius))

        def _draw_sparkle(self, x, y, size):
            """Draw a small sparkle/star shape"""
            sparkle_color = (255, 255, 255)

            # Draw sparkle as intersecting lines
            pygame.draw.line(self.screen, sparkle_color,
                             (x - size, y), (x + size, y), 2)
            pygame.draw.line(self.screen, sparkle_color,
                             (x, y - size), (x, y + size), 2)

            # Add diagonal lines for more star-like appearance
            diagonal_size = size * 0.7
            pygame.draw.line(self.screen, sparkle_color,
                             (x - diagonal_size, y - diagonal_size),
                             (x + diagonal_size, y + diagonal_size), 1)
            pygame.draw.line(self.screen, sparkle_color,
                             (x + diagonal_size, y - diagonal_size),
                             (x - diagonal_size, y + diagonal_size), 1)

        def _draw_alien_tech_background(self, content_rect):
            """Draw alien technology background for text area"""
            # Dark tech background
            tech_bg_color = (15, 20, 30)
            pygame.draw.rect(self.screen, tech_bg_color, content_rect)

            # Subtle tech grid
            grid_color = (0, 60, 100)
            for x in range(content_rect.x, content_rect.right, 30):
                pygame.draw.line(self.screen, grid_color, (x, content_rect.y), (x, content_rect.bottom), 1)
            for y in range(content_rect.y, content_rect.bottom, 30):
                pygame.draw.line(self.screen, grid_color, (content_rect.x, y), (content_rect.right, y), 1)

            # Tech border
            border_color = (0, 150, 200)
            pygame.draw.rect(self.screen, border_color, content_rect, 2)

        def _draw_alien_scrollbar(self, content_rect, max_scroll):
            """Draw alien technology-style scrollbar"""
            scrollbar_width = 20
            scrollbar_x = content_rect.right + 10
            scrollbar_rect = pygame.Rect(
                scrollbar_x,
                content_rect.top,
                scrollbar_width,
                content_rect.height
            )

            # Scrollbar background - dark tech
            scrollbar_bg_color = (20, 30, 40)
            pygame.draw.rect(self.screen, scrollbar_bg_color, scrollbar_rect)
            pygame.draw.rect(self.screen, (0, 100, 150), scrollbar_rect, 2)

            # Scroll thumb - bright tech
            thumb_height = max(30, int(content_rect.height * (content_rect.height / self.art_dialogue_total_height)))
            scroll_ratio = self.art_dialogue_scroll_pos / max_scroll if max_scroll > 0 else 0
            thumb_y = content_rect.top + int(scroll_ratio * (content_rect.height - thumb_height))

            thumb_rect = pygame.Rect(
                scrollbar_x + 2,
                thumb_y,
                scrollbar_width - 4,
                thumb_height
            )

            thumb_color = (0, 255, 255) if self.art_dialogue_dragging else (0, 200, 255)
            pygame.draw.rect(self.screen, thumb_color, thumb_rect)
            pygame.draw.rect(self.screen, (0, 150, 200), thumb_rect, 1)

            # Store rects for interaction
            self.art_dialogue_scrollbar_rect = scrollbar_rect
            self.art_dialogue_thumb_rect = thumb_rect

        def _draw_alien_close_button(self, panel_rect):
            """Draw alien technology-style close button"""
            button_width, button_height = 120, 40
            button_rect = pygame.Rect(0, 0, button_width, button_height)
            button_rect.center = (panel_rect.centerx, panel_rect.bottom - 50)

            self.art_dialogue_close_button = button_rect

            # Button styled like alien tech panel
            tech_color = (0, 100, 150)
            pygame.draw.rect(self.screen, tech_color, button_rect)
            pygame.draw.rect(self.screen, (0, 255, 255), button_rect, 3)

            # Button text in bright cyan
            button_text = self.fonts['normal'].render("Close", True, (0, 255, 255))
            button_text_rect = button_text.get_rect(center=button_rect.center)
            self.screen.blit(button_text, button_text_rect)

        def _draw_scroll_background(self, panel_rect):
            """Draw the paper scroll background with rolled edges"""
            # Main scroll body - aged paper color
            paper_color = (240, 230, 200)  # Cream/aged paper color
            pygame.draw.rect(self.screen, paper_color, panel_rect)

            # Draw scroll rod at top and bottom
            rod_color = (101, 67, 33)  # Dark brown wood color
            rod_height = 12

            # Top rod
            top_rod = pygame.Rect(panel_rect.x - 10, panel_rect.y - 15, panel_rect.width + 20, rod_height)
            pygame.draw.rect(self.screen, rod_color, top_rod)
            pygame.draw.rect(self.screen, (80, 53, 26), top_rod, 2)  # Darker border

            # Bottom rod
            bottom_rod = pygame.Rect(panel_rect.x - 10, panel_rect.bottom + 3, panel_rect.width + 20, rod_height)
            pygame.draw.rect(self.screen, rod_color, bottom_rod)
            pygame.draw.rect(self.screen, (80, 53, 26), bottom_rod, 2)  # Darker border

            # Draw scroll edge shadows/curves
            shadow_color = (200, 185, 160)

            # Left edge shadow
            for i in range(15):
                alpha = 255 - (i * 12)
                if alpha > 0:
                    shadow_surf = pygame.Surface((2, panel_rect.height))
                    shadow_surf.set_alpha(alpha)
                    shadow_surf.fill(shadow_color)
                    self.screen.blit(shadow_surf, (panel_rect.x + i, panel_rect.y))

            # Right edge shadow
            for i in range(15):
                alpha = 255 - (i * 12)
                if alpha > 0:
                    shadow_surf = pygame.Surface((2, panel_rect.height))
                    shadow_surf.set_alpha(alpha)
                    shadow_surf.fill(shadow_color)
                    self.screen.blit(shadow_surf, (panel_rect.right - 15 + i, panel_rect.y))

            # Add some aging spots/stains
            import random
            random.seed(42)  # Consistent aging pattern
            stain_color = (210, 200, 170)

            for _ in range(8):
                stain_x = panel_rect.x + random.randint(20, panel_rect.width - 40)
                stain_y = panel_rect.y + random.randint(20, panel_rect.height - 40)
                stain_size = random.randint(8, 20)

                stain_surf = pygame.Surface((stain_size * 2, stain_size * 2), pygame.SRCALPHA)
                pygame.draw.circle(stain_surf, (*stain_color, 80), (stain_size, stain_size), stain_size)
                self.screen.blit(stain_surf, (stain_x - stain_size, stain_y - stain_size))

        def _draw_scroll_title(self, center_x, y, title_text):
            """Draw ornate title with decorative elements"""
            # Draw title with shadow for depth
            shadow_text = self.fonts['large'].render(title_text, True, (100, 80, 60))
            shadow_rect = shadow_text.get_rect(center=(center_x + 2, y + 2))
            self.screen.blit(shadow_text, shadow_rect)

            # Main title in dark ink color
            title_color = (40, 30, 20)
            title_surf = self.fonts['large'].render(title_text, True, title_color)
            title_rect = title_surf.get_rect(center=(center_x, y))
            self.screen.blit(title_surf, title_rect)

            # Decorative flourishes on either side of title
            flourish_color = (60, 45, 30)
            flourish_y = y + title_surf.get_height() // 2

            # Left flourish
            left_end = center_x - title_surf.get_width() // 2 - 20
            pygame.draw.line(self.screen, flourish_color, (left_end - 40, flourish_y), (left_end, flourish_y), 3)
            pygame.draw.circle(self.screen, flourish_color, (left_end - 40, flourish_y), 4)

            # Right flourish
            right_start = center_x + title_surf.get_width() // 2 + 20
            pygame.draw.line(self.screen, flourish_color, (right_start, flourish_y), (right_start + 40, flourish_y), 3)
            pygame.draw.circle(self.screen, flourish_color, (right_start + 40, flourish_y), 4)

        def _draw_aged_paper_background(self, content_rect):
            """Draw subtle aged paper background for text area"""
            # Slightly different shade for text area
            text_bg_color = (245, 235, 210)
            pygame.draw.rect(self.screen, text_bg_color, content_rect)

            # Very subtle border to define text area
            border_color = (220, 205, 180)
            pygame.draw.rect(self.screen, border_color, content_rect, 1)

        def _draw_scroll_scrollbar(self, content_rect, max_scroll):
            """Draw scrollbar styled to match scroll theme"""
            scrollbar_width = 20
            scrollbar_x = content_rect.right + 10
            scrollbar_rect = pygame.Rect(
                scrollbar_x,
                content_rect.top,
                scrollbar_width,
                content_rect.height
            )

            # Scrollbar background - wood-like
            scrollbar_bg_color = (160, 130, 90)
            pygame.draw.rect(self.screen, scrollbar_bg_color, scrollbar_rect)
            pygame.draw.rect(self.screen, (120, 95, 65), scrollbar_rect, 2)

            # Scroll thumb - darker wood
            thumb_height = max(30, int(content_rect.height * (content_rect.height / self.art_dialogue_total_height)))
            scroll_ratio = self.art_dialogue_scroll_pos / max_scroll if max_scroll > 0 else 0
            thumb_y = content_rect.top + int(scroll_ratio * (content_rect.height - thumb_height))

            thumb_rect = pygame.Rect(
                scrollbar_x + 2,
                thumb_y,
                scrollbar_width - 4,
                thumb_height
            )

            thumb_color = (101, 67, 33) if self.art_dialogue_dragging else (120, 85, 50)
            pygame.draw.rect(self.screen, thumb_color, thumb_rect)
            pygame.draw.rect(self.screen, (80, 53, 26), thumb_rect, 1)

            # Store rects for interaction
            self.art_dialogue_scrollbar_rect = scrollbar_rect
            self.art_dialogue_thumb_rect = thumb_rect

        def _draw_scroll_close_button(self, panel_rect):
            """Draw close button with scroll styling"""
            button_width, button_height = 120, 40
            button_rect = pygame.Rect(0, 0, button_width, button_height)
            button_rect.center = (panel_rect.centerx, panel_rect.bottom - 50)

            self.art_dialogue_close_button = button_rect

            # Button styled like a wax seal
            seal_color = (139, 69, 19)  # Saddle brown
            pygame.draw.ellipse(self.screen, seal_color, button_rect)
            pygame.draw.ellipse(self.screen, (160, 82, 45), button_rect, 3)  # Lighter border

            # Button text in lighter color
            button_text = self.fonts['normal'].render("Close", True, (240, 220, 180))
            button_text_rect = button_text.get_rect(center=button_rect.center)
            self.screen.blit(button_text, button_text_rect)

        def draw_painting_viewer(self):
            """Draw painting viewer with large image display"""
            if not self.show_painting_viewer or not self.current_painting_item:
                return

            # Semi-transparent overlay
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            overlay.set_alpha(180)
            overlay.fill(BLACK)
            self.screen.blit(overlay, (0, 0))

            # Get the painting display image
            painting_image = self.current_painting_item.get_painting_display_image()

            if painting_image:
                # Calculate display size
                max_width = SCREEN_WIDTH - 100
                max_height = SCREEN_HEIGHT - 200

                image_width, image_height = painting_image.get_size()
                scale = min(max_width / image_width, max_height / image_height, 1.0)

                display_width = int(image_width * scale)
                display_height = int(image_height * scale)
                scaled_image = pygame.transform.scale(painting_image, (display_width, display_height))

                # Center the image
                image_x = (SCREEN_WIDTH - display_width) // 2
                image_y = (SCREEN_HEIGHT - display_height) // 2 - 30

                # Draw image border
                border_rect = pygame.Rect(image_x - 5, image_y - 5, display_width + 10, display_height + 10)
                pygame.draw.rect(self.screen, WHITE, border_rect, 3)

                # Draw the image
                self.screen.blit(scaled_image, (image_x, image_y))

                # Draw painting title
                title = self.fonts['large'].render(self.current_painting_item.name, True, WHITE)
                title_rect = title.get_rect(center=(SCREEN_WIDTH // 2, 50))
                self.screen.blit(title, title_rect)
            else:
                # Error message without debug prints
                error_text = self.fonts['large'].render(
                    f"Could not display {self.current_painting_item.name}",
                    True,
                    WHITE
                )
                error_rect = error_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50))
                self.screen.blit(error_text, error_rect)

            # Close button
            button_width, button_height = 200, 60
            button_rect = pygame.Rect(0, 0, button_width, button_height)
            button_rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 80)

            self.painting_viewer_close_button = button_rect

            button_color = GREEN

            pygame.draw.rect(self.screen, button_color, button_rect)
            pygame.draw.rect(self.screen, WHITE, button_rect, 3)

            button_text = self.fonts['normal'].render("Close", True, BLACK)
            button_text_rect = button_text.get_rect(center=button_rect.center)
            self.screen.blit(button_text, button_text_rect)

        def handle_painting_viewer_click(self, pos, event=None):
            """Handle clicks on painting viewer"""
            if not self.show_painting_viewer:
                return False

            if event and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if hasattr(self, 'painting_viewer_close_button') and self.painting_viewer_close_button.collidepoint(
                        pos):
                    self.show_painting_viewer = False
                    self.current_painting_item = None
                    return True

            return False

        def handle_art_dialogue_click(self, pos, event=None):
            """Handle clicks and scroll events on art dialogue"""
            if not self.show_art_dialogue:
                return False

            if event and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if hasattr(self, 'art_dialogue_close_button') and self.art_dialogue_close_button.collidepoint(pos):
                    self._close_art_dialogue()
                    return True

            if event and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if (hasattr(self, 'art_dialogue_scrollbar_rect') and
                        self.art_dialogue_scrollbar_rect and
                        self.art_dialogue_scrollbar_rect.collidepoint(pos)):
                    self.art_dialogue_dragging = True
                    self.art_dialogue_drag_start_y = pos[1]
                    self.art_dialogue_scroll_start = self.art_dialogue_scroll_pos
                    return True

            elif event and event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if self.art_dialogue_dragging:
                    self.art_dialogue_dragging = False
                    return True

            elif event and event.type == pygame.MOUSEMOTION and self.art_dialogue_dragging:
                if (hasattr(self, 'art_dialogue_scrollbar_rect') and
                        self.art_dialogue_scrollbar_rect and
                        hasattr(self, 'art_dialogue_content_rect')):

                    drag_distance = pos[1] - self.art_dialogue_drag_start_y
                    scrollbar_height = self.art_dialogue_scrollbar_rect.height
                    max_scroll = max(0, self.art_dialogue_total_height - self.art_dialogue_visible_height)

                    if scrollbar_height > 0 and max_scroll > 0:
                        scroll_ratio = drag_distance / scrollbar_height
                        scroll_change = scroll_ratio * max_scroll
                        new_scroll = self.art_dialogue_scroll_start + scroll_change
                        self.art_dialogue_scroll_pos = max(0, min(new_scroll, max_scroll))
                    return True

            elif event and event.type == pygame.MOUSEWHEEL and hasattr(self, 'art_dialogue_content_rect'):
                if self.art_dialogue_content_rect.collidepoint(pos):
                    scroll_amount = event.y * 30
                    max_scroll = max(0, self.art_dialogue_total_height - self.art_dialogue_visible_height)
                    self.art_dialogue_scroll_pos = max(0, min(self.art_dialogue_scroll_pos - scroll_amount, max_scroll))
                    return True

            return False

        def _close_art_dialogue(self):
            """Cleanly close the art dialogue"""
            self.show_art_dialogue = False
            self.current_art_item = None
            self.art_dialogue_scroll_pos = 0
            self.art_dialogue_dragging = False

    def get_tooltip_text(self) -> list:
        """Get tooltip text for this item"""
        lines = [self.name]

        if self.description:
            lines.append(self.description)

        if self.is_equippable:
            if self.hp_bonus > 0:
                lines.append(f"HP Bonus: +{self.hp_bonus}")
            if self.attack_bonus > 0:
                lines.append(f"Attack Bonus: +{self.attack_bonus}")
        elif isinstance(self.item_type, FoodType):
            if self.item_type in [FoodType.FRUIT, FoodType.DOHNUT]:  # Modified to include Dohnut
                lines.append(f"Restores {self.hp_bonus} HP")
            elif self.item_type == FoodType.BREAD:
                lines.append("Grants speed boost")
        elif isinstance(self.item_type, ArtType):
            if self.item_type == ArtType.POETRY:
                lines.append("Click to read poetry")
            elif self.item_type == ArtType.PAINTING:
                lines.append("Click to view painting")

        if hasattr(self, 'quantity') and self.quantity > 1:
            lines.append(f"Quantity: {self.quantity}")

        return lines