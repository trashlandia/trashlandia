# ui/renderer.py - FIXED: Victory zone spaceship collision and end sequence
"""Game Renderer - Handles all game rendering with optimized organization"""
import pygame
import math
import random
import os
from typing import List, Dict, Set, Tuple
from config.settings import *
from models.item import Item
from models.enemy import Enemy
from models.zone import Zone
from models.character import Character


class GameRenderer:
    """Handles all game rendering with organized, efficient methods"""

    def __init__(self, screen, game=None):
        self.screen = screen
        self.game = game
        self._init_fonts()
        self._init_art_display()
        self._init_minimap()
        self._init_inventory()

        # Initialize spaceship image for victory zone
        self.spaceship_image = None
        self._load_spaceship_image()

    # ==================== INITIALIZATION METHODS ====================

    def _init_fonts(self):
        """Initialize all fonts from settings"""
        self.fonts = {
            size: pygame.font.Font(None, FONT_SIZES[size])
            for size in ['large', 'normal', 'small', 'tiny']
        }
        self._font_cache = {}

    def _get_font(self, size):
        """Return a cached default font of the given size"""
        if size not in self._font_cache:
            self._font_cache[size] = pygame.font.Font(None, size)
        return self._font_cache[size]

    def _init_art_display(self):
        """Initialize art display manager"""
        from models.item import Item
        self.art_display = Item.ArtDisplayManager(self.screen, self.fonts)

    def _init_minimap(self):
        """Initialize minimap tracking"""
        self.revealed_positions = {
            zone: set() for zone in [
                "Oozing Canal City",
                "Forest of Rusting Trees",
                "Wasteland Plains"
            ]
        }
        self.minimap_caches = {}
        self.minimap_dirty = True
        self.last_player_pos = (0, 0)

    def _init_inventory(self):
        """Initialize inventory rendering state"""
        self.scroll_offsets = {'trash': 0, 'food': 0, 'art': 0, 'crafted': 0}
        self.section_rects = {}
        self.upgrade_button_rects = {}

    def _load_spaceship_image(self):
        """Load spaceship image for victory zone with fallback"""
        # Try to load spaceship.png from multiple possible paths
        spaceship_paths = [
            "spaceship.png",
            os.path.join("assets", "spaceship.png"),
            os.path.join("images", "spaceship.png"),
            os.path.join("art", "spaceship.png"),
            os.path.join("data", "spaceship.png")
        ]

        for path in spaceship_paths:
            if os.path.exists(path):
                try:
                    self.spaceship_image = pygame.image.load(path).convert_alpha()
                    # Scale to appropriate size
                    original_size = self.spaceship_image.get_size()
                    new_size = (min(400, original_size[0]), min(300, original_size[1]))
                    self.spaceship_image = pygame.transform.scale(self.spaceship_image, new_size)
                    return
                except pygame.error as e:
                    print(f"Error loading spaceship image from {path}: {e}")

        print("Warning: spaceship.png not found - creating placeholder")
        self._create_placeholder_spaceship()

    def _create_placeholder_spaceship(self):
        """Create a placeholder spaceship image if file not found"""
        size = (300, 200)
        self.spaceship_image = pygame.Surface(size, pygame.SRCALPHA)

        center_x, center_y = size[0] // 2, size[1] // 2

        # Main body (ellipse)
        pygame.draw.ellipse(self.spaceship_image, (150, 150, 200),
                            (50, center_y - 30, 200, 60))

        # Cockpit (circle)
        pygame.draw.circle(self.spaceship_image, (100, 150, 255),
                           (center_x, center_y), 25)

        # Wings
        pygame.draw.polygon(self.spaceship_image, (120, 120, 160), [
            (40, center_y), (80, center_y - 40), (80, center_y + 40)
        ])
        pygame.draw.polygon(self.spaceship_image, (120, 120, 160), [
            (260, center_y), (220, center_y - 40), (220, center_y + 40)
        ])

        # Engine glow effects
        pygame.draw.circle(self.spaceship_image, (255, 100, 100), (40, center_y), 15)
        pygame.draw.circle(self.spaceship_image, (255, 200, 100), (40, center_y), 10)

        print("Created placeholder spaceship image")

    # ==================== MAIN DRAWING METHODS ====================

    def draw_exploration(self, zone: Zone, player: Character, zone_name: str):
        """Draw exploration view with proper victory zone handling"""
        current_zone_map = self.game.get_current_zone_map() if self.game else None

        # Handle end credits separately
        if (zone_name == "Final Victory Zone" and
                hasattr(self.game, 'spaceship_collision_active') and
                self.game.spaceship_collision_active):
            # Don't draw normal exploration during end credits
            return

        # SPECIAL CASE: Victory Zone rendering
        if zone_name == "Final Victory Zone":
            self._draw_victory_zone(zone, player, zone_name)
            return

        # Regular zone drawing code
        if current_zone_map and hasattr(self.game, 'camera'):
            current_zone_map.draw(self.screen, self.game.camera)
            pygame.draw.rect(self.screen, WHITE,
                             self.game.camera.apply_rect(current_zone_map.world_boundary), 3)
        elif self.game and hasattr(self.game, 'camera'):
            # Fallback: draw a colored background if no map is available
            self.screen.fill((50, 50, 100))

        camera = self.game.camera if self.game else None

        if camera:
            # Draw items
            for item, x, y in zone.trash_items:
                screen_x, screen_y = camera.apply(x, y)
                if -50 < screen_x < SCREEN_WIDTH + 50 and -50 < screen_y < SCREEN_HEIGHT + 50:
                    item.draw(self.screen, screen_x, screen_y)

            # Draw enemies
            for enemy, x, y in zone.enemies:
                screen_x, screen_y = camera.apply(enemy.x, enemy.y)
                if -50 < screen_x < SCREEN_WIDTH + 50 and -50 < screen_y < SCREEN_HEIGHT + 50:
                    enemy.draw(self.screen, screen_x, screen_y, self.game)

            # Draw NPCs
            for npc, x, y in zone.npcs:
                screen_x, screen_y = camera.apply(npc.x, npc.y)
                if -50 < screen_x < SCREEN_WIDTH + 50 and -50 < screen_y < SCREEN_HEIGHT + 50:
                    npc.draw(self.screen, screen_x, screen_y)

            # Draw doors
            for door in zone.doors:
                screen_x, screen_y = camera.apply(door.x, door.y)
                if -50 < screen_x < SCREEN_WIDTH + 50 and -50 < screen_y < SCREEN_HEIGHT + 50:
                    door.draw(self.screen, camera)

        # Draw player last (on top of everything)
        if camera:
            player_screen_x, player_screen_y = camera.apply(player.x, player.y)
        else:
            player_screen_x, player_screen_y = int(player.x), int(player.y)

        speed_boost_active = self.game.speed_boost_active if self.game else False

        # Pass exploration_mode=True to enable sprite sheet animation
        player.draw(self.screen, player_screen_x, player_screen_y, speed_boost_active,
                    combat_mode=False, exploration_mode=True)

        # Update fog of war
        self.update_revealed_area(int(player.x), int(player.y))

    def draw_combat(self, enemy: Enemy, combat_log: List[str]):
        """Draw combat screen using Character and Enemy drawing methods"""
        self.screen.fill((40, 40, 50))

        # Get sprite positions
        positions = self.game.combat.get_sprite_positions()

        # Draw character and enemy using their draw methods
        if self.game:
            self.game.player.draw(self.screen, positions['player_x'], positions['player_y'], combat_mode=True)

        if enemy and enemy.image:
            # Check if enemy is a boss (type BOSS)
            if enemy.type == EnemyType.BOSS:
                # Scale boss enemy to nearly fill the screen
                # Calculate size based on screen dimensions
                size = (SCREEN_WIDTH - 200, SCREEN_HEIGHT - 200)  # Leave 100px margin on each side
                # Maintain aspect ratio
                original_ratio = enemy.image.get_width() / enemy.image.get_height()
                if (size[0] / size[1]) > original_ratio:
                    # Width is the limiting factor
                    size = (size[0], int(size[0] / original_ratio))
                else:
                    # Height is the limiting factor
                    size = (int(size[1] * original_ratio), size[1])
            else:
                # Regular enemies keep normal size
                size = (192, 192)

            enemy_img = pygame.transform.scale(enemy.image, size)
            enemy_rect = enemy_img.get_rect(center=(positions['enemy_x'], positions['enemy_y']))
            self.screen.blit(enemy_img, enemy_rect)
        else:
            enemy_color = enemy.get_color() if enemy else GRAY
            pygame.draw.circle(self.screen, enemy_color, (int(positions['enemy_x']), int(positions['enemy_y'])), 96)

        # Draw combat stats using Character method
        if self.game:
            self.game.player.draw_combat_stats(self.screen, self.fonts)
            enemy.draw_combat_stats(self.screen, self.fonts, positions)

        # Draw health bars
        self._draw_combat_health_bars(positions, enemy)

        # Draw combat log
        self._draw_combat_log(combat_log)

        # Turn indicator
        turn_text = "YOUR TURN" if self.game.combat.player_turn else "ENEMY TURN"
        turn_color = GREEN if self.game.combat.player_turn else RED
        turn_surf = self.fonts['small'].render(turn_text, True, turn_color)
        turn_rect = turn_surf.get_rect(center=(SCREEN_WIDTH // 2, 200))
        self.screen.blit(turn_surf, turn_rect)

        # Action buttons
        if self.game.combat.player_turn:
            self.game.combat.draw_buttons(self.screen)

    def draw_death_screen(self):
        """Draw death screen with continue/new game options"""
        self._draw_death_background()
        self._draw_death_content()
        self._draw_death_buttons()

    # ==================== VICTORY ZONE METHODS ====================

    def _draw_victory_zone(self, zone: Zone, player: Character, zone_name: str):
        """Special drawing method for the Final Victory Zone with spaceship collision"""
        # Draw TMX map background (map10.tmx)
        current_zone_map = self.game.get_current_zone_map() if self.game else None
        if current_zone_map and hasattr(self.game, 'camera'):
            current_zone_map.draw(self.screen, self.game.camera)
            pygame.draw.rect(self.screen, WHITE,
                             self.game.camera.apply_rect(current_zone_map.world_boundary), 3)
        else:
            # Fallback - draw a beautiful restored world background
            self.screen.fill((50, 150, 100))  # Lush green fallback
            self._draw_victory_background_effects()

        camera = self.game.camera if self.game else None

        # Draw and set up spaceship collision detection
        if camera and self.spaceship_image:
            # Position spaceship in the center-right area of the world
            spaceship_world_x = zone.world_width // 2 + 300  # Offset to the right
            spaceship_world_y = zone.world_height // 2

            # Apply camera transformation to spaceship position
            spaceship_screen_x, spaceship_screen_y = camera.apply(spaceship_world_x, spaceship_world_y)

            # Draw spaceship with glow effect for attraction
            self._draw_spaceship_with_glow(spaceship_screen_x, spaceship_screen_y)

            # Set up collision detection rectangle in world coordinates
            if not hasattr(self.game, 'spaceship_world_rect') or self.game.spaceship_world_rect is None:
                spaceship_width = self.spaceship_image.get_width()
                spaceship_height = self.spaceship_image.get_height()

                # Create collision rect with some padding for easier collision
                padding = 20
                self.game.spaceship_world_rect = pygame.Rect(
                    spaceship_world_x - spaceship_width // 2 - padding,
                    spaceship_world_y - spaceship_height // 2 - padding,
                    spaceship_width + (padding * 2),
                    spaceship_height + (padding * 2)
                )
                print(f"Spaceship collision rect set: {self.game.spaceship_world_rect}")

        # FIXED: Draw alien artifacts and other trash items (this was missing!)
        if camera:
            for item, x, y in zone.trash_items:
                screen_x, screen_y = camera.apply(x, y)
                if -50 < screen_x < SCREEN_WIDTH + 50 and -50 < screen_y < SCREEN_HEIGHT + 50:
                    item.draw(self.screen, screen_x, screen_y)

        # Draw NPCs (they should be stationary around the spaceship)
        if camera:
            for npc, x, y in zone.npcs:
                screen_x, screen_y = camera.apply(npc.x, npc.y)
                if -50 < screen_x < SCREEN_WIDTH + 50 and -50 < screen_y < SCREEN_HEIGHT + 50:
                    npc.draw(self.screen, screen_x, screen_y)

            # Draw doors (if any)
            for door in zone.doors:
                screen_x, screen_y = camera.apply(door.x, door.y)
                if -50 < screen_x < SCREEN_WIDTH + 50 and -50 < screen_y < SCREEN_HEIGHT + 50:
                    door.draw(self.screen, camera)

        # Draw player
        if camera:
            player_screen_x, player_screen_y = camera.apply(player.x, player.y)
        else:
            player_screen_x, player_screen_y = int(player.x), int(player.y)

        speed_boost_active = self.game.speed_boost_active if self.game else False
        player.draw(self.screen, player_screen_x, player_screen_y, speed_boost_active,
                    combat_mode=False, exploration_mode=True)

        # Draw instruction text for player
        self._draw_victory_zone_instructions()

    def _draw_spaceship_with_glow(self, screen_x, screen_y):
        """Draw spaceship with attractive glow effect"""
        current_time = pygame.time.get_ticks()

        # Create pulsing glow effect
        pulse_intensity = 0.7 + 0.3 * math.sin(current_time * 0.005)
        glow_radius = int(80 + 40 * pulse_intensity)

        # Draw multiple glow layers
        glow_colors = [
            (255, 255, 0, 30),  # Bright yellow outer
            (255, 200, 0, 50),  # Orange middle
            (255, 255, 255, 70),  # White inner
        ]

        for i, (r, g, b, a) in enumerate(glow_colors):
            current_radius = glow_radius - (i * 20)
            if current_radius > 0:
                glow_surface = pygame.Surface((current_radius * 2, current_radius * 2), pygame.SRCALPHA)
                pygame.draw.circle(glow_surface, (r, g, b, int(a * pulse_intensity)),
                                   (current_radius, current_radius), current_radius)
                self.screen.blit(glow_surface,
                                 (screen_x - current_radius, screen_y - current_radius))

        # Draw the spaceship itself
        spaceship_rect = self.spaceship_image.get_rect(center=(screen_x, screen_y))
        self.screen.blit(self.spaceship_image, spaceship_rect)

        # Add sparkle effects around the spaceship
        self._draw_spaceship_sparkles(screen_x, screen_y, current_time)

    def _draw_spaceship_sparkles(self, center_x, center_y, current_time):
        """Draw animated sparkles around the spaceship"""
        # Create sparkles that orbit around the spaceship
        for i in range(8):
            angle = (current_time * 0.001 + i * 45) % 360
            distance = 150 + 30 * math.sin(current_time * 0.002 + i)

            sparkle_x = center_x + int(distance * math.cos(math.radians(angle)))
            sparkle_y = center_y + int(distance * math.sin(math.radians(angle)))

            sparkle_size = random.randint(3, 8)
            sparkle_alpha = int(150 + 100 * math.sin(current_time * 0.003 + i))
            sparkle_color = (255, 255, random.randint(100, 255))

            sparkle_surface = pygame.Surface((sparkle_size * 2, sparkle_size * 2), pygame.SRCALPHA)
            pygame.draw.circle(sparkle_surface, sparkle_color,
                               (sparkle_size, sparkle_size), sparkle_size)
            sparkle_surface.set_alpha(sparkle_alpha)

            self.screen.blit(sparkle_surface,
                             (sparkle_x - sparkle_size, sparkle_y - sparkle_size))

    def _draw_victory_zone_instructions(self):
        """Draw instructions for the victory zone"""
        instruction_text = "Fix the spaceship to escape this world!"
        text_surface = self.fonts['normal'].render(instruction_text, True, (255, 255, 100))

        # Create pulsing effect
        current_time = pygame.time.get_ticks()
        pulse = 0.8 + 0.2 * math.sin(current_time * 0.005)
        text_surface.set_alpha(int(255 * pulse))

        # Position at top of screen
        text_rect = text_surface.get_rect(center=(SCREEN_WIDTH // 2, 50))

        # Draw background
        bg_rect = pygame.Rect(text_rect.x - 20, text_rect.y - 10,
                              text_rect.width + 40, text_rect.height + 20)
        bg_surface = pygame.Surface((bg_rect.width, bg_rect.height), pygame.SRCALPHA)
        bg_surface.fill((0, 0, 0, 120))
        self.screen.blit(bg_surface, bg_rect)

        self.screen.blit(text_surface, text_rect)

    def _draw_victory_background_effects(self):
        """Draw beautiful background effects for victory zone"""
        current_time = pygame.time.get_ticks()

        # Draw floating particles representing restoration
        for i in range(30):
            # Calculate particle position based on time
            x = (i * 100 + current_time * 0.02) % SCREEN_WIDTH
            y = (i * 77 + current_time * 0.015) % SCREEN_HEIGHT

            # Create different colored particles
            colors = [(100, 255, 100), (100, 200, 255), (255, 255, 100), (255, 150, 255)]
            color = colors[i % len(colors)]

            # Pulsing alpha
            alpha = int(50 + 100 * math.sin(current_time * 0.003 + i))
            size = 3 + int(2 * math.sin(current_time * 0.004 + i))

            particle_surface = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
            pygame.draw.circle(particle_surface, (*color, alpha), (size, size), size)
            self.screen.blit(particle_surface, (x - size, y - size))

    def draw_victory_text(self):
        """Draw the boss victory text with animated effects"""
        if not self.game or not self.game.show_victory_text:
            return

        current_time = pygame.time.get_ticks()
        elapsed = current_time - self.game.victory_text_start_time
        progress = min(1.0, elapsed / self.game.victory_text_duration)

        # Create semi-transparent overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(int(200 * min(1.0, progress * 2)))  # Fade in quickly
        overlay.fill((0, 20, 0))  # Dark green tint
        self.screen.blit(overlay, (0, 0))

        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2

        # Animate text scale and position
        if progress < 0.3:
            # Growing phase
            scale_factor = progress * 3.33  # 0 to 1 over first 30%
            text_alpha = int(255 * (progress * 3.33))
        else:
            # Stable phase
            scale_factor = 1.0
            text_alpha = 255

        # Create victory text with glow effect
        victory_text = "You defeated the BOSS!"
        base_font_size = int(48 * scale_factor)

        if base_font_size > 0:
            # Create font at scaled size
            victory_font = self._get_font(base_font_size)

            # Create glow effect with multiple layers
            glow_colors = [
                (255, 255, 0, 60),  # Bright yellow center
                (255, 200, 0, 40),  # Orange middle
                (255, 150, 0, 20),  # Red outer
            ]

            glow_offsets = [2, 4, 6]

            # Draw glow layers
            for i, (color, offset) in enumerate(zip(glow_colors, glow_offsets)):
                glow_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
                glow_text = victory_font.render(victory_text, True, color[:3])
                glow_text.set_alpha(color[3])

                for dx in [-offset, 0, offset]:
                    for dy in [-offset, 0, offset]:
                        if dx != 0 or dy != 0:
                            glow_surface.blit(glow_text,
                                              (center_x - glow_text.get_width() // 2 + dx,
                                               center_y - glow_text.get_height() // 2 + dy))

                self.screen.blit(glow_surface, (0, 0))

            # Draw main text with pulsing effect
            pulse_intensity = 0.8 + 0.2 * math.sin(elapsed * 0.008)
            text_color = (
                int(255 * pulse_intensity),
                int(255 * pulse_intensity),
                int(100 * pulse_intensity)
            )

            main_text = victory_font.render(victory_text, True, text_color)
            main_text.set_alpha(text_alpha)

            text_rect = main_text.get_rect(center=(center_x, center_y))
            self.screen.blit(main_text, text_rect)

            # Add sparkle effects
            self._draw_victory_sparkles(current_time, center_x, center_y)

            # Draw completion stats below
            if progress > 0.5:  # Show stats after text is stable
                stats_alpha = int(255 * (progress - 0.5) * 2)
                completion_time = self.game.highscore_system.get_formatted_current_time()

                stats_text = f"Completion Time: {completion_time}"
                stats_surface = self.fonts['small'].render(stats_text, True, (200, 255, 200))
                stats_surface.set_alpha(stats_alpha)

                stats_rect = stats_surface.get_rect(center=(center_x, center_y + 60))
                self.screen.blit(stats_surface, stats_rect)

                # Player stats
                player_stats = f"Final HP: {self.game.player.hp} | Attack: {self.game.player.total_attack}"
                player_surface = self.fonts['small'].render(player_stats, True, (200, 255, 200))
                player_surface.set_alpha(stats_alpha)

                player_rect = player_surface.get_rect(center=(center_x, center_y + 80))
                self.screen.blit(player_surface, player_rect)

    def _draw_victory_sparkles(self, current_time, center_x, center_y):
        """Draw animated sparkle effects around victory text"""
        # Create consistent sparkles based on time
        random.seed(int(current_time / 100))  # Change seed every 100ms

        for i in range(15):  # 15 sparkles
            angle = (current_time * 0.002 + i * 24) % (2 * math.pi)
            distance = 150 + 50 * math.sin(current_time * 0.003 + i)

            sparkle_x = center_x + int(distance * math.cos(angle))
            sparkle_y = center_y + int(distance * math.sin(angle))

            # Random sparkle size and alpha
            sparkle_size = random.randint(2, 8)
            sparkle_alpha = random.randint(100, 255)

            # Create sparkle surface
            sparkle_surface = pygame.Surface((sparkle_size * 2, sparkle_size * 2), pygame.SRCALPHA)
            sparkle_color = (255, 255, random.randint(100, 255), sparkle_alpha)

            pygame.draw.circle(sparkle_surface, sparkle_color[:3],
                               (sparkle_size, sparkle_size), sparkle_size)
            sparkle_surface.set_alpha(sparkle_alpha)

            self.screen.blit(sparkle_surface, (sparkle_x - sparkle_size, sparkle_y - sparkle_size))

    # ==================== END SEQUENCE METHODS ====================

    def draw_end_sequence(self):
        """Draw the end credits sequence with moving spaceship"""
        if not self.game:
            return

        # Draw star field background
        self._draw_star_field()

        # Draw moving spaceship and credits
        self._draw_spaceship_end_sequence()

    def _draw_star_field(self):
        """Draw animated galaxy background with moving stars for end credits"""
        # Fill with deep space background
        self.screen.fill((5, 5, 20))  # Deep space blue-black

        current_time = pygame.time.get_ticks()

        # Create multiple layers of stars moving at different speeds for parallax effect
        star_layers = [
            {
                'count': 200,
                'speed': 0.5,
                'size_range': (1, 2),
                'color_base': (150, 150, 200),
                'brightness_range': (100, 255),
                'seed_offset': 0
            },
            {
                'count': 100,
                'speed': 1.0,
                'size_range': (2, 3),
                'color_base': (200, 200, 255),
                'brightness_range': (120, 255),
                'seed_offset': 1000
            },
            {
                'count': 50,
                'speed': 2.0,
                'size_range': (3, 5),
                'color_base': (255, 255, 255),
                'brightness_range': (150, 255),
                'seed_offset': 2000
            }
        ]

        # Draw each star layer
        for layer in star_layers:
            random.seed(42 + layer['seed_offset'])  # Consistent but different for each layer

            for i in range(layer['count']):
                # Base star position
                base_x = random.randint(-100, SCREEN_WIDTH + 100)
                base_y = random.randint(-100, SCREEN_HEIGHT + 100)

                # Calculate movement based on time and speed
                movement_x = (current_time * layer['speed'] * 0.1) % (SCREEN_WIDTH + 200)
                movement_y = (current_time * layer['speed'] * 0.05) % (SCREEN_HEIGHT + 200)

                # Final star position with wrapping
                star_x = (base_x + movement_x) % (SCREEN_WIDTH + 200) - 100
                star_y = (base_y + movement_y) % (SCREEN_HEIGHT + 200) - 100

                # Skip if star is off screen
                if star_x < -50 or star_x > SCREEN_WIDTH + 50 or star_y < -50 or star_y > SCREEN_HEIGHT + 50:
                    continue

                # Twinkling effect
                twinkle = math.sin(current_time * 0.003 + i * 0.1)
                brightness_min, brightness_max = layer['brightness_range']
                brightness = int(brightness_min + (brightness_max - brightness_min) * (0.5 + 0.5 * twinkle))

                # Star color with some variation
                base_color = layer['color_base']
                color_variation = random.randint(-30, 30)
                color = (
                    max(0, min(255, base_color[0] + color_variation)),
                    max(0, min(255, base_color[1] + color_variation)),
                    max(0, min(255, base_color[2] + brightness - 100))
                )

                # Star size
                size = random.choice(range(layer['size_range'][0], layer['size_range'][1] + 1))

                # Draw star with glow effect for larger stars
                if size >= 3:
                    # Create glow effect for bright stars
                    glow_radius = size + 2
                    glow_surface = pygame.Surface((glow_radius * 4, glow_radius * 4), pygame.SRCALPHA)
                    glow_color = (*color, 60)
                    pygame.draw.circle(glow_surface, glow_color,
                                       (glow_radius * 2, glow_radius * 2), glow_radius * 2)
                    self.screen.blit(glow_surface,
                                     (star_x - glow_radius * 2, star_y - glow_radius * 2))

                # Draw the star
                pygame.draw.circle(self.screen, color, (int(star_x), int(star_y)), size)

        # Add nebula clouds in background
        self._draw_nebula_clouds(current_time)

        # Add distant galaxies
        self._draw_distant_galaxies(current_time)

        # Add shooting stars/comets
        self._draw_shooting_stars(current_time)

    def _draw_nebula_clouds(self, current_time):
        """Draw colorful nebula clouds drifting in background"""
        # Create several nebula clouds with different colors
        nebula_configs = [
            {
                'center': (SCREEN_WIDTH * 0.2, SCREEN_HEIGHT * 0.3),
                'color': (100, 50, 150, 40),  # Purple
                'size': 200,
                'drift_speed': 0.02
            },
            {
                'center': (SCREEN_WIDTH * 0.7, SCREEN_HEIGHT * 0.6),
                'color': (50, 100, 200, 35),  # Blue
                'size': 250,
                'drift_speed': 0.015
            },
            {
                'center': (SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.8),
                'color': (200, 100, 50, 30),  # Orange
                'size': 180,
                'drift_speed': 0.025
            }
        ]

        for nebula in nebula_configs:
            # Calculate drifting position
            drift_x = nebula['center'][0] + 50 * math.sin(current_time * nebula['drift_speed'])
            drift_y = nebula['center'][1] + 30 * math.cos(current_time * nebula['drift_speed'] * 0.7)

            # Create nebula surface with gradient effect
            nebula_surface = pygame.Surface((nebula['size'] * 2, nebula['size'] * 2), pygame.SRCALPHA)

            # Draw multiple circles for gradient effect
            for radius_step in range(nebula['size'], 0, -10):
                alpha = int(nebula['color'][3] * (radius_step / nebula['size']))
                circle_color = (*nebula['color'][:3], max(5, alpha))
                pygame.draw.circle(nebula_surface, circle_color,
                                   (nebula['size'], nebula['size']), radius_step)

            # Blit nebula to screen
            self.screen.blit(nebula_surface,
                             (drift_x - nebula['size'], drift_y - nebula['size']))

    def _draw_distant_galaxies(self, current_time):
        """Draw small spiral galaxies in the background"""
        galaxy_positions = [
            (SCREEN_WIDTH * 0.15, SCREEN_HEIGHT * 0.15),
            (SCREEN_WIDTH * 0.85, SCREEN_HEIGHT * 0.25),
            (SCREEN_WIDTH * 0.25, SCREEN_HEIGHT * 0.75),
            (SCREEN_WIDTH * 0.75, SCREEN_HEIGHT * 0.85)
        ]

        for i, (base_x, base_y) in enumerate(galaxy_positions):
            # Slow rotation for each galaxy
            rotation = (current_time * 0.001 + i * 90) % 360

            # Galaxy size and brightness
            galaxy_size = 30 + 10 * math.sin(current_time * 0.002 + i)

            # Create galaxy surface
            galaxy_surface = pygame.Surface((galaxy_size * 2, galaxy_size * 2), pygame.SRCALPHA)
            center = (galaxy_size, galaxy_size)

            # Draw spiral arms
            arm_color = (150, 150, 255, 80)
            for arm in range(3):  # 3 spiral arms
                arm_angle_offset = arm * 120
                for j in range(20):
                    # Spiral math
                    spiral_angle = (rotation + arm_angle_offset + j * 18) % 360
                    spiral_radius = (j / 20) * galaxy_size

                    arm_x = center[0] + spiral_radius * math.cos(math.radians(spiral_angle))
                    arm_y = center[1] + spiral_radius * math.sin(math.radians(spiral_angle))

                    # Draw arm segment
                    if 0 <= arm_x < galaxy_size * 2 and 0 <= arm_y < galaxy_size * 2:
                        pygame.draw.circle(galaxy_surface, arm_color,
                                           (int(arm_x), int(arm_y)), 2)

            # Draw galaxy core
            core_color = (255, 255, 150, 120)
            pygame.draw.circle(galaxy_surface, core_color, center, int(galaxy_size * 0.2))

            # Blit galaxy to screen
            self.screen.blit(galaxy_surface, (base_x - galaxy_size, base_y - galaxy_size))

    def _draw_shooting_stars(self, current_time):
        """Draw animated shooting stars/comets crossing the screen"""
        # Create 3-4 shooting stars at different intervals
        shooting_star_configs = [
            {
                'period': 8000,  # 8 seconds for full crossing
                'start_offset': 0,
                'color': (255, 255, 200),
                'trail_length': 60,
                'speed': 1.2
            },
            {
                'period': 12000,  # 12 seconds
                'start_offset': 3000,  # Offset by 3 seconds
                'color': (200, 255, 255),
                'trail_length': 80,
                'speed': 0.8
            },
            {
                'period': 15000,  # 15 seconds
                'start_offset': 7000,  # Offset by 7 seconds
                'color': (255, 200, 255),
                'trail_length': 45,
                'speed': 1.5
            }
        ]

        for config in shooting_star_configs:
            # Calculate shooting star timing
            star_time = (current_time + config['start_offset']) % config['period']
            progress = star_time / config['period']

            # Only show star during active period (not constantly)
            if progress < 0.8:  # Star visible for 80% of period
                # Calculate position (diagonal movement across screen)
                start_x = -100
                start_y = random.Random(config['start_offset']).randint(50, SCREEN_HEIGHT - 50)
                end_x = SCREEN_WIDTH + 100
                end_y = start_y + 200  # Diagonal movement

                # Current position
                star_x = start_x + (end_x - start_x) * progress * config['speed']
                star_y = start_y + (end_y - start_y) * progress * config['speed']

                # Skip if off screen
                if star_x < -50 or star_x > SCREEN_WIDTH + 50:
                    continue

                # Draw shooting star trail
                trail_segments = 15
                for j in range(trail_segments):
                    trail_progress = j / trail_segments
                    trail_x = star_x - (config['trail_length'] * trail_progress)
                    trail_y = star_y - (config['trail_length'] * 0.3 * trail_progress)

                    # Trail fade effect
                    trail_alpha = int(255 * (1 - trail_progress) * 0.6)
                    trail_size = max(1, int(4 * (1 - trail_progress)))

                    if trail_alpha > 10 and 0 <= trail_x <= SCREEN_WIDTH and 0 <= trail_y <= SCREEN_HEIGHT:
                        trail_surface = pygame.Surface((trail_size * 2, trail_size * 2), pygame.SRCALPHA)
                        trail_color = (*config['color'], trail_alpha)
                        pygame.draw.circle(trail_surface, trail_color,
                                           (trail_size, trail_size), trail_size)
                        self.screen.blit(trail_surface,
                                         (trail_x - trail_size, trail_y - trail_size))

                # Draw main shooting star head
                star_surface = pygame.Surface((12, 12), pygame.SRCALPHA)

                # Bright core
                pygame.draw.circle(star_surface, config['color'], (6, 6), 4)

                # Outer glow
                glow_color = (*config['color'], 100)
                pygame.draw.circle(star_surface, glow_color, (6, 6), 6)

                self.screen.blit(star_surface, (star_x - 6, star_y - 6))

    def _draw_spaceship_end_sequence(self):
        """Draw the end credits sequence with enhanced space movement effects"""
        if not self.game:
            return

        # ADD THIS LINE - was missing!
        current_time = pygame.time.get_ticks()

        # Check if required attributes exist
        if not hasattr(self.game, 'spaceship_end_x') or not hasattr(self.game, 'spaceship_end_y'):
            print("Warning: spaceship end position not set")
            return

        # Draw spaceship with enhanced engine effects
        if self.spaceship_image:
            # Scale spaceship for end sequence
            end_spaceship = pygame.transform.scale(self.spaceship_image, (200, 150))

            # Enhanced engine trail effect with multiple colors
            trail_length = 8
            trail_colors = [
                (255, 100, 100, 255),  # Bright red core
                (255, 150, 100, 200),  # Orange
                (255, 200, 100, 150),  # Yellow
                (255, 255, 150, 100),  # Pale yellow
                (200, 255, 255, 60),  # Cyan outer
                (150, 200, 255, 40),  # Blue outer
                (100, 150, 255, 20),  # Deep blue
                (50, 100, 200, 10)  # Very faint blue
            ]

            # Create a separate random generator for engine effects
            engine_random = random.Random(current_time // 100)

            # Draw engine trail with color gradient
            for i in range(trail_length):
                if i < len(trail_colors):
                    trail_color = trail_colors[i]
                    alpha = trail_color[3]

                    # Calculate trail position with some randomness for engine flicker
                    trail_x = self.game.spaceship_end_x - (i * 25) - engine_random.randint(0, 10)
                    trail_y = self.game.spaceship_end_y + engine_random.randint(-8, 8)

                    # Create engine flame shape (elongated)
                    flame_width = 40 - (i * 4)
                    flame_height = 20 - (i * 2)

                    if flame_width > 0 and flame_height > 0:
                        flame_surface = pygame.Surface((flame_width, flame_height), pygame.SRCALPHA)
                        pygame.draw.ellipse(flame_surface, trail_color[:3],
                                            (0, 0, flame_width, flame_height))
                        flame_surface.set_alpha(alpha)

                        flame_rect = flame_surface.get_rect(center=(trail_x, trail_y))
                        self.screen.blit(flame_surface, flame_rect)

            # Add sparkle effects around engine area
            sparkle_random = random.Random((current_time // 50) + 12345)  # Different seed
            for i in range(20):
                sparkle_x = self.game.spaceship_end_x - sparkle_random.randint(30, 80)
                sparkle_y = self.game.spaceship_end_y + sparkle_random.randint(-25, 25)

                sparkle_intensity = sparkle_random.random()
                if sparkle_intensity > 0.7:  # Only show bright sparkles
                    sparkle_size = sparkle_random.randint(2, 5)
                    sparkle_color = sparkle_random.choice([
                        (255, 255, 255),  # White
                        (255, 200, 100),  # Orange
                        (100, 200, 255)  # Blue
                    ])

                    sparkle_alpha = int(255 * sparkle_intensity)
                    sparkle_surface = pygame.Surface((sparkle_size * 2, sparkle_size * 2), pygame.SRCALPHA)
                    pygame.draw.circle(sparkle_surface, sparkle_color,
                                       (sparkle_size, sparkle_size), sparkle_size)
                    sparkle_surface.set_alpha(sparkle_alpha)

                    self.screen.blit(sparkle_surface,
                                     (sparkle_x - sparkle_size, sparkle_y - sparkle_size))

            # Draw main spaceship with subtle glow
            glow_surface = pygame.Surface((240, 190), pygame.SRCALPHA)
            pygame.draw.ellipse(glow_surface, (100, 150, 255, 30), (0, 0, 240, 190))
            glow_rect = glow_surface.get_rect(center=(self.game.spaceship_end_x, self.game.spaceship_end_y))
            self.screen.blit(glow_surface, glow_rect)

            # Main spaceship
            spaceship_rect = end_spaceship.get_rect(
                center=(self.game.spaceship_end_x, self.game.spaceship_end_y)
            )
            self.screen.blit(end_spaceship, spaceship_rect)

            # Add forward-facing lights
            light_positions = [
                (self.game.spaceship_end_x + 90, self.game.spaceship_end_y - 15),
                (self.game.spaceship_end_x + 90, self.game.spaceship_end_y + 15)
            ]

            for light_x, light_y in light_positions:
                # Pulsing navigation lights
                pulse = 0.5 + 0.5 * math.sin(current_time * 0.008)
                light_color = (int(255 * pulse), int(255 * pulse), 255)
                light_alpha = int(200 * pulse)

                light_surface = pygame.Surface((20, 20), pygame.SRCALPHA)
                pygame.draw.circle(light_surface, light_color, (10, 10), 8)
                light_surface.set_alpha(light_alpha)

                self.screen.blit(light_surface, (light_x - 10, light_y - 10))

        # Draw enhanced credits text
        self._draw_end_credits_text()

    def _draw_end_credits_text(self):
        """Draw comprehensive end credits text with REVERSE scrolling and end pause"""
        if not self.game:
            return

        credits_text = [
            "",
            "CONGRATULATIONS!",
            "You have successfully restored the world!",
            "",
            "Everyone joined you and escaped to a new beginning!",
            "",
            "Now you all will explore the cosmos together,",
            "",
            "reading leftover scrap pieces of poetry,",
            "",
            "while floating in space...",
            "",
            "",
            f"Final Stats:",
            "",
            f"Player: {self.game.highscore_system.player_name}" if hasattr(self.game,
                                                                           'highscore_system') else "Player: Hero",
            "",
            f"Completion Time: {self.game.highscore_system.get_formatted_current_time()}" if hasattr(self.game,
                                                                                                     'highscore_system') else "",
            "",
            f"Final HP: {self.game.player.hp}/{self.game.player.max_hp}" if hasattr(self.game, 'player') else "",
            "",
            f"Final Attack: {self.game.player.total_attack}" if hasattr(self.game, 'player') else "",
            "",
            "Thank you for playing",
            "Our Trashy Adventure!",
            "",
            "all poetry writing, game artwork, photos, and names",
            "were based off real world characters and made by Bryan Alexander Utesch",
            "",
            "game was based from conversations between Bryan and Thomas",
            "Thomas created the original model structure code",
            "he is The Best",
            "",
            "NOW GO CLEAN UP TRASH IN REAL LIFE!",
            "",
            "",
            "Animated player and npc sprites made using the online tool by:",
            "Sprites by: Johannes Sjölund (wulax), Michael Whitlock (bigbeargames),",
            "Matthew Krohn (makrohn), Nila122, David Conway Jr. (JaidynReiman),",
            "Carlo Enrico Victoria (Nemisys), Thane Brimhall (pennomi), laetissima, bluecarrot16, ",
            "Luke Mehl, Benjamin K. Smith (BenCreating), MuffinElZangano, Durrani, kheftel,",
            "Stephen Challener (Redshrike), William.Thompsonj, Marcel van de Steeg (MadMarcel),",
            "TheraHedwig, Evert, Pierre Vigier (pvigier), Eliza Wyatt (ElizaWy), Johannes Sjölund (wulax),",
            "Sander Frenken (castelonia), dalonedrau, Lanea Zimmerman (Sharm), Manuel Riecke (MrBeast), ",
            "Barbara Riviera, Joe White, Mandi Paugh, Shaun Williams, Daniel Eddeland (daneeklu), ",
            "Emilio J. Sanchez-Sierra, drjamgo, gr3yh47, tskaufma, Fabzy, Yamilian, Skorpio, kheftel, ",
            "Tuomo Untinen (reemax), Tracy, thecilekli, LordNeo, Stafford McIntyre, PlatForge project, ",
            "DCSS authors, DarkwallLKE, Charles Sanchez (CharlesGabriel), Radomir Dopieralski, macmanmatty, ",
            "Cobra Hubbard (BlueVortexGames), Inboxninja, kcilds/Rocetti/Eredah, Napsio (Vitruvian Studio),",
            "The Foreman, AntumDeluge - Sprites contributed as part of the Liberated Pixel Cup project ",
            "from OpenGameArt.org: http://opengameart.org/content/lpc-collection ",
            "Creative Commons Attribution-ShareAlike 3.0 (CC-BY-SA 3.0)",
            "",
            "",
            "Press ESC to return to main menu"
        ]

        # CHANGED: Much slower scroll speed for better readability - REVERSE DIRECTION
        scroll_speed = 0.35  # Same slow speed

        # REVERSE: Start from bottom and scroll upward
        line_height = 40

        # Scroll upward from the bottom of the screen
        base_y = SCREEN_HEIGHT - (self.game.end_sequence_timer * scroll_speed)

        # Stop when the last line reaches mid-screen and hold until the player presses ESC
        final_base_y = (SCREEN_HEIGHT // 2) - (len(credits_text) - 1) * line_height
        base_y = max(base_y, final_base_y)

        for i, line in enumerate(credits_text):
            if not line:  # Skip empty lines
                continue

            # REVERSE: Calculate position going upward (subtract index instead of add)
            line_y = base_y + (i * line_height)

            # Only draw lines that are visible on screen
            if -50 < line_y < SCREEN_HEIGHT + 50:
                # Choose color and font based on line content
                if "CONGRATULATIONS" in line:
                    color = (255, 215, 0)  # Gold
                    font = self.fonts['large']
                elif "Final Stats:" in line:
                    color = (100, 255, 100)  # Light green
                    font = self.fonts['normal']
                elif any(stat in line for stat in ["Player:", "Completion Time:", "Final"]):
                    color = (200, 200, 255)  # Light blue
                    font = self.fonts['small']
                elif "Thank you" in line or "Our Trashy Adventure" in line:
                    color = (255, 100, 255)  # Magenta
                    font = self.fonts['normal']
                elif "Press ESC" in line:
                    # Pulsing effect for instructions
                    current_time = pygame.time.get_ticks()
                    pulse = 0.5 + 0.5 * math.sin(current_time * 0.005)
                    color = (int(255 * pulse), int(255 * pulse), 100)
                    font = self.fonts['small']
                else:
                    color = WHITE
                    font = self.fonts['small']

                text_surf = font.render(line, True, color)
                text_rect = text_surf.get_rect(center=(SCREEN_WIDTH // 2, line_y))

                # Add text shadow for better readability
                shadow_surf = font.render(line, True, (20, 20, 20))
                shadow_rect = shadow_surf.get_rect(center=(SCREEN_WIDTH // 2 + 2, line_y + 2))
                self.screen.blit(shadow_surf, shadow_rect)
                self.screen.blit(text_surf, text_rect)

    # ==================== DEATH SCREEN METHODS ====================

    def _draw_death_background(self):
        """Draw death screen background effects"""
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(220)
        overlay.fill((20, 20, 30))
        self.screen.blit(overlay, (0, 0))
        self._draw_floating_particles()

    def _draw_floating_particles(self):
        """Draw floating particle effects"""
        current_time = pygame.time.get_ticks()
        for i in range(20):
            particle_x = (i * 51 + current_time * 0.02) % SCREEN_WIDTH
            particle_y = (i * 37 + current_time * 0.01) % SCREEN_HEIGHT
            particle_alpha = int(30 + 20 * math.sin(current_time * 0.001 + i))
            particle_size = 2 + int(math.sin(current_time * 0.002 + i))

            particle_surface = pygame.Surface((particle_size * 2, particle_size * 2))
            particle_surface.set_alpha(particle_alpha)
            particle_surface.fill((100, 100, 150))
            self.screen.blit(particle_surface, (particle_x, particle_y))

    def _draw_death_content(self):
        """Draw death screen main content"""
        center_x, center_y = SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2
        current_time = pygame.time.get_ticks()

        self._draw_spinning_player(center_x, center_y, current_time)
        self._draw_death_text(center_x, current_time)
        self._draw_progress_indicator(center_x, center_y)

    def _draw_spinning_player(self, center_x, center_y, current_time):
        """Draw spinning player with glow effect"""
        spinning_image = self._get_spinning_player_image()
        if spinning_image:
            glow_radius = 80 + int(10 * math.sin(current_time * 0.003))
            glow_surface = pygame.Surface((glow_radius * 2, glow_radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(glow_surface, (150, 50, 50, 60), (glow_radius, glow_radius), glow_radius)
            self.screen.blit(glow_surface, (center_x - glow_radius, center_y - glow_radius))
            self.screen.blit(spinning_image, spinning_image.get_rect(center=(center_x, center_y)))

    def _draw_death_text(self, center_x, current_time):
        """Draw 'YOU DIED' text with effects"""
        text_y = (SCREEN_HEIGHT // 2) - 150
        shadow_text = self.fonts['large'].render("YOU DIED", True, (80, 0, 0))
        self.screen.blit(shadow_text, (center_x - shadow_text.get_width() // 2 + 3, text_y + 3))

        pulse_alpha = int(255 * (0.7 + 0.3 * math.sin(current_time * 0.005)))
        death_color = (min(255, 180 + int(75 * math.sin(current_time * 0.004))), 20, 20)
        death_text = self.fonts['large'].render("YOU DIED", True, death_color)
        self.screen.blit(death_text, (center_x - death_text.get_width() // 2, text_y))

    def _draw_progress_indicator(self, center_x, center_y):
        """Draw progress indicator text"""
        has_progress = any(zone.is_restored for zone in self.game.zones.values() if not zone.is_hub)
        progress_y = center_y + 80

        if has_progress:
            restored_count = sum(1 for zone in self.game.zones.values() if zone.is_restored and not zone.is_hub)
            progress_text = f"Progress: {restored_count} zones restored"
            progress_color = (100, 200, 100)
        else:
            progress_text = "No zones restored yet"
            progress_color = (200, 100, 100)

        progress_surf = self.fonts['small'].render(progress_text, True, progress_color)
        self.screen.blit(progress_surf, (center_x - progress_surf.get_width() // 2, progress_y))

    def _draw_death_buttons(self):
        """Draw death screen buttons"""
        has_progress = any(zone.is_restored for zone in self.game.zones.values() if not zone.is_hub)
        self._create_death_screen_buttons(has_progress)
        mouse_pos = pygame.mouse.get_pos()

        if hasattr(self.game, 'restart_button') and self.game.restart_button:
            self._draw_button(
                self.game.restart_button,
                mouse_pos,
                (60, 100, 60),
                (120, 150, 120),
                "CONTINUE FROM TRAIN STATION" if has_progress else "RESTART GAME"
            )

        if has_progress and hasattr(self.game, 'new_game_button') and self.game.new_game_button:
            self._draw_button(
                self.game.new_game_button,
                mouse_pos,
                (100, 60, 60),
                (150, 120, 120),
                "START NEW GAME"
            )

        # Footer instructions
        footer_text = self.fonts['tiny'].render(
            "Continue: Keep progress | New Game: Start over" if has_progress
            else "Click to begin your adventure anew",
            True, (150, 150, 150)
        )
        self.screen.blit(footer_text, (SCREEN_WIDTH // 2 - footer_text.get_width() // 2, SCREEN_HEIGHT - 30))

    def _draw_button(self, rect, mouse_pos, base_color, border_color, text):
        """Generic button drawing method"""
        hovered = rect.collidepoint(mouse_pos)

        if hovered:
            glow_surface = pygame.Surface((rect.width + 20, rect.height + 20), pygame.SRCALPHA)
            pygame.draw.rect(glow_surface, (*base_color[:3], 40), (0, 0, rect.width + 20, rect.height + 20), 0, 10)
            self.screen.blit(glow_surface,
                             (rect.centerx - (rect.width + 20) // 2, rect.centery - (rect.height + 20) // 2))

        pygame.draw.rect(self.screen, base_color, rect, 0, 10)
        pygame.draw.rect(self.screen, border_color, rect, 3, 10)

        # Button text with shadow
        button_shadow = self.fonts['small'].render(text, True, (20, 20, 20))
        self.screen.blit(button_shadow, (rect.centerx - button_shadow.get_width() // 2 + 2,
                                         rect.centery - button_shadow.get_height() // 2 + 2))

        button_text = self.fonts['small'].render(text, True, WHITE)
        self.screen.blit(button_text,
                         (rect.centerx - button_text.get_width() // 2, rect.centery - button_text.get_height() // 2))

    def _get_spinning_player_image(self):
        """Get the player image rotated based on current time for spinning effect"""
        if not self.game:
            return None

        # Get the base player image (prefer right-facing)
        base_image = None
        if hasattr(Character, '_player_images') and Character._player_images:
            base_image = Character._player_images.get('right') or Character._player_images.get('left')

        if not base_image:
            return None

        # Calculate rotation angle based on time (slow, continuous spin)
        current_time = pygame.time.get_ticks()
        rotation_angle = (current_time * 0.05) % 360  # Slow rotation speed

        # Scale up the image for better visibility on death screen
        scaled_image = pygame.transform.scale(base_image, (96, 96))  # Double the normal size

        # Rotate the scaled image
        rotated_image = pygame.transform.rotate(scaled_image, rotation_angle)

        return rotated_image

    def _create_death_screen_buttons(self, has_progress):
        """Create appropriate buttons for the death screen"""
        button_width = 350
        button_height = 70

        if has_progress:
            # Two buttons: Continue and New Game
            # Continue button (main button)
            continue_x = (SCREEN_WIDTH - button_width) // 2
            continue_y = SCREEN_HEIGHT - 180
            self.game.restart_button = pygame.Rect(continue_x, continue_y, button_width, button_height)

            # New Game button (below continue)
            new_game_x = (SCREEN_WIDTH - button_width) // 2
            new_game_y = SCREEN_HEIGHT - 100
            self.game.new_game_button = pygame.Rect(new_game_x, new_game_y, button_width, button_height)
        else:
            # Single restart button
            restart_x = (SCREEN_WIDTH - button_width) // 2
            restart_y = SCREEN_HEIGHT - 140
            self.game.restart_button = pygame.Rect(restart_x, restart_y, button_width, button_height)

            # No new game button needed
            if hasattr(self.game, 'new_game_button'):
                self.game.new_game_button = None

    # ==================== ZONE TITLE METHODS ====================

    def draw_zone_title(self):
        """Draw zone entry title with fade effects"""
        if not self.game or not self.game.show_zone_title:
            return

        current_time = pygame.time.get_ticks()
        elapsed = current_time - self.game.zone_title_start_time
        progress = min(1.0, elapsed / self.game.zone_title_duration)

        # Calculate fade effect (fade in first 0.5 seconds, stable, then fade out last 0.5 seconds)
        if elapsed < 500:  # Fade in
            alpha_factor = elapsed / 500.0
        elif elapsed > (self.game.zone_title_duration - 500):  # Fade out
            alpha_factor = (self.game.zone_title_duration - elapsed) / 500.0
        else:  # Stable
            alpha_factor = 1.0

        alpha_factor = max(0.0, min(1.0, alpha_factor))

        # Create overlay background
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay_alpha = int(100 * alpha_factor)  # Semi-transparent background
        overlay.fill((0, 0, 0, overlay_alpha))
        self.screen.blit(overlay, (0, 0))

        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2 - 50

        # Draw title with glow effect
        title_alpha = int(255 * alpha_factor)

        # Title and subtitle fonts (cached)
        title_font = self._get_font(72)
        subtitle_font = self._get_font(32)

        # Draw glow effect for title
        glow_colors = [
            (255, 255, 100, int(40 * alpha_factor)),  # Yellow glow
            (255, 200, 50, int(30 * alpha_factor)),  # Orange middle
            (255, 150, 0, int(20 * alpha_factor)),  # Red outer
        ]

        glow_offsets = [3, 6, 9]

        for i, (color, offset) in enumerate(zip(glow_colors, glow_offsets)):
            glow_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            glow_text = title_font.render(self.game.current_zone_title, True, color[:3])
            glow_text.set_alpha(color[3])

            for dx in [-offset, 0, offset]:
                for dy in [-offset, 0, offset]:
                    if dx != 0 or dy != 0:
                        glow_surface.blit(glow_text,
                                          (center_x - glow_text.get_width() // 2 + dx,
                                           center_y - glow_text.get_height() // 2 + dy))

            self.screen.blit(glow_surface, (0, 0))

        # Draw main title with subtle pulse
        pulse_intensity = 0.9 + 0.1 * math.sin(elapsed * 0.005)
        title_color = (
            int(255 * pulse_intensity * alpha_factor),
            int(255 * pulse_intensity * alpha_factor),
            int(150 * pulse_intensity * alpha_factor)
        )

        main_title = title_font.render(self.game.current_zone_title, True, title_color)
        title_rect = main_title.get_rect(center=(center_x, center_y))
        self.screen.blit(main_title, title_rect)

        # Draw subtitle below title
        if self.game.zone_title_subtitle:
            subtitle_color = (
                int(200 * alpha_factor),
                int(200 * alpha_factor),
                int(200 * alpha_factor)
            )

            subtitle_surface = subtitle_font.render(self.game.zone_title_subtitle, True, subtitle_color)
            subtitle_rect = subtitle_surface.get_rect(center=(center_x, center_y + 60))
            self.screen.blit(subtitle_surface, subtitle_rect)

        # Add decorative elements
        self._draw_zone_title_decorations(center_x, center_y, elapsed, alpha_factor)

    def _draw_zone_title_decorations(self, center_x, center_y, elapsed, alpha_factor):
        """Draw decorative elements around zone title"""
        # Animated border lines
        line_length = 200
        line_y_offset = 100

        # Top line
        line_progress = min(1.0, (elapsed - 200) / 800.0) if elapsed > 200 else 0
        if line_progress > 0:
            line_width = int(line_length * line_progress)
            line_alpha = int(255 * alpha_factor)
            line_color = (255, 215, 0, line_alpha)  # Gold color

            start_x = center_x - line_width // 2
            end_x = center_x + line_width // 2

            pygame.draw.line(self.screen, line_color[:3],
                             (start_x, center_y - line_y_offset),
                             (end_x, center_y - line_y_offset), 3)

            # Bottom line
            pygame.draw.line(self.screen, line_color[:3],
                             (start_x, center_y + line_y_offset),
                             (end_x, center_y + line_y_offset), 3)

        # Sparkle effects (only after fade-in is complete)
        if elapsed > 500 and alpha_factor > 0.8:
            random.seed(int(elapsed / 100))  # Consistent but changing sparkles

            for i in range(8):
                angle = (elapsed * 0.001 + i * 45) % 360
                distance = 250 + 30 * math.sin(elapsed * 0.002 + i)

                sparkle_x = center_x + int(distance * math.cos(math.radians(angle)))
                sparkle_y = center_y + int(distance * math.sin(math.radians(angle)))

                sparkle_size = random.randint(2, 6)
                sparkle_alpha = int(random.randint(100, 255) * alpha_factor)
                sparkle_color = (255, 255, random.randint(100, 255), sparkle_alpha)

                sparkle_surface = pygame.Surface((sparkle_size * 2, sparkle_size * 2), pygame.SRCALPHA)
                pygame.draw.circle(sparkle_surface, sparkle_color[:3],
                                   (sparkle_size, sparkle_size), sparkle_size)
                sparkle_surface.set_alpha(sparkle_alpha)

                self.screen.blit(sparkle_surface,
                                 (sparkle_x - sparkle_size, sparkle_y - sparkle_size))

    # ==================== COMBAT HELPER METHODS ====================

    def _draw_combat_health_bars(self, positions, enemy):
        """Draw health bars for combat"""
        bar_size = COMBAT_UI['health_bar_size']

        # Player health bar
        if self.game:
            self.game.player.draw_health_bar(self.screen, positions['player_x'],
                                             positions['player_y'] + 100, bar_size)

        # Enemy health bar
        if enemy:
            enemy_bar_x = positions['enemy_x'] - bar_size[0] // 2
            enemy_bar_y = positions['enemy_y'] + 100
            enemy_bar_rect = pygame.Rect(enemy_bar_x, enemy_bar_y, *bar_size)

            enemy_fill_width = (enemy.hp / enemy.max_hp) * bar_size[0]
            pygame.draw.rect(self.screen, (50, 50, 50), enemy_bar_rect)
            pygame.draw.rect(self.screen, (200, 30, 30),
                             (enemy_bar_rect.x, enemy_bar_rect.y, enemy_fill_width, enemy_bar_rect.height))
            pygame.draw.rect(self.screen, WHITE, enemy_bar_rect, 1)

    def _draw_combat_log(self, combat_log):
        """Draw combat log"""
        log_size = COMBAT_UI['log_size']
        log_pos = COMBAT_UI['log_position']()
        log_rect = pygame.Rect(*log_pos, *log_size)

        pygame.draw.rect(self.screen, (20, 20, 30), log_rect)
        pygame.draw.rect(self.screen, (100, 100, 100), log_rect, 1)

        # Title
        log_title = self.fonts['small'].render("COMBAT LOG", True, WHITE)
        self.screen.blit(log_title, (log_rect.x + 10, log_rect.y + 5))

        # Display messages
        y_offset = 25
        visible_lines = min(6, len(combat_log))
        start_idx = max(0, len(combat_log) - visible_lines)

        for i in range(start_idx, len(combat_log)):
            text = self.fonts['tiny'].render(combat_log[i], True, WHITE)
            self.screen.blit(text, (log_rect.x + 10, log_rect.y + y_offset))
            y_offset += 18

    # ==================== MINIMAP METHODS ====================

    def update_revealed_area(self, player_x: int, player_y: int):
        """Update fog of war based on player position - MODIFIED for Noah mode"""
        if not self.game or (player_x, player_y) == self.last_player_pos:
            return

        self.last_player_pos = (player_x, player_y)
        zone_name = self.game.current_zone
        zone = self.game.get_current_zone()

        # Clear old revealed positions for items/enemies that are gone
        current_positions = set()

        # Add positions for remaining objects (skip if train station)
        if not zone.is_hub:
            for obj_list in [zone.trash_items, zone.enemies, zone.npcs]:
                for obj, x, y in obj_list:
                    if hasattr(obj, 'x'):  # Enemy/NPC with updated position
                        x, y = obj.x, obj.y
                    map_x = int((x / self.game.world_width) * MINIMAP_SIZE[0])
                    map_y = int((y / self.game.world_height) * MINIMAP_SIZE[1])
                    current_positions.add((map_x, map_y))

        # Add door positions for all zones (including train station)
        for door in zone.doors:
            map_x = int((door.x / self.game.world_width) * MINIMAP_SIZE[0])
            map_y = int((door.y / self.game.world_height) * MINIMAP_SIZE[1])
            current_positions.add((map_x, map_y))

        # Update revealed positions
        self.revealed_positions[zone_name] = {
            pos for pos in self.revealed_positions.get(zone_name, set())
            if pos in current_positions
        }

        # NEW: Check for Noah mode for special item visibility
        noah_mode = getattr(self.game, 'noah_mode', False) or self.game.is_noah_mode() if hasattr(self.game,
                                                                                                  'is_noah_mode') else False

        if noah_mode and not zone.is_hub:
            # NOAH MODE: Add ALL item positions immediately (but not enemies/NPCs)
            for obj, x, y in zone.trash_items:
                map_x = int((x / self.game.world_width) * MINIMAP_SIZE[0])
                map_y = int((y / self.game.world_height) * MINIMAP_SIZE[1])
                self.revealed_positions[zone_name].add((map_x, map_y))
        else:
            # NORMAL MODE: Add new positions in visible area only
            visible_bounds = (
                player_x - SCREEN_WIDTH // 2, player_x + SCREEN_WIDTH // 2,
                player_y - SCREEN_HEIGHT // 2, player_y + SCREEN_HEIGHT // 2
            )

            # Add object positions (skip for train station)
            if not zone.is_hub:
                for obj_list in [zone.trash_items, zone.enemies, zone.npcs]:
                    for obj, x, y in obj_list:
                        if hasattr(obj, 'x'):
                            x, y = obj.x, obj.y
                        if (visible_bounds[0] <= x <= visible_bounds[1] and
                                visible_bounds[2] <= y <= visible_bounds[3]):
                            map_x = int((x / self.game.world_width) * MINIMAP_SIZE[0])
                            map_y = int((y / self.game.world_height) * MINIMAP_SIZE[1])
                            self.revealed_positions[zone_name].add((map_x, map_y))

        # Add door positions for all zones (both modes)
        visible_bounds = (
            player_x - SCREEN_WIDTH // 2, player_x + SCREEN_WIDTH // 2,
            player_y - SCREEN_HEIGHT // 2, player_y + SCREEN_HEIGHT // 2
        )

        for door in zone.doors:
            if (visible_bounds[0] <= door.x <= visible_bounds[1] and
                    visible_bounds[2] <= door.y <= visible_bounds[3]):
                map_x = int((door.x / self.game.world_width) * MINIMAP_SIZE[0])
                map_y = int((door.y / self.game.world_height) * MINIMAP_SIZE[1])
                self.revealed_positions[zone_name].add((map_x, map_y))

        self.minimap_dirty = True

    def draw_minimap(self):
        """Draw the minimap with player position"""
        if not self.game:
            return

        zone_name = self.game.current_zone
        if self.minimap_dirty or zone_name not in self.minimap_caches:
            self._rebuild_minimap_cache(zone_name)

        # Draw minimap
        minimap_x, minimap_y = MINIMAP_POSITION
        self.screen.blit(self.minimap_caches[zone_name], (minimap_x, minimap_y))

        # Draw player position
        player_map_x = int((self.game.player.x / self.game.world_width) * MINIMAP_SIZE[0])
        player_map_y = int((self.game.player.y / self.game.world_height) * MINIMAP_SIZE[1])
        pygame.draw.circle(self.screen, GREEN, (minimap_x + player_map_x, minimap_y + player_map_y), 3)

        # Draw zone name
        zone_display_name = "🚂 Train Station" if zone_name == "Train Station" else zone_name
        zone_text = self.fonts['tiny'].render(zone_display_name, True, WHITE)
        self.screen.blit(zone_text, (SCREEN_WIDTH // 2 - zone_text.get_width() // 2, minimap_y - 20))

    def _rebuild_minimap_cache(self, zone_name):
        """Rebuild minimap cache with colored dots - NPCs are now BLUE"""
        self.minimap_caches[zone_name] = pygame.Surface(MINIMAP_SIZE, pygame.SRCALPHA)

        # Different background color for train station
        if zone_name == "Train Station":
            self.minimap_caches[zone_name].fill((80, 60, 40, 180))  # Brown tint
        else:
            self.minimap_caches[zone_name].fill(UI_COLORS['overlay_bg'])

        zone = self.game.zones.get(zone_name)
        if not zone:
            return

        # Draw revealed positions with different colors
        for pos in self.revealed_positions.get(zone_name, set()):
            color = self._get_minimap_color(zone, pos)
            pygame.draw.circle(self.minimap_caches[zone_name], color, pos, 2)

        # Draw zone border
        border_color = YELLOW if zone_name == "Train Station" else GREEN
        pygame.draw.rect(self.minimap_caches[zone_name], border_color, (0, 0, *MINIMAP_SIZE), 1)
        self.minimap_dirty = False

    def _get_minimap_color(self, zone, pos):
        """Determine the color for a minimap position - NPCs are BLUE, with Noah mode support"""
        # Check doors first (highest priority)
        for door in zone.doors:
            door_x = int((door.x / self.game.world_width) * MINIMAP_SIZE[0])
            door_y = int((door.y / self.game.world_height) * MINIMAP_SIZE[1])
            if (door_x, door_y) == pos:
                return YELLOW if zone.name == "Train Station" else GREEN

        # Check NPCs second - Returns BLUE for NPCs
        for npc, x, y in zone.npcs:
            if hasattr(npc, 'x'):
                x, y = npc.x, npc.y
            npc_x = int((x / self.game.world_width) * MINIMAP_SIZE[0])
            npc_y = int((y / self.game.world_height) * MINIMAP_SIZE[1])
            if (npc_x, npc_y) == pos:
                return (0, 100, 255)  # BLUE color for NPCs

        # Check enemies third (only if not a hub zone)
        if not zone.is_hub:
            for enemy, x, y in zone.enemies:
                if hasattr(enemy, 'x'):
                    x, y = enemy.x, enemy.y
                enemy_x = int((x / self.game.world_width) * MINIMAP_SIZE[0])
                enemy_y = int((y / self.game.world_height) * MINIMAP_SIZE[1])
                if (enemy_x, enemy_y) == pos:
                    return RED

        # NEW: Check items (trash_items) - Return a distinct color for items
        if not zone.is_hub:
            for item, x, y in zone.trash_items:
                item_x = int((x / self.game.world_width) * MINIMAP_SIZE[0])
                item_y = int((y / self.game.world_height) * MINIMAP_SIZE[1])
                if (item_x, item_y) == pos:
                    # Return a distinct color for items (light gray/silver)
                    return (180, 180, 180)

        # Default to white for unknown objects
        return WHITE

        # Check NPCs second - Now returns BLUE for NPCs
        for npc, x, y in zone.npcs:
            if hasattr(npc, 'x'):
                x, y = npc.x, npc.y
            npc_x = int((x / self.game.world_width) * MINIMAP_SIZE[0])
            npc_y = int((y / self.game.world_height) * MINIMAP_SIZE[1])
            if (npc_x, npc_y) == pos:
                return (0, 100, 255)  # BLUE color for NPCs

        # Check enemies third (only if not a hub zone)
        if not zone.is_hub:
            for enemy, x, y in zone.enemies:
                if hasattr(enemy, 'x'):
                    x, y = enemy.x, enemy.y
                enemy_x = int((x / self.game.world_width) * MINIMAP_SIZE[0])
                enemy_y = int((y / self.game.world_height) * MINIMAP_SIZE[1])
                if (enemy_x, enemy_y) == pos:
                    return RED

        # Default to white for unknown objects
        return WHITE

    # ==================== UI DRAWING METHODS ====================

    def draw_ui(self, player: Character, zone: Zone, zone_name: str):
        """Draw UI using Character method"""
        combat_cooldown = self.game.get_combat_cooldown_remaining() if self.game else 0
        speed_boost = self.game.get_speed_boost_remaining() if self.game else 0

        player.draw_stats_ui(self.screen, self.fonts, zone_name, zone, combat_cooldown, speed_boost)

        # Controls (updated to include H key)
        controls = [
            "WASD/Arrows - Move", "SPACE - Collect Trash", "C - Crafting",
            "I - Inventory", "G - Player Stats", "H - Highscores",
            "X - Speak to NPC", "M - Toggle Mini-map"
        ]

        for i, control in enumerate(controls):
            text = self.fonts['tiny'].render(control, True, WHITE)
            self.screen.blit(text, (SCREEN_WIDTH - 200, 10 + i * 20))

        # Draw minimap if enabled
        if self.game and self.game.show_minimap:
            self.draw_minimap()

    def draw_music_button(self):
        """Draw the music toggle button in bottom right corner"""
        if not self.game:
            return

        button_rect = self.game.get_music_button_rect()

        # Button color based on actual playing state
        button_color = (50, 150, 50) if self.game.music_playing else (150, 50, 50)
        pygame.draw.rect(self.screen, button_color, button_rect)
        pygame.draw.rect(self.screen, WHITE, button_rect, 2)

        # Music note symbol
        center_x, center_y = button_rect.centerx, button_rect.centery
        if self.game.music_loaded:
            if self.game.music_playing:
                # Draw music note (playing)
                pygame.draw.circle(self.screen, WHITE, (center_x - 5, center_y + 3), 4)
                pygame.draw.rect(self.screen, WHITE, (center_x - 1, center_y - 10, 2, 13))
                pygame.draw.arc(self.screen, WHITE, (center_x - 1, center_y - 10, 8, 6), 0, 3.14, 2)
            else:
                # Draw muted music note (paused)
                pygame.draw.circle(self.screen, WHITE, (center_x - 5, center_y + 3), 4, 2)
                pygame.draw.rect(self.screen, WHITE, (center_x - 1, center_y - 10, 2, 13))
                pygame.draw.arc(self.screen, WHITE, (center_x - 1, center_y - 10, 8, 6), 0, 3.14, 2)
                # Add mute line
                pygame.draw.line(self.screen, RED, (center_x - 8, center_y - 8),
                                 (center_x + 8, center_y + 8), 2)
        else:
            # Show "X" if no music loaded
            pygame.draw.line(self.screen, WHITE, (button_rect.left + 8, button_rect.top + 8),
                             (button_rect.right - 8, button_rect.bottom - 8), 3)
            pygame.draw.line(self.screen, WHITE, (button_rect.right - 8, button_rect.top + 8),
                             (button_rect.left + 8, button_rect.bottom - 8), 3)

    def draw_dialogue(self):
        """Draw dialogue using the correct NPC or Door with quest support"""
        if not self.game or not self.game.show_dialogue:
            return

        # Check if we're showing door dialogue
        if hasattr(self.game, 'current_door_dialogue') and self.game.current_door_dialogue:
            # Draw door dialogue with image
            door = self.game.current_door_dialogue
            door.draw_dialogue(self.screen, self.fonts)
            return

        # Draw NPC dialogue with quest support
        if (hasattr(self.game, 'input_handler') and
                self.game.input_handler.current_interacting_npc and
                self.game.show_dialogue):
            current_npc = self.game.input_handler.current_interacting_npc
            player_inventory = self.game.player.inventory if self.game.player else []
            current_npc.draw_dialogue(self.screen, self.fonts, player_inventory)

    # ==================== INVENTORY METHODS ====================

    def draw_inventory(self, inventory: List[Item]):
        """Draw inventory with categorized sections"""
        # Semi-transparent overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(180)
        overlay.fill(BLACK)
        self.screen.blit(overlay, (0, 0))

        # Main panel
        panel_width, panel_height = INVENTORY_PANEL_SIZE
        panel_rect = pygame.Rect(50, 50, panel_width, panel_height)

        pygame.draw.rect(self.screen, UI_COLORS['panel_bg'], panel_rect)
        pygame.draw.rect(self.screen, WHITE, panel_rect, 3)

        # Title
        title = self.fonts['normal'].render("INVENTORY", True, WHITE)
        self.screen.blit(title, (panel_rect.centerx - title.get_width() // 2, panel_rect.y + 15))

        # Draw player stats
        if self.game:
            self.game.player.draw(self.screen, panel_rect.centerx, panel_rect.y + 75, combat_mode=False)

            # Player stats
            stats = [
                f"Level: {self.game.player.level}  HP: {self.game.player.hp}/{self.game.player.max_hp}",
                f"Attack: {self.game.player.total_attack}  XP: {self.game.player.xp}"
            ]
            for i, stat in enumerate(stats):
                text = self.fonts['small'].render(stat, True, WHITE)
                self.screen.blit(text, (panel_rect.centerx - text.get_width() // 2,
                                        panel_rect.y + 110 + i * 18))

        # Get categorized inventory
        categories = self.game.player.get_inventory_by_category() if self.game else {
            'trash': [], 'food': [], 'art': [], 'crafted': []
        }

        # Draw inventory sections
        self._draw_inventory_sections(panel_rect, categories)

        # Instructions
        instructions = [
            "Press I to close  |  Click items to use/equip",
            "Mouse wheel to scroll sections (when hovering)"
        ]
        for i, instruction in enumerate(instructions):
            text = self.fonts['tiny'].render(instruction, True, WHITE)
            self.screen.blit(text, (panel_rect.x + 20, panel_rect.bottom - 45 + i * 18))

    def _draw_inventory_sections(self, panel_rect, categories):
        """Draw the inventory sections using Item drawing methods"""
        inventory_start_y = panel_rect.y + 145
        section_width = panel_rect.width // 4  # 4 sections now (trash, food, art, crafted)

        # Section positions
        sections = [
            ('trash', panel_rect.x + 15, "TRASH ITEMS"),
            ('food', panel_rect.x + section_width + 15, "FOOD"),
            ('art', panel_rect.x + 2 * section_width + 15, "ART"),
            ('crafted', panel_rect.x + 3 * section_width + 15, "CRAFTED ITEMS")
        ]

        for i, (category, x_pos, label) in enumerate(sections):
            # Draw section label
            label_surf = self.fonts['small'].render(label, True, BLACK)
            label_width = label_surf.get_width() + 16
            label_rect = pygame.Rect(x_pos + (section_width - label_width) // 2,
                                     inventory_start_y,
                                     label_width,
                                     label_surf.get_height() + 6)
            pygame.draw.rect(self.screen, UI_COLORS['light_gray'], label_rect)
            pygame.draw.rect(self.screen, WHITE, label_rect, 1)
            self.screen.blit(label_surf, (label_rect.x + 8, label_rect.y + 3))

            # Draw divider
            if i < 3:  # Only draw dividers between sections
                divider_x = panel_rect.x + (i + 1) * section_width
                pygame.draw.line(self.screen, WHITE,
                                 (divider_x, inventory_start_y + 30),
                                 (divider_x, panel_rect.bottom - 50), 2)

            # Draw items
            items = categories.get(category, [])
            self._draw_scrollable_section(items, category,
                                          x_pos, inventory_start_y + 35,
                                          section_width - 30,
                                          panel_rect.bottom - inventory_start_y - 85)

    def _draw_scrollable_section(self, items, section_name, start_x, start_y, width, height):
        """Draw scrollable section using Item drawing methods"""
        if not items:
            empty_text = self.fonts['tiny'].render("Empty", True, (150, 150, 150))
            self.screen.blit(empty_text, (start_x + width // 2 - empty_text.get_width() // 2, start_y + 20))
            return

        grid_settings = INVENTORY_GRID_SETTINGS
        item_height = grid_settings['item_height']
        max_visible = grid_settings['max_items_visible']

        # Handle scrolling
        scroll_offset = self.scroll_offsets.get(section_name, 0)
        max_scroll = max(0, len(items) - max_visible)
        scroll_offset = max(0, min(scroll_offset, max_scroll))
        self.scroll_offsets[section_name] = scroll_offset

        # Draw visible items using Item.draw_inventory_item
        for i in range(max_visible):
            item_index = i + scroll_offset
            if item_index >= len(items):
                break

            item = items[item_index]
            item_y = start_y + (i * item_height)
            is_equipped = (hasattr(self.game, 'player') and
                           item in self.game.player.equipped_items)

            item.draw_inventory_item(self.screen, start_x, item_y, width, item_height,
                                     is_equipped, self.fonts['tiny'])

        # Draw scroll indicators
        if max_scroll > 0:
            self._draw_scroll_indicators(start_x, start_y, width, height,
                                         scroll_offset, max_scroll, section_name)

    def _draw_scroll_indicators(self, start_x, start_y, width, height, scroll_offset, max_scroll, section_name):
        """Draw scroll bar indicators"""
        indicator_width = 8
        indicator_x = start_x + width - indicator_width - 2

        # Background bar
        bar_rect = pygame.Rect(indicator_x, start_y, indicator_width, height - 10)
        pygame.draw.rect(self.screen, UI_COLORS['scroll_bar'], bar_rect)

        # Scroll thumb
        thumb_height = max(20, int(bar_rect.height * 0.3))
        thumb_y = start_y + int((scroll_offset / max_scroll) * (bar_rect.height - thumb_height))
        thumb_rect = pygame.Rect(indicator_x, thumb_y, indicator_width, thumb_height)
        pygame.draw.rect(self.screen, UI_COLORS['scroll_thumb'], thumb_rect)

        # Store section rect for scroll detection
        self.section_rects[section_name] = pygame.Rect(start_x, start_y, width, height)

    # ==================== CRAFTING AND STATS METHODS ====================

    def draw_crafting_menu(self):
        """Draw crafting menu using CraftingSystem method"""
        if self.game and self.game.crafting:
            self.game.crafting.draw_crafting_menu(self.screen, self.fonts, self.game.player.inventory)

    def draw_player_stats_menu(self):
        """Draw player stats menu using Character method"""
        if self.game:
            button_rects = self.game.player.draw_stats_menu(self.screen, self.fonts)
            self.upgrade_button_rects = button_rects  # Store the rects for click handling
            return button_rects
        return {}

    # ==================== HIGHSCORE METHODS ====================

    def draw_highscores(self, highscore_system):
        """Draw highscore window with animated pulsing border and current game time"""
        # Semi-transparent overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(180)
        overlay.fill(BLACK)
        self.screen.blit(overlay, (0, 0))

        # Main panel (larger for highscores)
        panel_width = SCREEN_WIDTH - 100
        panel_height = SCREEN_HEIGHT - 100
        panel_rect = pygame.Rect(50, 50, panel_width, panel_height)

        # Draw animated pulsing border
        self._draw_pulsing_border(panel_rect)

        # Main panel background
        pygame.draw.rect(self.screen, UI_COLORS['panel_bg'], panel_rect)
        pygame.draw.rect(self.screen, WHITE, panel_rect, 3)

        # Draw glowing title
        self._draw_glowing_title("HIGHSCORES", panel_rect.centerx, panel_rect.y + 40)

        # Get highscores data
        highscores = highscore_system.get_top_scores(50)

        if not highscores:
            # Show "No highscores yet" message
            no_scores_text = self.fonts['normal'].render("No highscores recorded yet!", True, WHITE)
            no_scores_rect = no_scores_text.get_rect(center=(panel_rect.centerx, panel_rect.centery))
            self.screen.blit(no_scores_text, no_scores_rect)

            # Instructions
            instruction_text = self.fonts['small'].render("Complete the game to set your first highscore!", True,
                                                          (150, 150, 150))
            instruction_rect = instruction_text.get_rect(center=(panel_rect.centerx, panel_rect.centery + 50))
            self.screen.blit(instruction_text, instruction_rect)
        else:
            # Draw column headers
            header_y = panel_rect.y + 90
            self._draw_highscore_headers(panel_rect, header_y)

            # Draw scrollable highscore list
            list_start_y = header_y + 40
            list_height = panel_rect.height - 220  # Leave more space for current time display
            self._draw_scrollable_highscore_list(panel_rect, list_start_y, list_height, highscores)

        # Draw current game time at bottom
        self._draw_current_game_time(panel_rect, highscore_system)

        # Instructions at bottom
        instructions = [
            "Press H to close  |  Mouse wheel to scroll",
            f"Showing top {min(len(highscores), 50)} fastest completion times"
        ]

        for i, instruction in enumerate(instructions):
            text = self.fonts['tiny'].render(instruction, True, (200, 200, 200))
            instruction_rect = text.get_rect(center=(panel_rect.centerx, panel_rect.bottom - 50 + i * 18))
            self.screen.blit(text, instruction_rect)

    def _draw_glowing_title(self, title_text, center_x, y):
        """Draw title with glowing effect"""
        current_time = pygame.time.get_ticks()

        # Shadow effect
        shadow_text = self.fonts['large'].render(title_text, True, (30, 60, 30))
        shadow_rect = shadow_text.get_rect(center=(center_x + 3, y + 3))
        self.screen.blit(shadow_text, shadow_rect)

        # Main title with pulsing effect
        pulse_intensity = 0.8 + 0.2 * math.sin(current_time * 0.005)
        title_color = (int(255 * pulse_intensity), int(215 * pulse_intensity), 0)
        title_text_surf = self.fonts['large'].render(title_text, True, title_color)
        title_rect = title_text_surf.get_rect(center=(center_x, y))
        self.screen.blit(title_text_surf, title_rect)

    def _draw_highscore_headers(self, panel_rect, y):
        """Draw column headers for highscore table"""
        header_color = (200, 200, 200)

        # Column positions
        headers_data = [
            (panel_rect.x + 50, "RANK"),
            (panel_rect.x + 150, "PLAYER NAME"),
            (panel_rect.x + 350, "TIME"),
            (panel_rect.x + 450, "HP"),
            (panel_rect.x + 550, "ATTACK"),
            (panel_rect.x + panel_rect.width - 200, "DATE")
        ]

        # Draw headers
        for x, header in headers_data:
            header_surf = self.fonts['small'].render(header, True, header_color)
            self.screen.blit(header_surf, (x, y))

        # Draw separator line
        line_y = y + 25
        pygame.draw.line(self.screen, header_color,
                         (panel_rect.x + 20, line_y),
                         (panel_rect.right - 20, line_y), 2)

    def _draw_scrollable_highscore_list(self, panel_rect, start_y, height, highscores):
        """Draw scrollable list of highscores"""
        # Scrolling settings
        if not hasattr(self, 'highscore_scroll_offset'):
            self.highscore_scroll_offset = 0

        line_height = 25
        max_visible_lines = height // line_height
        max_scroll = max(0, len(highscores) - max_visible_lines)

        # Clamp scroll offset
        self.highscore_scroll_offset = max(0, min(self.highscore_scroll_offset, max_scroll))

        # Draw visible entries
        for i in range(max_visible_lines):
            entry_index = i + self.highscore_scroll_offset
            if entry_index >= len(highscores):
                break

            entry = highscores[entry_index]
            entry_y = start_y + (i * line_height)

            # Alternate row colors
            if i % 2 == 0:
                row_rect = pygame.Rect(panel_rect.x + 20, entry_y - 2, panel_rect.width - 40, line_height)
                pygame.draw.rect(self.screen, (40, 40, 50, 100), row_rect)

            # Highlight current player's entries
            text_color = WHITE
            if hasattr(self.game, 'highscore_system') and entry.player_name == self.game.highscore_system.player_name:
                text_color = YELLOW
                highlight_rect = pygame.Rect(panel_rect.x + 15, entry_y - 2, panel_rect.width - 30, line_height)
                pygame.draw.rect(self.screen, (100, 100, 0, 50), highlight_rect)

            self._draw_highscore_entry(panel_rect, entry_y, entry, entry_index + 1, text_color)

        # Draw scroll bar if needed
        if max_scroll > 0:
            self._draw_highscore_scrollbar(panel_rect, start_y, height, max_scroll)

    def _draw_highscore_entry(self, panel_rect, y, entry, rank, text_color):
        """Draw a single highscore entry"""
        # Format date (show only date part)
        date_str = entry.timestamp.split(' ')[0] if ' ' in entry.timestamp else entry.timestamp[:10]

        # Column data with consistent positioning
        entry_data = [
            (panel_rect.x + 50, f"#{rank}"),
            (panel_rect.x + 150, entry.player_name),
            (panel_rect.x + 350, entry.get_formatted_time()),
            (panel_rect.x + 450, str(entry.player_hp)),
            (panel_rect.x + 550, str(entry.player_attack)),
            (panel_rect.x + panel_rect.width - 200, date_str)
        ]

        for x, text in entry_data:
            text_surf = self.fonts['small'].render(str(text), True, text_color)
            self.screen.blit(text_surf, (x, y))

    def _draw_highscore_scrollbar(self, panel_rect, start_y, height, max_scroll):
        """Draw scrollbar for highscore list"""
        scrollbar_x = panel_rect.right - 25
        scrollbar_width = 15

        # Background
        scrollbar_rect = pygame.Rect(scrollbar_x, start_y, scrollbar_width, height)
        pygame.draw.rect(self.screen, UI_COLORS['scroll_bar'], scrollbar_rect)

        # Thumb
        if max_scroll > 0:
            thumb_height = max(20, int(height * 0.3))
            thumb_ratio = self.highscore_scroll_offset / max_scroll
            thumb_y = start_y + int(thumb_ratio * (height - thumb_height))

            thumb_rect = pygame.Rect(scrollbar_x, thumb_y, scrollbar_width, thumb_height)
            pygame.draw.rect(self.screen, UI_COLORS['scroll_thumb'], thumb_rect)

    def _draw_current_game_time(self, panel_rect, highscore_system):
        """Draw current game time at bottom of highscore panel"""
        current_time_text = "Current Game Time: "

        # Get current game time
        if hasattr(self.game, 'highscore_system') and self.game.highscore_system.start_time:
            current_game_time = self.game.highscore_system.get_formatted_current_time()
            time_color = (150, 255, 150)  # Light green for active timer
        else:
            current_game_time = "Not Started"
            time_color = (255, 150, 150)  # Light red for inactive timer

        # Create the full text
        full_time_text = current_time_text + current_game_time

        # Add pulsing effect to current time
        current_time = pygame.time.get_ticks()
        pulse_intensity = 0.7 + 0.3 * math.sin(current_time * 0.003)
        pulsed_color = (
            int(time_color[0] * pulse_intensity),
            int(time_color[1] * pulse_intensity),
            int(time_color[2] * pulse_intensity)
        )

        # Draw background for current time display
        time_bg_rect = pygame.Rect(
            panel_rect.x + 20,
            panel_rect.bottom - 140,
            panel_rect.width - 40,
            30
        )
        pygame.draw.rect(self.screen, (40, 40, 50), time_bg_rect)
        pygame.draw.rect(self.screen, WHITE, time_bg_rect, 1)

        # Draw the text
        time_surface = self.fonts['small'].render(full_time_text, True, pulsed_color)
        time_rect = time_surface.get_rect(center=(panel_rect.centerx, time_bg_rect.centery))
        self.screen.blit(time_surface, time_rect)

        # Add additional game stats if available
        if hasattr(self.game, 'player'):
            stats_text = f"Current HP: {self.game.player.hp}/{self.game.player.max_hp}  |  " \
                         f"Level: {self.game.player.level}  |  Attack: {self.game.player.total_attack}"

            stats_surface = self.fonts['tiny'].render(stats_text, True, (200, 200, 200))
            stats_rect = stats_surface.get_rect(center=(panel_rect.centerx, time_bg_rect.centery + 20))
            self.screen.blit(stats_surface, stats_rect)

    def _draw_pulsing_border(self, panel_rect):
        """Draw animated pulsing colored border around the highscore panel"""
        current_time = pygame.time.get_ticks()

        # Create multiple pulsing layers with different colors and speeds
        border_layers = [
            {
                'color_base': (255, 0, 0),  # Red base
                'speed': 0.003,
                'thickness': 8,
                'offset': 0
            },
            {
                'color_base': (0, 255, 0),  # Green base
                'speed': 0.004,
                'thickness': 6,
                'offset': 15
            },
            {
                'color_base': (0, 0, 255),  # Blue base
                'speed': 0.005,
                'thickness': 4,
                'offset': 30
            },
            {
                'color_base': (255, 255, 0),  # Yellow base
                'speed': 0.002,
                'thickness': 10,
                'offset': 45
            }
        ]

        for layer in border_layers:
            # Calculate pulsing intensity
            pulse = 0.3 + 0.7 * abs(math.sin(current_time * layer['speed'] + layer['offset'] * 0.1))

            # Calculate color with pulsing alpha
            color = (
                int(layer['color_base'][0] * pulse),
                int(layer['color_base'][1] * pulse),
                int(layer['color_base'][2] * pulse)
            )

            # Draw pulsing border segments
            thickness = int(layer['thickness'] * pulse)

            # Create expanded rectangle for this layer
            border_offset = layer['offset']
            expanded_rect = pygame.Rect(
                panel_rect.x - border_offset,
                panel_rect.y - border_offset,
                panel_rect.width + (border_offset * 2),
                panel_rect.height + (border_offset * 2)
            )

            # Draw the border with animated thickness
            if thickness > 0:
                pygame.draw.rect(self.screen, color, expanded_rect, thickness)

        # Add sparkle effects around the border
        self._draw_border_sparkles(panel_rect, current_time)

    def _draw_border_sparkles(self, panel_rect, current_time):
        """Draw animated sparkles around the border"""
        # Use time-based seed for consistent but animated sparkles
        random.seed(int(current_time / 200))  # Change every 200ms

        # Create sparkles around the perimeter
        sparkle_count = 20
        perimeter_points = []

        # Top edge
        for i in range(sparkle_count // 4):
            x = panel_rect.x + (i * panel_rect.width) // (sparkle_count // 4)
            y = panel_rect.y
            perimeter_points.append((x, y))

        # Right edge
        for i in range(sparkle_count // 4):
            x = panel_rect.right
            y = panel_rect.y + (i * panel_rect.height) // (sparkle_count // 4)
            perimeter_points.append((x, y))

        # Bottom edge
        for i in range(sparkle_count // 4):
            x = panel_rect.right - (i * panel_rect.width) // (sparkle_count // 4)
            y = panel_rect.bottom
            perimeter_points.append((x, y))

        # Left edge
        for i in range(sparkle_count // 4):
            x = panel_rect.x
            y = panel_rect.bottom - (i * panel_rect.height) // (sparkle_count // 4)
            perimeter_points.append((x, y))

        # Draw sparkles at perimeter points
        for i, (x, y) in enumerate(perimeter_points):
            # Animate sparkles with different phases
            phase = (current_time * 0.005) + (i * 0.3)
            sparkle_intensity = abs(math.sin(phase))

            if sparkle_intensity > 0.7:  # Only show bright sparkles
                sparkle_size = random.randint(3, 8)
                sparkle_color = (
                    random.randint(150, 255),
                    random.randint(150, 255),
                    random.randint(150, 255)
                )

                # Add some random offset from exact perimeter
                offset_x = random.randint(-20, 20)
                offset_y = random.randint(-20, 20)

                sparkle_x = x + offset_x
                sparkle_y = y + offset_y

                # Draw sparkle with glow effect
                glow_surface = pygame.Surface((sparkle_size * 4, sparkle_size * 4), pygame.SRCALPHA)
                pygame.draw.circle(glow_surface, (*sparkle_color, 100),
                                   (sparkle_size * 2, sparkle_size * 2), sparkle_size * 2)
                self.screen.blit(glow_surface, (sparkle_x - sparkle_size * 2, sparkle_y - sparkle_size * 2))

                pygame.draw.circle(self.screen, sparkle_color, (sparkle_x, sparkle_y), sparkle_size)

    # ==================== EVENT HANDLING METHODS ====================

    def handle_inventory_scroll(self, event):
        """Handle mouse wheel scrolling in inventory sections"""
        if not self.game.show_inventory or not hasattr(self, 'section_rects'):
            return False

        mouse_pos = pygame.mouse.get_pos()
        scroll_amount = 1 if event.y < 0 else -1

        for section_name, rect in self.section_rects.items():
            if rect.collidepoint(mouse_pos):
                current_offset = self.scroll_offsets.get(section_name, 0)
                categories = self.game.player.get_inventory_by_category()
                items = categories.get(section_name, [])

                max_visible = INVENTORY_GRID_SETTINGS['max_items_visible']
                max_scroll = max(0, len(items) - max_visible)
                new_offset = max(0, min(current_offset + scroll_amount, max_scroll))
                self.scroll_offsets[section_name] = new_offset
                return True

        return False

    def handle_highscore_scroll(self, event):
        """Handle mouse wheel scrolling in highscore window"""
        if not hasattr(self, 'highscore_scroll_offset'):
            self.highscore_scroll_offset = 0

        scroll_amount = 3 if event.y < 0 else -3
        self.highscore_scroll_offset += scroll_amount
        return True

    # ==================== ART DISPLAY METHODS ====================

    def show_art_item_dialogue(self, art_item):
        """Show dialogue for an art item"""
        self.art_display.show_art_item_dialogue(art_item)

    def handle_art_dialogue_click(self, pos, event=None):
        """Handle clicks and scroll events on art dialogue"""
        return self.art_display.handle_art_dialogue_click(pos, event)

    def show_painting_item_viewer(self, painting_item):
        """Show painting viewer for a painting item"""
        self.art_display.show_painting_item_viewer(painting_item)

    def handle_painting_viewer_click(self, pos):
        """Handle clicks on painting viewer"""
        return self.art_display.handle_painting_viewer_click(
            pos)