# ui/player_name_screen.py - PYGBAG COMPATIBLE
"""
Player Name Entry Screen - Allows player to enter their name before starting the game
MODIFIED: Now preserves existing music playback without interruption
MODIFIED: Made compatible with pygbag for browser deployment
"""
import pygame
import sys
import asyncio  # Added for pygbag compatibility
from config.settings import *


class PlayerNameScreen:
    """Handles the player name entry screen with enhanced visuals and music preservation - PYGBAG COMPATIBLE"""

    def __init__(self):
        # DON'T call pygame.init() again - use existing pygame state
        # pygame.init()  # REMOVED - this was causing music interruption

        self.screen = pygame.display.get_surface()  # Use existing screen

        # Preserve current music state
        # self._preserve_music_state() # COMMENTED OUT

        # Initialize fonts
        self.fonts = {
            'large': pygame.font.Font(None, FONT_SIZES['large']),
            'normal': pygame.font.Font(None, FONT_SIZES['normal']),
            'small': pygame.font.Font(None, FONT_SIZES['small']),
            'tiny': pygame.font.Font(None, FONT_SIZES['tiny'])
        }

        self.clock = pygame.time.Clock()

        # Input state
        self.player_name = ""
        self.cursor_visible = True
        self.cursor_timer = 0
        self.max_name_length = 20

        # Create input box and button
        self._create_ui_elements()

        # Load player images for decoration
        self.player_images = {}
        self._load_player_images()

    def _preserve_music_state(self):
        """Preserve the current music state without interrupting playback"""
        #try:
        #    # Check if music is currently playing
        #    self.music_was_playing = pygame.mixer.music.get_busy()
        #    # Store current volume
        #    self.current_volume = pygame.mixer.music.get_volume() if self.music_was_playing else 0.5
        #except:
        #    # If there's any issue getting music state, assume music wasn't playing
        #    self.music_was_playing = False
        #    self.current_volume = 0.5
        pass  # Do nothing

    async def show(self) -> str:
        """Display name entry screen and return the entered name - preserves music - MODIFIED: Made async for pygbag"""
        # Don't touch music at all - let it continue playing whatever was playing before
        running = True

        while running:
            # Handle events
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        # Allow escape to skip name entry
                        return "Anonymous"

                    elif event.key == pygame.K_RETURN:
                        # Enter key submits the name
                        final_name = self.player_name.strip() if self.player_name.strip() else "Anonymous"
                        return final_name

                    elif event.key == pygame.K_BACKSPACE:
                        # Remove last character
                        self.player_name = self.player_name[:-1]

                    elif event.unicode.isprintable() and len(self.player_name) < self.max_name_length:
                        # Add printable characters
                        self.player_name += event.unicode

                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    # Handle button clicks
                    if self.continue_button.collidepoint(event.pos):
                        final_name = self.player_name.strip() if self.player_name.strip() else "Anonymous"
                        return final_name

                    elif self.skip_button.collidepoint(event.pos):
                        return "Anonymous"

            # Update cursor blinking
            self.cursor_timer += self.clock.get_time()
            if self.cursor_timer >= 500:  # Blink every 500ms
                self.cursor_visible = not self.cursor_visible
                self.cursor_timer = 0

            # Draw the screen
            self.draw()
            self.clock.tick(FPS)
            await asyncio.sleep(0)  # CRITICAL: Required for pygbag compatibility

        return "Anonymous"

    def _load_player_images(self):
        """Load player sprite images for decoration"""
        from models.character import Character
        Character.load_player_images()
        if hasattr(Character, '_player_images') and Character._player_images:
            self.player_images = Character._player_images

    def _create_ui_elements(self):
        """Create UI elements for the name entry screen"""
        # Input box
        input_width = 400
        input_height = 50
        input_x = (SCREEN_WIDTH - input_width) // 2
        input_y = SCREEN_HEIGHT // 2 - 20
        self.input_box = pygame.Rect(input_x, input_y, input_width, input_height)

        # Continue button
        button_width = 200
        button_height = 50
        button_x = (SCREEN_WIDTH - button_width) // 2
        button_y = input_y + 80
        self.continue_button = pygame.Rect(button_x, button_y, button_width, button_height)

        # Skip button (for anonymous play)
        skip_x = button_x
        skip_y = button_y + 60
        self.skip_button = pygame.Rect(skip_x, skip_y, button_width, button_height)

    def draw(self):
        """Draw the name entry screen with enhanced visuals"""
        # Background with gradient effect
        self._draw_background()

        # Title
        self._draw_title()

        # Decorative player sprite
        self._draw_player_decoration()

        # Instructions
        self._draw_instructions()

        # Input box
        self._draw_input_box()

        # Buttons
        self._draw_buttons()

        # Footer
        self._draw_footer()

        pygame.display.flip()

    def _draw_background(self):
        """Draw animated background"""
        import math

        # Dark gradient background
        for y in range(SCREEN_HEIGHT):
            color_intensity = int(20 + 15 * math.sin(y * 0.01))
            color = (color_intensity, color_intensity + 5, color_intensity + 10)
            pygame.draw.line(self.screen, color, (0, y), (SCREEN_WIDTH, y))

        # Floating particles for atmosphere
        current_time = pygame.time.get_ticks()
        for i in range(15):
            particle_x = (i * 73 + current_time * 0.02) % SCREEN_WIDTH
            particle_y = (i * 47 + current_time * 0.015) % SCREEN_HEIGHT
            particle_alpha = int(40 + 30 * math.sin(current_time * 0.002 + i))
            particle_size = 3 + int(2 * math.sin(current_time * 0.003 + i))

            particle_surface = pygame.Surface((particle_size * 2, particle_size * 2))
            particle_surface.set_alpha(particle_alpha)
            particle_surface.fill((100, 150, 200))  # Blue particles
            self.screen.blit(particle_surface, (particle_x, particle_y))

    def _draw_title(self):
        """Draw the main title"""
        import math

        center_x = SCREEN_WIDTH // 2
        title_y = SCREEN_HEIGHT // 2 - 150

        # Shadow effect
        shadow_text = self.fonts['large'].render("Enter Your Name", True, (30, 30, 60))
        shadow_rect = shadow_text.get_rect(center=(center_x + 3, title_y + 3))
        self.screen.blit(shadow_text, shadow_rect)

        # Main title with pulsing effect
        current_time = pygame.time.get_ticks()
        pulse_alpha = int(255 * (0.8 + 0.2 * math.sin(current_time * 0.005)))
        title_color = (150 + int(105 * math.sin(current_time * 0.004)), 200, 255)
        title_text = self.fonts['large'].render("Enter Your Name", True, title_color)
        title_rect = title_text.get_rect(center=(center_x, title_y))
        self.screen.blit(title_text, title_rect)

    def _draw_player_decoration(self):
        """Draw spinning player sprite for decoration"""
        import math

        if not self.player_images:
            return

        # Get base image
        base_image = self.player_images.get('right') or self.player_images.get('left')
        if not base_image:
            return

        # Calculate rotation and position
        current_time = pygame.time.get_ticks()
        rotation_angle = (current_time * 0.03) % 360  # Slow rotation

        # Scale and rotate
        scaled_image = pygame.transform.scale(base_image, (80, 80))
        rotated_image = pygame.transform.rotate(scaled_image, rotation_angle)

        # Position to the left of the input box
        sprite_x = self.input_box.x - 120
        sprite_y = self.input_box.centery

        # Draw glow effect
        glow_radius = 50 + int(10 * math.sin(current_time * 0.004))
        glow_surface = pygame.Surface((glow_radius * 2, glow_radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(glow_surface, (100, 150, 200, 60), (glow_radius, glow_radius), glow_radius)
        glow_rect = glow_surface.get_rect(center=(sprite_x, sprite_y))
        self.screen.blit(glow_surface, glow_rect)

        # Draw sprite
        sprite_rect = rotated_image.get_rect(center=(sprite_x, sprite_y))
        self.screen.blit(rotated_image, sprite_rect)

    def _draw_instructions(self):
        """Draw instruction text"""
        center_x = SCREEN_WIDTH // 2
        instruction_y = self.input_box.y - 50

        instruction_text = "Choose a name for the highscore leaderboard"
        instruction_surf = self.fonts['small'].render(instruction_text, True, (200, 200, 200))
        instruction_rect = instruction_surf.get_rect(center=(center_x, instruction_y))
        self.screen.blit(instruction_surf, instruction_rect)

    def _draw_input_box(self):
        """Draw the name input box with current text"""
        mouse_pos = pygame.mouse.get_pos()
        is_hovered = self.input_box.collidepoint(mouse_pos)

        # Box colors
        if is_hovered:
            box_color = (80, 80, 100)
            border_color = (150, 200, 255)
        else:
            box_color = (60, 60, 80)
            border_color = (120, 120, 140)

        # Draw box
        pygame.draw.rect(self.screen, box_color, self.input_box)
        pygame.draw.rect(self.screen, border_color, self.input_box, 3)

        # Draw text
        display_text = self.player_name
        if len(display_text) == 0:
            # Placeholder text
            placeholder_surf = self.fonts['normal'].render("Enter name here...", True, (120, 120, 120))
            text_rect = placeholder_surf.get_rect(center=(self.input_box.centerx, self.input_box.centery))
            self.screen.blit(placeholder_surf, text_rect)
        else:
            # Actual text
            text_surf = self.fonts['normal'].render(display_text, True, WHITE)
            text_x = self.input_box.x + 15
            text_y = self.input_box.centery - text_surf.get_height() // 2
            self.screen.blit(text_surf, (text_x, text_y))

            # Draw cursor
            if self.cursor_visible and len(display_text) > 0:
                cursor_x = text_x + text_surf.get_width() + 2
                cursor_y = text_y
                cursor_height = text_surf.get_height()
                pygame.draw.line(self.screen, WHITE,
                                 (cursor_x, cursor_y),
                                 (cursor_x, cursor_y + cursor_height), 2)

        # Character count
        char_count_text = f"{len(self.player_name)}/{self.max_name_length}"
        char_count_surf = self.fonts['tiny'].render(char_count_text, True, (150, 150, 150))
        self.screen.blit(char_count_surf, (self.input_box.right - 60, self.input_box.bottom + 5))

    def _draw_buttons(self):
        """Draw the continue and skip buttons"""
        mouse_pos = pygame.mouse.get_pos()

        # Continue button
        continue_hovered = self.continue_button.collidepoint(mouse_pos)
        continue_color = (60, 120, 60) if continue_hovered else (40, 100, 40)
        continue_border = (120, 200, 120) if continue_hovered else (80, 160, 80)

        pygame.draw.rect(self.screen, continue_color, self.continue_button, 0, 10)
        pygame.draw.rect(self.screen, continue_border, self.continue_button, 3, 10)

        continue_text = self.fonts['normal'].render("CONTINUE", True, WHITE)
        continue_rect = continue_text.get_rect(center=self.continue_button.center)
        self.screen.blit(continue_text, continue_rect)

        # Skip button
        skip_hovered = self.skip_button.collidepoint(mouse_pos)
        skip_color = (100, 60, 60) if skip_hovered else (80, 40, 40)
        skip_border = (160, 120, 120) if skip_hovered else (120, 80, 80)

        pygame.draw.rect(self.screen, skip_color, self.skip_button, 0, 10)
        pygame.draw.rect(self.screen, skip_border, self.skip_button, 3, 10)

        skip_text = self.fonts['normal'].render("SKIP", True, WHITE)
        skip_rect = skip_text.get_rect(center=self.skip_button.center)
        self.screen.blit(skip_text, skip_rect)

    def _draw_footer(self):
        """Draw footer instructions"""
        center_x = SCREEN_WIDTH // 2
        footer_y = SCREEN_HEIGHT - 40

        footer_text = "Press ENTER to continue or ESC to skip"
        footer_surf = self.fonts['tiny'].render(footer_text, True, (150, 150, 150))
        footer_rect = footer_surf.get_rect(center=(center_x, footer_y))
        self.screen.blit(footer_surf, footer_rect)