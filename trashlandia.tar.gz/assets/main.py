# /// script
# dependencies = [
#     "pygame-ce",
#     "pytmx",
# ]
# ///
"""
Trash Paradise - Main Entry Point
A fun environmental adventure game built with pygame
FIXED: Web-compatible version for pygbag deployment
MODIFIED: Made compatible with pygbag for browser deployment
"""
import pygame
import sys
import traceback
import math
import os
import asyncio  # Added for pygbag compatibility
import json
from config.settings import *

# Web-compatible asset loader
class WebAssetLoader:
    """Asset loader optimized for web deployment with pygbag"""

    def __init__(self):
        self.assets = {}
        self._load_lock = asyncio.Lock()

    async def preload_assets(self, asset_list):
        """Preload all necessary assets for web deployment"""
        async with self._load_lock:
            for asset_path in asset_list:
                try:
                    if asset_path not in self.assets:
                        # Use pygbag's asset loading mechanism
                        self.assets[asset_path] = await self.load_image(asset_path)
                except Exception as e:
                    print(f"Failed to preload {asset_path}: {e}")

    async def load_image(self, path, size=None):
        """Load image with proper web handling"""
        try:
            # First try direct loading
            image = pygame.image.load(path).convert_alpha()
            if size:
                image = pygame.transform.scale(image, size)
            return image
        except:
            # Fallback for web - create placeholder
            print(f"Creating placeholder for: {path}")
            if size:
                surf = pygame.Surface(size, pygame.SRCALPHA)
            else:
                surf = pygame.Surface((64, 64), pygame.SRCALPHA)

            # Color code by file type
            if "trash" in path: surf.fill((100, 100, 255, 200))
            elif "enemy" in path: surf.fill((255, 100, 100, 200))
            elif "npc" in path: surf.fill((100, 255, 100, 200))
            elif "door" in path: surf.fill((200, 200, 100, 200))
            else: surf.fill((200, 200, 200, 200))

            return surf

    def get_image(self, path, size=None):
        """Get a preloaded image or load it synchronously"""
        if path in self.assets:
            img = self.assets[path]
            if size and (img.get_width() != size[0] or img.get_height() != size[1]):
                return pygame.transform.scale(img, size)
            return img

        # Fallback for synchronous loading
        try:
            # For synchronous loading, we need to handle it differently
            # This is not ideal for web but works for desktop
            return pygame.image.load(path).convert_alpha()
        except:
            return self.get_placeholder(size or (64, 64))

    def get_placeholder(self, size):
        """Create a placeholder surface"""
        surf = pygame.Surface(size, pygame.SRCALPHA)
        surf.fill((255, 0, 255))  # Magenta for missing textures
        return surf

    # Add async version of get_image for proper web loading
    async def get_image_async(self, path, size=None):
        """Async version of get_image for proper web loading"""
        if path in self.assets:
            img = self.assets[path]
            if size and (img.get_width() != size[0] or img.get_height() != size[1]):
                return pygame.transform.scale(img, size)
            return img

        # Load the image async
        image = await self.load_image(path, size)
        self.assets[path] = image  # Cache for future use
        return image

# Global asset loader instance
asset_loader = WebAssetLoader()

# Web-compatible save system
class WebSaveSystem:
    """Save system that uses browser localStorage via JavaScript"""

    def __init__(self):
        self.save_key = "trashlandia_save_data"

    async def save_progress(self, game):
        """Save game progress to localStorage"""
        try:
            save_data = {
                "restored_zones": [zone_name for zone_name, zone in game.zones.items() if zone.is_restored],
                "player_level": game.player.level,
                "player_xp": game.player.xp,
                "player_max_hp": game.player.max_hp,
                "player_base_attack": game.player.base_attack,
                "player_block_chance": game.player.block_chance
            }

            # Convert to JSON string
            save_json = json.dumps(save_data)

            # Save to localStorage using JavaScript
            try:
                import js
                js.localStorage.setItem(self.save_key, save_json)
                return True
            except:
                # Fallback for non-web environment
                print("Web storage not available - save simulated")
                return True

        except Exception as e:
            print(f"Error saving progress: {e}")
            return False

    async def load_progress(self, game):
        """Load game progress from localStorage"""
        try:
            # Try to get data from localStorage
            try:
                import js
                save_json = js.localStorage.getItem(self.save_key)
                if not save_json:
                    return False
                save_data = json.loads(save_json)
            except:
                # Not in web environment
                return False

            # Restore zone states
            for zone_name in save_data.get("restored_zones", []):
                if zone_name in game.zones:
                    game.zones[zone_name].is_restored = True
                    game.zones[zone_name].trash_items = []
                    game.zones[zone_name].enemies = []

            # Restore player stats
            game.player.level = save_data.get("player_level", 1)
            game.player.xp = save_data.get("player_xp", 0)
            game.player.max_hp = save_data.get("player_max_hp", 100)
            game.player.hp = game.player.max_hp
            game.player.base_attack = save_data.get("player_base_attack", 10)
            game.player.block_chance = save_data.get("player_block_chance", 40)

            return True

        except Exception as e:
            print(f"Error loading progress: {e}")
            return False

    async def clear_save(self):
        """Clear save data"""
        try:
            import js
            js.localStorage.removeItem(self.save_key)
            return True
        except:
            print("Web storage not available - clear simulated")
            return True

    # Add synchronous versions for compatibility with existing code
    def save_progress_sync(self, game):
        """Synchronous version of save_progress"""
        try:
            # Try to get the current event loop
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        if loop.is_running():
            # If loop is running, we can't block - create a task and hope it completes
            task = loop.create_task(self.save_progress(game))
            return True  # Assume success since we can't get the result
        else:
            # Run the coroutine and return the result
            return loop.run_until_complete(self.save_progress(game))

    def load_progress_sync(self, game):
        """Synchronous version of load_progress"""
        try:
            # Try to get the current event loop
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        if loop.is_running():
            # If loop is running, we can't block - create a task and hope it completes
            task = loop.create_task(self.load_progress(game))
            return False  # Assume failure since we can't get the result
        else:
            # Run the coroutine and return the result
            return loop.run_until_complete(self.load_progress(game))

    def clear_save_sync(self):
        """Synchronous version of clear_save"""
        try:
            # Try to get the current event loop
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        if loop.is_running():
            # If loop is running, we can't block - create a task and hope it completes
            task = loop.create_task(self.clear_save())
            return True  # Assume success since we can't get the result
        else:
            # Run the coroutine and return the result
            return loop.run_until_complete(self.clear_save())


class MainMenu:
    """Handles the main menu screen with enhanced visuals"""

    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE)
        pygame.display.set_caption('Our Trashy Adventure')

        # Initialize fonts using settings
        self.fonts = {
            'large': pygame.font.Font(None, FONT_SIZES['large']),
            'normal': pygame.font.Font(None, FONT_SIZES['normal']),
            'small': pygame.font.Font(None, FONT_SIZES['small']),
            'tiny': pygame.font.Font(None, FONT_SIZES['tiny'])
        }

        self.clock = pygame.time.Clock()

        # Load player images for spinning effect
        self.player_images = {}
        self.spinning_image = None
        self._load_player_images()

        # Create start button
        self.start_button = None
        self._create_start_button()

    def _load_player_images(self):
        """Load player sprite images for spinning effect - FIXED: Proper async loading"""
        # Try multiple paths to find the player images
        image_paths = [
            "guy1.png", "images/guy1.png", "assets/guy1.png",
            "guy2.png", "images/guy2.png", "assets/guy2.png"
        ]

        # Load right-facing image
        for path in image_paths:
            try:
                if os.path.exists(path):
                    self.player_images['right'] = pygame.image.load(path).convert_alpha()
                    self.player_images['right'] = pygame.transform.scale(self.player_images['right'], (96, 96))
                    break
            except:
                continue

        # Load left-facing image
        for path in image_paths:
            try:
                if os.path.exists(path):
                    self.player_images['left'] = pygame.image.load(path).convert_alpha()
                    self.player_images['left'] = pygame.transform.scale(self.player_images['left'], (96, 96))
                    break
            except:
                continue

        # If images still not found, create fallback images
        if 'right' not in self.player_images:
            self._create_fallback_images()

    def _create_fallback_images(self):
        """Create fallback player images if the real ones can't be loaded"""
        # Create a simple character shape as fallback
        size = (96, 96)

        # Right-facing fallback
        right_surface = pygame.Surface(size, pygame.SRCALPHA)
        pygame.draw.circle(right_surface, (100, 200, 100), (48, 48), 30)  # Green body
        pygame.draw.circle(right_surface, (255, 200, 150), (48, 35), 20)  # Face
        pygame.draw.rect(right_surface, (100, 200, 100), (35, 60, 26, 20))  # Body
        self.player_images['right'] = right_surface

        # Left-facing fallback (just mirror the right one)
        left_surface = pygame.Surface(size, pygame.SRCALPHA)
        pygame.draw.circle(left_surface, (100, 200, 100), (48, 48), 30)  # Green body
        pygame.draw.circle(left_surface, (255, 200, 150), (48, 35), 20)  # Face
        pygame.draw.rect(left_surface, (100, 200, 100), (35, 60, 26, 20))  # Body
        self.player_images['left'] = left_surface

    def _get_spinning_player_image(self):
        """Get the player image rotated based on current time for spinning effect"""
        # Get the base player image (prefer right-facing)
        base_image = self.player_images.get('right') or self.player_images.get('left')

        if not base_image:
            # Create a simple fallback if no images are available
            fallback = pygame.Surface((96, 96), pygame.SRCALPHA)
            pygame.draw.circle(fallback, (100, 200, 100), (48, 48), 30)
            base_image = fallback

        # Calculate rotation angle based on time (slow, continuous spin)
        current_time = pygame.time.get_ticks()
        rotation_angle = (current_time * 0.05) % 360  # Slow rotation speed

        # Rotate the image
        rotated_image = pygame.transform.rotate(base_image, rotation_angle)
        return rotated_image

    def _create_start_button(self):
        """Create the start button for the main menu - positioned near the bottom"""
        button_width = 300
        button_height = 60
        button_x = (SCREEN_WIDTH - button_width) // 2
        button_y = SCREEN_HEIGHT - button_height - 50  # 50 pixels from bottom

        # Create start button rectangle
        self.start_button = pygame.Rect(button_x, button_y, button_width, button_height)

    async def show(self):
        """Display main menu and handle input - MODIFIED: Made async for pygbag"""
        clock = pygame.time.Clock()

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    # Check if start button was clicked
                    if self.start_button and self.start_button.collidepoint(event.pos):
                        return True
                elif event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                        return True
                    elif event.key == pygame.K_ESCAPE:
                        pygame.quit()
                        sys.exit()

            self.draw()
            clock.tick(FPS)
            await asyncio.sleep(0)  # Added for pygbag compatibility

    def draw(self):
        """Draw the enhanced main menu with visual effects"""
        # Semi-transparent dark overlay with gradient effect
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(220)
        overlay.fill((20, 30, 40))  # Dark blue-gray
        self.screen.blit(overlay, (0, 0))

        # Add atmospheric effects - floating particles
        current_time = pygame.time.get_ticks()
        for i in range(20):
            particle_x = (i * 51 + current_time * 0.02) % SCREEN_WIDTH
            particle_y = (i * 37 + current_time * 0.01) % SCREEN_HEIGHT
            particle_alpha = int(30 + 20 * math.sin(current_time * 0.001 + i))
            particle_size = 2 + int(math.sin(current_time * 0.002 + i))

            particle_surface = pygame.Surface((particle_size * 2, particle_size * 2))
            particle_surface.set_alpha(particle_alpha)
            particle_surface.fill((100, 150, 100))  # Green particles for environmental theme
            self.screen.blit(particle_surface, (particle_x, particle_y))

        # Center coordinates for the spinning player image
        center_x = SCREEN_WIDTH // 2
        center_y = SCREEN_HEIGHT // 2

        # Get spinning player image
        spinning_image = self._get_spinning_player_image()
        if spinning_image:
            # Create a subtle glow effect behind the spinning image
            glow_radius = 80 + int(10 * math.sin(current_time * 0.003))
            glow_surface = pygame.Surface((glow_radius * 2, glow_radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(glow_surface, (50, 150, 50, 60), (glow_radius, glow_radius), glow_radius)
            glow_rect = glow_surface.get_rect(center=(center_x, center_y))
            self.screen.blit(glow_surface, glow_rect)

            # Draw the spinning player image
            image_rect = spinning_image.get_rect(center=(center_x, center_y))
            self.screen.blit(spinning_image, image_rect)

        # Title text with enhanced styling - positioned above the spinning image
        title_text_y = center_y - 150

        # Shadow effect for title
        shadow_text = self.fonts['large'].render("Our Trashy Adventure", True, (30, 60, 30))
        shadow_rect = shadow_text.get_rect(center=(center_x + 3, title_text_y + 3))
        self.screen.blit(shadow_text, shadow_rect)

        # Main title text with pulsing effect
        pulse_alpha = int(255 * (0.8 + 0.2 * math.sin(current_time * 0.005)))
        title_color = (min(255, 100 + int(55 * math.sin(current_time * 0.004))), 200, 100)
        title_text = self.fonts['large'].render("Our Trashy Adventure", True, title_color)
        title_rect = title_text.get_rect(center=(center_x, title_text_y))
        self.screen.blit(title_text, title_rect)

        # Subtitle text - positioned below the spinning image
        subtitle_y = center_y + 120
        subtitle_text = self.fonts['normal'].render("Clean up trash to restore the environment!", True, (200, 200, 200))
        subtitle_rect = subtitle_text.get_rect(center=(center_x, subtitle_y))
        self.screen.blit(subtitle_text, subtitle_rect)

        # Enhanced start button with hover effects
        if self.start_button:
            mouse_pos = pygame.mouse.get_pos()

            # Button hover effect
            if self.start_button.collidepoint(mouse_pos):
                button_color = (80, 120, 80)
                border_color = (150, 200, 150)
                button_glow = True
            else:
                button_color = (60, 100, 60)
                border_color = (120, 150, 120)
                button_glow = False

            # Button glow effect when hovering
            if button_glow:
                glow_surface = pygame.Surface((self.start_button.width + 20, self.start_button.height + 20),
                                              pygame.SRCALPHA)
                pygame.draw.rect(glow_surface, (100, 150, 100, 40),
                                 (0, 0, self.start_button.width + 20, self.start_button.height + 20), 0, 10)
                glow_rect = glow_surface.get_rect(center=self.start_button.center)
                self.screen.blit(glow_surface, glow_rect)

            # Draw button background with rounded corners effect
            pygame.draw.rect(self.screen, button_color, self.start_button, 0, 10)
            pygame.draw.rect(self.screen, border_color, self.start_button, 3, 10)

            # Button text with shadow
            button_shadow = self.fonts['normal'].render("START GAME", True, (20, 20, 20))
            button_shadow_rect = button_shadow.get_rect(
                center=(self.start_button.centerx + 2, self.start_button.centery + 2))
            self.screen.blit(button_shadow, button_shadow_rect)

            button_text = self.fonts['normal'].render("START GAME", True, WHITE)
            button_text_rect = button_text.get_rect(center=self.start_button.center)
            self.screen.blit(button_text, button_text_rect)

        # Instructions - positioned between subtitle and button
        instructions_y = center_y + 160
        instructions = [
            "Use arrow keys to move, SPACE to collect",
            "Press X to talk to NPCs"
        ]

        for i, instruction in enumerate(instructions):
            text = self.fonts['small'].render(instruction, True, (180, 180, 180))
            text_rect = text.get_rect(center=(center_x, instructions_y + i * 25))
            self.screen.blit(text, text_rect)

        # Additional atmospheric text at the bottom
        footer_text = self.fonts['tiny'].render("Click START or press ENTER to begin your adventure", True,
                                                (150, 150, 150))
        footer_rect = footer_text.get_rect(center=(center_x, SCREEN_HEIGHT - 20))
        self.screen.blit(footer_text, footer_rect)

        pygame.display.flip()


class IntroScreen:
    """Async-compatible intro screen wrapper"""
    def __init__(self):
        self.screen = pygame.display.get_surface()

    async def show(self):
        """Show intro screen - made async for pygbag compatibility"""
        # Import the actual IntroScreen here to avoid conflicts
        from intro_screen import IntroScreen as ActualIntroScreen
        actual_intro = ActualIntroScreen()

        # Run the actual intro with async compatibility
        return await actual_intro.show()


class PlayerNameScreen:
    """Async-compatible player name screen wrapper"""
    def __init__(self):
        pass

    async def show(self):
        """Show name entry screen - made async for pygbag compatibility"""
        from ui.player_name_screen import PlayerNameScreen as ActualNameScreen
        actual_screen = ActualNameScreen()

        # Run the actual name screen with async compatibility
        return await actual_screen.show()

def play_intro_music():
    """Play looping intro music (OGG) during menu/intro/name screens"""
    for path in MUSIC_SEARCH_PATHS:
        full_path = os.path.join(path, INTRO_MUSIC)
        if os.path.exists(full_path):
            try:
                pygame.mixer.music.load(full_path)
                pygame.mixer.music.set_volume(MUSIC_VOLUME)
                pygame.mixer.music.play(-1)
                return True
            except pygame.error as e:
                print(f"Error loading intro music {full_path}: {e}")
    print(f"Warning: could not find {INTRO_MUSIC}")
    return False


async def main():
    """MODIFIED: Main application entry point made async for pygbag compatibility"""
    # Initialize pygame first
    pygame.init()
    play_intro_music()

    # Preload essential assets
    asset_list = [
        "guy1.png", "guy2.png", "guy3.png", "guyspritesheet.png",
        "trash1.png", "trash2.png", "trash3.png", "trash4.png",
        "food1.png", "food2.png", "food3.png", "food4.png",
        "enemy1.png", "enemy2.png",
        "door1.png", "door2.png", "door3.png", "door4.png", "door5.png",
        "door6.png", "door7.png", "door8.png", "door9.png", "door10.png",
        "npc1.png", "npc2.png", "npc3.png", "npc4.png", "npc5.png",
        "train.png"
    ]

    # Preload assets asynchronously
    await asset_loader.preload_assets(asset_list)

    while True:  # Outer loop allows for game restarts
        try:
            # Show main menu first
            menu = MainMenu()
            if await menu.show():
                # Show the intro screen after menu
                intro = IntroScreen()
                await intro.show()

                # Show player name screen BEFORE creating game
                name_screen = PlayerNameScreen()
                player_name = await name_screen.show()

                # Now we need to import and create the game
                # Import here to avoid circular imports
                from game import Game

                # Create game instance with web-compatible save system
                game = Game(player_name=player_name)

                # Replace the save system with web-compatible version
                game.save_system = WebSaveSystem()

                # Run the game
                await game.run()

        except Exception as e:
            print(f"Error running game: {e}")
            traceback.print_exc()
            break  # stop here so the error stays visible in the console


# Run the async main function - required for pygbag
if __name__ == "__main__":
    asyncio.run(main())