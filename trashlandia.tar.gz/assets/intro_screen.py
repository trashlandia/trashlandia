# intro_screen.py - MODIFIED VERSION - Single Player Only - PYGBAG COMPATIBLE
"""
Enhanced Animated Intro Screen with SINGLE Game Sprite Player
MODIFIED: Made compatible with pygbag for browser deployment
"""
import pygame
import math
import sys
import random
import os
import asyncio  # Added for pygbag compatibility
from config.settings import *


class GameElement:
    """Base class for animated game elements in intro"""

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.age = 0

    def update(self, dt):
        self.age += dt

    def draw(self, screen):
        pass

    def is_alive(self):
        return True

    @staticmethod
    def load_image(filename, size=None, search_paths=None):
        """Load image from various possible paths"""
        if search_paths is None:
            search_paths = ["", "assets/", "images/", "data/"]

        for path in search_paths:
            try:
                full_path = os.path.join(path, filename)
                if os.path.exists(full_path):
                    image = pygame.image.load(full_path).convert_alpha()
                    if size:
                        image = pygame.transform.scale(image, size)
                    return image
            except Exception as e:
                print(f"Error loading {full_path}: {e}")
                continue

        print(f"Warning: Could not load {filename}, using placeholder")
        return None


class AnimatedPlayer(GameElement):
    """Animated player character that uses actual game sprites"""

    def __init__(self, x, y):
        super().__init__(x, y)
        self.target_x = x
        self.target_y = y
        self.speed = 2.0
        self.facing_right = True
        self.sprite_frame = 0
        self.frame_time = 0
        self.collecting = False
        self.collect_time = 0

        # Load actual player images
        self.player_images = {}
        self._load_player_sprites()

    def _load_player_sprites(self):
        """Load the same player sprites used in main game"""
        # Try to load the actual player sprites
        sprite_files = {
            'right': 'guy1.png',
            'left': 'guy2.png'
        }

        for direction, filename in sprite_files.items():
            image = self.load_image(filename, (64, 64))  # Scale to reasonable size
            if image:
                self.player_images[direction] = image
            else:
                # Create fallback colored rectangle if image not found
                fallback = pygame.Surface((32, 32), pygame.SRCALPHA)
                fallback.fill((100, 255, 100))  # Green
                self.player_images[direction] = fallback

    def set_target(self, x, y):
        self.target_x = x
        self.target_y = y
        self.facing_right = x > self.x

    def update(self, dt):
        super().update(dt)

        # Move towards target
        dx = self.target_x - self.x
        dy = self.target_y - self.y
        distance = math.sqrt(dx * dx + dy * dy)

        if distance > 5:
            self.x += (dx / distance) * self.speed * dt * 0.1
            self.y += (dy / distance) * self.speed * dt * 0.1

        # Animate sprite
        self.frame_time += dt
        if self.frame_time > 200:  # Change frame every 200ms
            self.sprite_frame = (self.sprite_frame + 1) % 2
            self.frame_time = 0

        # Update collecting state
        if self.collecting:
            self.collect_time += dt
            if self.collect_time > 500:  # Collection animation lasts 500ms
                self.collecting = False
                self.collect_time = 0

    def start_collecting(self):
        self.collecting = True
        self.collect_time = 0

    def draw(self, screen):
        # Use actual player sprite
        direction = 'right' if self.facing_right else 'left'
        player_image = self.player_images.get(direction)

        if player_image:
            # Apply collection effect
            if self.collecting:
                # Create glowing effect during collection
                glow_size = int(20 + 10 * math.sin(self.collect_time * 0.01))
                glow_surface = pygame.Surface((glow_size * 2, glow_size * 2), pygame.SRCALPHA)
                glow_alpha = max(0, 100 - int(self.collect_time * 0.2))
                if glow_alpha > 0:
                    pygame.draw.circle(glow_surface, (255, 255, 0, glow_alpha), (glow_size, glow_size), glow_size)
                    screen.blit(glow_surface, (self.x - glow_size, self.y - glow_size))

            # Draw the actual player sprite
            sprite_rect = player_image.get_rect(center=(int(self.x), int(self.y)))
            screen.blit(player_image, sprite_rect)
        else:
            # Fallback to colored circle if no sprite
            size = 32
            color = (100, 255, 100) if not self.collecting else (255, 255, 100)
            pygame.draw.circle(screen, color, (int(self.x), int(self.y)), size // 2)


class AnimatedTrash(GameElement):
    """Animated trash item that uses actual item sprites"""

    def __init__(self, x, y, trash_type="bottle"):
        super().__init__(x, y)
        self.trash_type = trash_type
        self.bob_offset = random.random() * 6.28
        self.collected = False
        self.fade_alpha = 255
        self.pulse_phase = random.random() * 6.28

        # Load actual trash sprite
        self.trash_image = self._load_trash_sprite()

    def _load_trash_sprite(self):
        """Load actual trash sprite based on type"""
        # Map trash types to potential image files - REMOVED specific file attempts
        sprite_files = {
            "bottle": ["trash1.png"],
            "can": ["trash4.png"],
            "scrap": ["trash3.png"],
            "food": ["food1.png"]
        }

        possible_files = sprite_files.get(self.trash_type, ["trash.png"])

        # Try to load any of the possible files
        for filename in possible_files:
            image = self.load_image(filename, (32, 32))
            if image:
                return image

        # Create fallback colored square if no image found
        fallback = pygame.Surface((20, 20), pygame.SRCALPHA)
        colors = {
            "bottle": (100, 150, 255),
            "can": (200, 200, 200),
            "scrap": (150, 100, 50),
            "food": (255, 100, 100)
        }
        color = colors.get(self.trash_type, (150, 150, 150))
        fallback.fill(color)
        return fallback

    def update(self, dt):
        super().update(dt)
        if self.collected:
            self.fade_alpha = max(0, self.fade_alpha - dt * 0.5)

    def collect(self):
        self.collected = True

    def is_alive(self):
        return self.fade_alpha > 0

    def draw(self, screen):
        if self.fade_alpha <= 0:
            return

        # Bobbing motion
        bob_y = self.y + math.sin(self.age * 0.003 + self.bob_offset) * 3

        # Apply alpha for fading
        if self.trash_image:
            # Use actual sprite with bobbing and fading
            temp_image = self.trash_image.copy()
            temp_image.set_alpha(int(self.fade_alpha))

            # Add sparkle effect when not collected
            if not self.collected and random.random() < 0.1:
                sparkle_x = self.x + random.randint(-15, 15)
                sparkle_y = bob_y + random.randint(-15, 15)
                pygame.draw.circle(screen, (255, 255, 255), (int(sparkle_x), int(sparkle_y)), 2)

            # Draw the sprite
            sprite_rect = temp_image.get_rect(center=(int(self.x), int(bob_y)))
            screen.blit(temp_image, sprite_rect)


class AnimatedEnemy(GameElement):
    """Animated enemy that uses actual enemy sprites"""

    def __init__(self, x, y, enemy_type="slime"):
        super().__init__(x, y)
        self.enemy_type = enemy_type
        self.target_x = x
        self.target_y = y
        self.speed = 1.5
        self.animation_phase = random.random() * 6.28
        self.defeated = False
        self.death_timer = 0

        # Load actual enemy sprite
        self.enemy_image = self._load_enemy_sprite()

    def _load_enemy_sprite(self):
        """Load actual enemy sprite based on type"""
        # Map enemy types to potential image files - REMOVED specific file attempts
        sprite_files = {
            "slime": ["enemy1.png"],
            "robot": ["enemy2.png"],
        }

        possible_files = sprite_files.get(self.enemy_type, ["enemy1.png"])

        # Try to load any of the possible files
        for filename in possible_files:
            image = self.load_image(filename, (48, 48))
            if image:
                return image

        # Create fallback colored shape if no image found
        fallback = pygame.Surface((40, 40), pygame.SRCALPHA)
        colors = {
            "slime": (100, 255, 100),
            "robot": (200, 200, 255),
            "spiky": (255, 100, 100)
        }
        color = colors.get(self.enemy_type, (150, 150, 150))

        if self.enemy_type == "slime":
            pygame.draw.circle(fallback, color, (20, 20), 18)
        elif self.enemy_type == "robot":
            pygame.draw.rect(fallback, color, (5, 5, 30, 30))
        else:
            # Create spiky shape
            points = []
            for i in range(8):
                angle = (i / 8) * 2 * math.pi
                radius = 18 if i % 2 == 0 else 10
                x = 20 + math.cos(angle) * radius
                y = 20 + math.sin(angle) * radius
                points.append((x, y))
            pygame.draw.polygon(fallback, color, points)

        return fallback

    def set_target(self, x, y):
        self.target_x = x
        self.target_y = y

    def defeat(self):
        self.defeated = True

    def update(self, dt):
        super().update(dt)

        if not self.defeated:
            # Move towards target
            dx = self.target_x - self.x
            dy = self.target_y - self.y
            distance = math.sqrt(dx * dx + dy * dy)

            if distance > 30:  # Don't get too close
                move_x = (dx / distance) * self.speed * dt * 0.08
                move_y = (dy / distance) * self.speed * dt * 0.08
                self.x += move_x
                self.y += move_y
        else:
            self.death_timer += dt

    def is_alive(self):
        return not self.defeated or self.death_timer < 1000  # 1 second death animation

    def draw(self, screen):
        if self.defeated and self.death_timer > 1000:
            return

        if self.enemy_image:
            # Use actual enemy sprite
            temp_image = self.enemy_image.copy()

            if self.defeated:
                # Fade out during death
                fade_factor = 1.0 - (self.death_timer / 1000)
                temp_image.set_alpha(int(255 * fade_factor))

            # Apply animation (slight rotation or scaling)
            self.animation_phase += 0.005
            if self.enemy_type == "slime":
                # Slight scale pulsing for slime
                scale_factor = 1.0 + 0.1 * math.sin(self.animation_phase)
                new_size = (int(temp_image.get_width() * scale_factor),
                            int(temp_image.get_height() * scale_factor))
                if new_size[0] > 0 and new_size[1] > 0:
                    temp_image = pygame.transform.scale(temp_image, new_size)

            sprite_rect = temp_image.get_rect(center=(int(self.x), int(self.y)))
            screen.blit(temp_image, sprite_rect)


class FadingImage:
    """Image that fades in and out during the intro"""

    def __init__(self, image_path, x, y, fade_in_time=2000, display_time=3000, fade_out_time=2000):
        self.x = x
        self.y = y
        self.fade_in_time = fade_in_time
        self.display_time = display_time
        self.fade_out_time = fade_out_time
        self.age = 0
        self.alpha = 0
        self.image = None

        # Try to load the image
        self._load_image(image_path)

    def _load_image(self, image_path):
        """Load image from various possible paths"""
        search_paths = ["", "assets/", "images/", "data/"]

        for path in search_paths:
            try:
                full_path = os.path.join(path, image_path)
                if os.path.exists(full_path):
                    self.image = pygame.image.load(full_path).convert_alpha()
                    # Scale down if too large
                    if self.image.get_width() > 200 or self.image.get_height() > 200:
                        self.image = pygame.transform.scale(self.image, (100, 100))
                    return
            except Exception as e:
                print(f"Error loading {full_path}: {e}")
                continue

        # If no image found, create a placeholder
        self.image = pygame.Surface((80, 80), pygame.SRCALPHA)
        pygame.draw.rect(self.image, (100, 100, 100), (0, 0, 80, 80))
        pygame.draw.rect(self.image, (200, 200, 200), (10, 10, 60, 60))

    def update(self, dt):
        self.age += dt

        total_time = self.fade_in_time + self.display_time + self.fade_out_time

        if self.age < self.fade_in_time:
            # Fading in
            self.alpha = int(255 * (self.age / self.fade_in_time))
        elif self.age < self.fade_in_time + self.display_time:
            # Fully visible
            self.alpha = 255
        elif self.age < total_time:
            # Fading out
            fade_progress = (self.age - self.fade_in_time - self.display_time) / self.fade_out_time
            self.alpha = int(255 * (1.0 - fade_progress))
        else:
            self.alpha = 0

    def is_alive(self):
        total_time = self.fade_in_time + self.display_time + self.fade_out_time
        return self.age < total_time

    def draw(self, screen):
        if self.alpha > 0 and self.image:
            # Create a copy with alpha
            temp_image = self.image.copy()
            temp_image.set_alpha(self.alpha)
            screen.blit(temp_image, (self.x, self.y))


class IntroScreen:
    """Enhanced intro screen with animated game elements using actual sprites - SINGLE PLAYER ONLY - PYGBAG COMPATIBLE"""

    def __init__(self):
        pygame.init()
        self.screen = pygame.display.get_surface()  # Use existing screen
        self.clock = pygame.time.Clock()

        # Initialize fonts
        self.fonts = {
            'intro_large': pygame.font.Font(None, FONT_SIZES['large']),
            'intro_medium': pygame.font.Font(None, FONT_SIZES['normal']),
            'intro_small': pygame.font.Font(None, FONT_SIZES['small'])
        }

        # Intro text (keeping original)
        self.intro_text = """By the mid-21st century 


humanity had reached a breaking point. 


Decades of unchecked consumerism, 


corporate waste dumping  


and failed recycling policies 


led to a global garbage crisis...



Landfills overflowed, 


microplastics poisoned the oceans, 


and electronic waste 


leached toxins into the soil...




Governments struggled to 

manage the mounting trash...






Starting in 2065, 

all of the countries around the world 

started to weaponize garbage like

advanced-range toxic sludge missiles 

and plastic chemical dumping from planes

flying over entire regions...


This was referred to as: "The Great Disposal Wars" 

leaving the planet covered in mountains of trash...




By 2090, 

the last clean patch of land 

disappeared beneath the waves of refuse



Glowing radioactive waste trenches 

created permanent dead zones...




The Great Disposal Wars left

the Earth's ecosystems in ruins...




Then out of nowhere...

In 2093, the first

alien contact occurred

when extraterrestrial beings called: "The Observers"

made an intervention and suddenly appeared out of thin-air,

tired of being disgusted by Earth's pollution 

they decided to "help"





By the year 2099 these aliens introduced

genetically engineered trash-eating creatures 

to roam freely around the planet consuming trash

using a bacteria that eats plastic

called:  Ideonella sakaiensis...




These trash eating creatures multiplied out of control

and mutated into dangerous beasts...




The Observers realized this mistake 

and abandoned the planet 

except for one stranded alien scout...




Leaving the mutated monsters

that now lurk in the waste...





The year is now 4040, 

and you awaken in a post-apocalyptic wasteland 

try to recycle your items to craft weapons


and BATTLE the MONSTERS 

who are lurking

in the epic wasted world of



TRASHLANDIA!"""

        # Animation parameters
        self.scroll_y = SCREEN_HEIGHT
        self.scroll_speed = 1.1
        self.perspective_factor = 0.75
        self.fade_distance = 40
        self.min_scale = 0.1
        self.shrink_start = SCREEN_HEIGHT * 0.2

        # Prepare text
        self.text_lines = []
        self.line_heights = []
        self._prepare_text()

        # Animation state
        self.animation_complete = False
        self.skip_requested = False

        # Background stars
        self.stars = []
        self._generate_stars()

        # Game elements - MODIFIED: Single player only
        self.game_elements = []
        self.fading_images = []
        self.player = None  # Keep reference to the single player
        self.last_element_spawn = 0
        self.last_image_spawn = 0

        self._spawn_initial_elements()

    def _generate_stars(self):
        """Generate background stars for space effect"""
        for _ in range(150):  # More stars for richer background
            x = random.randint(0, SCREEN_WIDTH)
            y = random.randint(0, SCREEN_HEIGHT)
            brightness = random.randint(30, 255)
            size = random.randint(1, 3)
            twinkle_speed = random.random() * 0.02 + 0.01

            self.stars.append({
                'x': x,
                'y': y,
                'brightness': brightness,
                'size': size,
                'twinkle_speed': twinkle_speed,
                'twinkle_offset': random.random() * 6.28
            })

    def _prepare_text(self):
        """Prepare text lines with different fonts for emphasis"""
        lines = self.intro_text.split('\n')

        for line in lines:
            line = line.strip()

            if 'TRASHLANDIA' in line:
                font = self.fonts['intro_large']
                color = (255, 255, 100)
            elif line == '' or len(line) < 5:
                font = self.fonts['intro_small']
                color = (255, 215, 0)
            else:
                font = self.fonts['intro_medium']
                color = (255, 215, 0)

            if line:
                text_surface = font.render(line, True, color)
            else:
                text_surface = pygame.Surface((1, 30), pygame.SRCALPHA)

            self.text_lines.append((text_surface, color))
            self.line_heights.append(text_surface.get_height() + 10)

    def _spawn_initial_elements(self):
        """Spawn initial game elements - MODIFIED: Only create ONE player"""
        # Create SINGLE player (store separately, not in game_elements)
        self.player = AnimatedPlayer(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        # Don't add player to game_elements list to prevent it from being removed

        # Spawn some initial trash
        for _ in range(8):
            x = random.randint(100, SCREEN_WIDTH - 100)
            y = random.randint(100, SCREEN_HEIGHT - 100)
            trash_type = random.choice(["bottle", "can", "scrap", "food"])
            trash = AnimatedTrash(x, y, trash_type)
            self.game_elements.append(trash)

    def _spawn_random_elements(self, current_time):
        """Spawn random game elements during animation - MODIFIED: No player images at all"""
        # Spawn trash items and enemies periodically (NO MORE PLAYERS)
        if current_time - self.last_element_spawn > 2000:  # Every 2 seconds
            self.last_element_spawn = current_time

            # Spawn trash
            if random.random() < 0.7:  # 70% chance for trash
                x = random.randint(50, SCREEN_WIDTH - 50)
                y = random.randint(50, SCREEN_HEIGHT - 50)
                trash_type = random.choice(["bottle", "can", "scrap", "food"])
                trash = AnimatedTrash(x, y, trash_type)
                self.game_elements.append(trash)

                # Sometimes make the SINGLE player go to this trash
                if random.random() < 0.5 and self.player:
                    self.player.set_target(x, y)

            # Spawn enemies occasionally
            elif random.random() < 0.3:  # 30% chance for enemy
                # Spawn from edges
                if random.random() < 0.5:
                    x = 0 if random.random() < 0.5 else SCREEN_WIDTH
                    y = random.randint(100, SCREEN_HEIGHT - 100)
                else:
                    x = random.randint(100, SCREEN_WIDTH - 100)
                    y = 0 if random.random() < 0.5 else SCREEN_HEIGHT

                enemy_type = random.choice(["slime", "robot", "spiky"])
                enemy = AnimatedEnemy(x, y, enemy_type)
                if self.player:  # Target the SINGLE player
                    enemy.set_target(self.player.x, self.player.y)
                self.game_elements.append(enemy)

        # Spawn fading images - COMPLETELY REMOVED (no images at all)
        # This ensures no additional player images appear
        if current_time - self.last_image_spawn > 4000:  # Every 4 seconds
            self.last_image_spawn = current_time
            # No fading images will be spawned - this prevents any additional player images

    def _update_game_elements(self, dt):
        """Update all game elements - MODIFIED: Keep player separate"""
        # Update the single player separately
        if self.player:
            self.player.update(dt)

        # Update other elements
        for element in self.game_elements[:]:
            element.update(dt)
            if not element.is_alive():
                self.game_elements.remove(element)

        # Update fading images
        for img in self.fading_images[:]:
            img.update(dt)
            if not img.is_alive():
                self.fading_images.remove(img)

        # Game logic: player collects trash, enemies chase player
        if self.player:  # Only if player exists
            for element in self.game_elements:
                if isinstance(element, AnimatedTrash) and not element.collected:
                    # Check if player is close to trash
                    distance = math.sqrt((self.player.x - element.x) ** 2 + (self.player.y - element.y) ** 2)
                    if distance < 40:
                        element.collect()
                        self.player.start_collecting()

                elif isinstance(element, AnimatedEnemy) and not element.defeated:
                    # Enemy chases the SINGLE player
                    element.set_target(self.player.x, self.player.y)

                    # Check if player "defeats" enemy by being close enough
                    distance = math.sqrt((self.player.x - element.x) ** 2 + (self.player.y - element.y) ** 2)
                    if distance < 50 and random.random() < 0.01:  # 1% chance per frame when close
                        element.defeat()

            # Keep the SINGLE player moving around
            if random.random() < 0.003:  # Occasionally change direction
                new_x = random.randint(100, SCREEN_WIDTH - 100)
                new_y = random.randint(100, SCREEN_HEIGHT - 100)
                self.player.set_target(new_x, new_y)

    def _draw_stars(self):
        """Draw twinkling stars in the background"""
        current_time = pygame.time.get_ticks()

        for star in self.stars:
            twinkle = math.sin(current_time * star['twinkle_speed'] + star['twinkle_offset'])
            alpha = int(star['brightness'] + twinkle * 30)
            alpha = max(20, min(255, alpha))

            star_color = (alpha, alpha, alpha)

            if star['size'] == 1:
                self.screen.set_at((star['x'], star['y']), star_color)
            else:
                pygame.draw.circle(self.screen, star_color,
                                   (star['x'], star['y']), star['size'])

    def _draw_scrolling_text(self):
        """Draw the scrolling text with perspective effects"""
        current_time = pygame.time.get_ticks()
        current_y = self.scroll_y

        for i, (text_surface, base_color) in enumerate(self.text_lines):
            line_y = current_y

            # Skip if completely off screen
            if line_y > SCREEN_HEIGHT + 100:
                current_y += self.line_heights[i]
                continue
            elif line_y < -200:
                if i == len(self.text_lines) - 1:
                    self.animation_complete = True
                current_y += self.line_heights[i]
                continue

            # Calculate perspective scaling
            distance_from_bottom = SCREEN_HEIGHT - line_y
            scale_factor = 1.0 - (distance_from_bottom / SCREEN_HEIGHT) * self.perspective_factor

            if line_y < self.shrink_start:
                shrink_factor = line_y / self.shrink_start
                scale_factor *= max(self.min_scale, shrink_factor)
            else:
                scale_factor = max(self.min_scale, scale_factor)

            # Calculate alpha for fading
            if line_y < self.fade_distance:
                alpha = max(0, int(255 * (line_y / self.fade_distance)))
            else:
                alpha = 255

            # Create glow effect for title
            glow_pulse = math.sin(current_time * 0.003) * 0.3 + 0.7
            glow_alpha = int(alpha * glow_pulse)

            # Scale and render text
            if scale_factor > 0.01:
                new_width = int(text_surface.get_width() * scale_factor)
                new_height = int(text_surface.get_height() * scale_factor)

                if new_width > 0 and new_height > 0:
                    scaled_surface = pygame.transform.scale(text_surface, (new_width, new_height))
                    fade_surface = scaled_surface.copy()
                    fade_surface.set_alpha(alpha)

                    text_rect = fade_surface.get_rect()
                    text_rect.centerx = SCREEN_WIDTH // 2
                    text_rect.y = int(line_y)

                    # Glow effect for TRASHLANDIA
                    if 'TRASHLANDIA' in str(base_color):
                        for offset in [(2, 2), (-2, -2), (2, -2), (-2, 2)]:
                            glow_surface = scaled_surface.copy()
                            glow_surface.set_alpha(glow_alpha // 4)
                            glow_rect = text_rect.move(offset[0], offset[1])
                            self.screen.blit(glow_surface, glow_rect)

                    self.screen.blit(fade_surface, text_rect)

            current_y += self.line_heights[i]

    def _draw_game_elements(self):
        """Draw all game elements with slight transparency"""
        # Create overlay surface for game elements
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)

        # Draw fading images first (behind game elements)
        for img in self.fading_images:
            img.draw(overlay)

        # Draw the single player first
        if self.player:
            self.player.draw(overlay)

        # Draw other game elements
        for element in self.game_elements:
            element.draw(overlay)

        # Apply slight transparency to all game elements so text remains readable
        overlay.set_alpha(200)  # Increased from 180 for better visibility of sprites
        self.screen.blit(overlay, (0, 0))

    def handle_events(self):
        """Handle events during intro"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                self.skip_requested = True
                return True
        return False

    def update(self):
        """Update intro animation"""
        if self.skip_requested or self.animation_complete:
            return True

        current_time = pygame.time.get_ticks()
        dt = self.clock.get_time()

        # Update scrolling text
        self.scroll_y -= self.scroll_speed

        # Update game elements
        self._update_game_elements(dt)

        # Spawn new elements
        self._spawn_random_elements(current_time)

        return False

    def draw(self):
        """Draw the enhanced intro screen"""
        # Fill with deep space black
        self.screen.fill((5, 5, 15))

        # Draw twinkling stars
        self._draw_stars()

        # Draw game elements behind text
        self._draw_game_elements()

        # Draw scrolling text on top
        self._draw_scrolling_text()

        # Draw skip instruction
        skip_text = pygame.font.Font(None, 24).render(
            "Press any key or click to skip...", True, (200, 200, 200))
        skip_rect = skip_text.get_rect()
        skip_rect.centerx = SCREEN_WIDTH // 2
        skip_rect.bottom = SCREEN_HEIGHT - 20
        self.screen.blit(skip_text, skip_rect)

        pygame.display.flip()

    async def show(self):
        """Show the intro screen and return when complete or skipped - MODIFIED: Made async for pygbag"""
        while True:
            if self.handle_events():
                break

            if self.update():
                break

            self.draw()
            self.clock.tick(FPS)
            await asyncio.sleep(0)  # CRITICAL: Required for pygbag compatibility

        return True