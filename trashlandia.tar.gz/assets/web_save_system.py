# web_save_system.py
import json
import asyncio


class WebSaveSystem:
    """Save system that uses browser localStorage via JavaScript"""

    def __init__(self):
        self.save_key = "trashlandia_save_data"

    async def save_progress(self, game):
        """Save game progress to localStorage"""
        try:
            save_data = {
                "restored_zones": [zone_name for zone_name, zone in game.zones.items() if zone.is_restored],
                "player_level": game.player.level,
                "player_xp": game.player.xp,
                "player_max_hp": game.player.max_hp,
                "player_base_attack": game.player.base_attack,
                "player_block_chance": game.player.block_chance
            }

            # Convert to JSON string
            save_json = json.dumps(save_data)

            # Save to localStorage using JavaScript
            try:
                import js
                js.localStorage.setItem(self.save_key, save_json)
                return True
            except:
                # Fallback for non-web environment
                print("Web storage not available - save simulated")
                return True

        except Exception as e:
            print(f"Error saving progress: {e}")
            return False

    async def load_progress(self, game):
        """Load game progress from localStorage"""
        try:
            # Try to get data from localStorage
            try:
                import js
                save_json = js.localStorage.getItem(self.save_key)
                if not save_json:
                    return False
                save_data = json.loads(save_json)
            except:
                # Not in web environment
                return False

            # Restore zone states
            for zone_name in save_data.get("restored_zones", []):
                if zone_name in game.zones:
                    game.zones[zone_name].is_restored = True
                    game.zones[zone_name].trash_items = []
                    game.zones[zone_name].enemies = []

            # Restore player stats
            game.player.level = save_data.get("player_level", 1)
            game.player.xp = save_data.get("player_xp", 0)
            game.player.max_hp = save_data.get("player_max_hp", 100)
            game.player.hp = game.player.max_hp
            game.player.base_attack = save_data.get("player_base_attack", 10)
            game.player.block_chance = save_data.get("player_block_chance", 40)

            return True

        except Exception as e:
            print(f"Error loading progress: {e}")
            return False

    async def clear_save(self):
        """Clear save data"""
        try:
            import js
            js.localStorage.removeItem(self.save_key)
            return True
        except:
            print("Web storage not available - clear simulated")
            return True