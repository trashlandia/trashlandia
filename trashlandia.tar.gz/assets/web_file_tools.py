# web_file_tools.py
import os
import sys


def file_exists(path):
    """Check if a file exists (works for both desktop and web)"""
    try:
        # For regular file system
        return os.path.exists(path)
    except:
        # For web environment
        try:
            # Try to open the file
            with open(path, 'r') as f:
                pass
            return True
        except:
            return False


def read_file(path, encoding='utf-8'):
    """Read a file with web compatibility"""
    try:
        # Try regular file reading
        with open(path, 'r', encoding=encoding) as f:
            return f.read()
    except:
        # Try alternative approach for web
        try:
            # For pygbag/web environment
            import js
            from pyodide.ffi import to_js
            # This is a placeholder - actual implementation would need
            # to use JavaScript integration
            return "File content placeholder"
        except:
            # Final fallback
            return f"Could not load file: {path}"


def find_file(filename, search_paths=None):
    """Find a file in various possible locations"""
    if search_paths is None:
        search_paths = ["", "assets/", "images/", "maps/", "data/"]

    for path in search_paths:
        full_path = os.path.join(path, filename)
        if file_exists(full_path):
            return full_path

    return None